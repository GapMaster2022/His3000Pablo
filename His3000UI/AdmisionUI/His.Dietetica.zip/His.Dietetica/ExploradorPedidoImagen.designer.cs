﻿namespace His.Dietetica
{
    partial class frmExploradorPedidoImagen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmExploradorPedidoImagen));
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance50 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            this.tools = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonActualizar = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonBuscar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonSalir = new System.Windows.Forms.ToolStripButton();
            this.frm_ExploraPacientes_Fill_Panel = new Infragistics.Win.Misc.UltraPanel();
            this.ultraGridPacientes = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.ultraPanel1 = new Infragistics.Win.Misc.UltraPanel();
            this.ultraGroupBox2 = new Infragistics.Win.Misc.UltraGroupBox();
            this.chkFormulario = new System.Windows.Forms.CheckBox();
            this.cmbFormulario = new System.Windows.Forms.ComboBox();
            this.cmb_tipoatencion = new System.Windows.Forms.ComboBox();
            this.chbTipoIngreso = new System.Windows.Forms.CheckBox();
            this.chkTratamiento = new System.Windows.Forms.CheckBox();
            this.cboTipoIngreso = new System.Windows.Forms.ComboBox();
            this.ultraGroupBox1 = new Infragistics.Win.Misc.UltraGroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.chkHC = new System.Windows.Forms.CheckBox();
            this.ayudaPacientes = new Infragistics.Win.Misc.UltraButton();
            this.txt_historiaclinica = new System.Windows.Forms.TextBox();
            this.grpFechas = new Infragistics.Win.Misc.UltraGroupBox();
            this.chkFacturacion = new System.Windows.Forms.CheckBox();
            this.chkAlta = new System.Windows.Forms.CheckBox();
            this.chkIngreso = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblHasta = new System.Windows.Forms.Label();
            this.dtpFiltroHasta = new System.Windows.Forms.DateTimePicker();
            this.dtpFiltroDesde = new System.Windows.Forms.DateTimePicker();
            this.MnuCtxHC = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.detalleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formulariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aniadirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.microfilmDeHCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historiaClinicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ultraGridExcelExporter1 = new Infragistics.Win.UltraWinGrid.ExcelExport.UltraGridExcelExporter(this.components);
            this.pacienteContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.atencionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estadoDeCuentaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tools.SuspendLayout();
            this.frm_ExploraPacientes_Fill_Panel.ClientArea.SuspendLayout();
            this.frm_ExploraPacientes_Fill_Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGridPacientes)).BeginInit();
            this.ultraPanel1.ClientArea.SuspendLayout();
            this.ultraPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox2)).BeginInit();
            this.ultraGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox1)).BeginInit();
            this.ultraGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grpFechas)).BeginInit();
            this.grpFechas.SuspendLayout();
            this.MnuCtxHC.SuspendLayout();
            this.pacienteContextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // tools
            // 
            this.tools.AutoSize = false;
            this.tools.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonActualizar,
            this.toolStripButtonBuscar,
            this.toolStripSeparator1,
            this.toolStripButtonSalir});
            this.tools.Location = new System.Drawing.Point(0, 0);
            this.tools.Name = "tools";
            this.tools.Size = new System.Drawing.Size(874, 45);
            this.tools.TabIndex = 6;
            this.tools.Text = "toolStrip1";
            // 
            // toolStripButtonActualizar
            // 
            this.toolStripButtonActualizar.AutoSize = false;
            this.toolStripButtonActualizar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonActualizar.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonActualizar.Image")));
            this.toolStripButtonActualizar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonActualizar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonActualizar.Name = "toolStripButtonActualizar";
            this.toolStripButtonActualizar.Size = new System.Drawing.Size(42, 42);
            this.toolStripButtonActualizar.Text = "toolStripButton1";
            this.toolStripButtonActualizar.ToolTipText = "Actualizar";
            this.toolStripButtonActualizar.Click += new System.EventHandler(this.toolStripButtonActualizar_Click);
            // 
            // toolStripButtonBuscar
            // 
            this.toolStripButtonBuscar.AutoSize = false;
            this.toolStripButtonBuscar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonBuscar.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonBuscar.Image")));
            this.toolStripButtonBuscar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonBuscar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonBuscar.Name = "toolStripButtonBuscar";
            this.toolStripButtonBuscar.Size = new System.Drawing.Size(42, 42);
            this.toolStripButtonBuscar.Text = "Exportar";
            this.toolStripButtonBuscar.ToolTipText = "Exportar a excel";
            this.toolStripButtonBuscar.Click += new System.EventHandler(this.toolStripButtonBuscar_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 45);
            // 
            // toolStripButtonSalir
            // 
            this.toolStripButtonSalir.AutoSize = false;
            this.toolStripButtonSalir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonSalir.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSalir.Image")));
            this.toolStripButtonSalir.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonSalir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSalir.Name = "toolStripButtonSalir";
            this.toolStripButtonSalir.Size = new System.Drawing.Size(42, 42);
            this.toolStripButtonSalir.Text = "toolStripButton1";
            this.toolStripButtonSalir.ToolTipText = "Salir";
            this.toolStripButtonSalir.Click += new System.EventHandler(this.toolStripButtonSalir_Click);
            // 
            // frm_ExploraPacientes_Fill_Panel
            // 
            appearance1.BackColor = System.Drawing.Color.LightGray;
            appearance1.BackColor2 = System.Drawing.Color.GhostWhite;
            appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop50;
            this.frm_ExploraPacientes_Fill_Panel.Appearance = appearance1;
            // 
            // frm_ExploraPacientes_Fill_Panel.ClientArea
            // 
            this.frm_ExploraPacientes_Fill_Panel.ClientArea.Controls.Add(this.ultraGridPacientes);
            this.frm_ExploraPacientes_Fill_Panel.ClientArea.Controls.Add(this.ultraPanel1);
            this.frm_ExploraPacientes_Fill_Panel.Cursor = System.Windows.Forms.Cursors.Default;
            this.frm_ExploraPacientes_Fill_Panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.frm_ExploraPacientes_Fill_Panel.Location = new System.Drawing.Point(0, 45);
            this.frm_ExploraPacientes_Fill_Panel.Name = "frm_ExploraPacientes_Fill_Panel";
            this.frm_ExploraPacientes_Fill_Panel.Size = new System.Drawing.Size(874, 424);
            this.frm_ExploraPacientes_Fill_Panel.TabIndex = 10;
            // 
            // ultraGridPacientes
            // 
            this.ultraGridPacientes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            appearance2.BackColor = System.Drawing.SystemColors.Window;
            appearance2.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.ultraGridPacientes.DisplayLayout.Appearance = appearance2;
            this.ultraGridPacientes.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.ultraGridPacientes.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance3.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance3.BorderColor = System.Drawing.SystemColors.Window;
            this.ultraGridPacientes.DisplayLayout.GroupByBox.Appearance = appearance3;
            appearance4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.ultraGridPacientes.DisplayLayout.GroupByBox.BandLabelAppearance = appearance4;
            this.ultraGridPacientes.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance5.BackColor2 = System.Drawing.SystemColors.Control;
            appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance5.ForeColor = System.Drawing.SystemColors.GrayText;
            this.ultraGridPacientes.DisplayLayout.GroupByBox.PromptAppearance = appearance5;
            this.ultraGridPacientes.DisplayLayout.MaxColScrollRegions = 1;
            this.ultraGridPacientes.DisplayLayout.MaxRowScrollRegions = 1;
            appearance6.BackColor = System.Drawing.SystemColors.Window;
            appearance6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.ultraGridPacientes.DisplayLayout.Override.ActiveCellAppearance = appearance6;
            appearance7.BackColor = System.Drawing.SystemColors.Highlight;
            appearance7.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.ultraGridPacientes.DisplayLayout.Override.ActiveRowAppearance = appearance7;
            this.ultraGridPacientes.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.ultraGridPacientes.DisplayLayout.Override.AllowDelete = Infragistics.Win.DefaultableBoolean.False;
            this.ultraGridPacientes.DisplayLayout.Override.AllowUpdate = Infragistics.Win.DefaultableBoolean.False;
            this.ultraGridPacientes.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.ultraGridPacientes.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance8.BackColor = System.Drawing.SystemColors.Window;
            this.ultraGridPacientes.DisplayLayout.Override.CardAreaAppearance = appearance8;
            appearance9.BorderColor = System.Drawing.Color.Silver;
            appearance9.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.ultraGridPacientes.DisplayLayout.Override.CellAppearance = appearance9;
            this.ultraGridPacientes.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.ultraGridPacientes.DisplayLayout.Override.CellPadding = 0;
            appearance10.BackColor = System.Drawing.SystemColors.Control;
            appearance10.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance10.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance10.BorderColor = System.Drawing.SystemColors.Window;
            this.ultraGridPacientes.DisplayLayout.Override.GroupByRowAppearance = appearance10;
            appearance11.TextHAlignAsString = "Left";
            this.ultraGridPacientes.DisplayLayout.Override.HeaderAppearance = appearance11;
            this.ultraGridPacientes.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.ultraGridPacientes.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance12.BackColor = System.Drawing.SystemColors.Window;
            appearance12.BorderColor = System.Drawing.Color.Silver;
            this.ultraGridPacientes.DisplayLayout.Override.RowAppearance = appearance12;
            this.ultraGridPacientes.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance13.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ultraGridPacientes.DisplayLayout.Override.TemplateAddRowAppearance = appearance13;
            this.ultraGridPacientes.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.ultraGridPacientes.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.ultraGridPacientes.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.ultraGridPacientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraGridPacientes.Location = new System.Drawing.Point(6, 82);
            this.ultraGridPacientes.Name = "ultraGridPacientes";
            this.ultraGridPacientes.Size = new System.Drawing.Size(865, 339);
            this.ultraGridPacientes.TabIndex = 9;
            this.ultraGridPacientes.ClickCell += new Infragistics.Win.UltraWinGrid.ClickCellEventHandler(this.ultraGridPacientes_ClickCell);
            this.ultraGridPacientes.DoubleClickCell += new Infragistics.Win.UltraWinGrid.DoubleClickCellEventHandler(this.ultraGridPacientes_DoubleClickCell);
            this.ultraGridPacientes.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ultraGridPacientes_MouseClick);
            // 
            // ultraPanel1
            // 
            appearance14.BackColor = System.Drawing.Color.Silver;
            appearance14.BackColor2 = System.Drawing.Color.DimGray;
            appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.GlassTop20;
            appearance14.BackHatchStyle = Infragistics.Win.BackHatchStyle.DiagonalCross;
            this.ultraPanel1.Appearance = appearance14;
            // 
            // ultraPanel1.ClientArea
            // 
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraGroupBox2);
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraGroupBox1);
            this.ultraPanel1.ClientArea.Controls.Add(this.grpFechas);
            this.ultraPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ultraPanel1.Location = new System.Drawing.Point(0, 0);
            this.ultraPanel1.Name = "ultraPanel1";
            this.ultraPanel1.Size = new System.Drawing.Size(874, 424);
            this.ultraPanel1.TabIndex = 8;
            // 
            // ultraGroupBox2
            // 
            appearance15.BackColor = System.Drawing.Color.Transparent;
            this.ultraGroupBox2.Appearance = appearance15;
            this.ultraGroupBox2.Controls.Add(this.chkFormulario);
            this.ultraGroupBox2.Controls.Add(this.cmbFormulario);
            this.ultraGroupBox2.Controls.Add(this.cmb_tipoatencion);
            this.ultraGroupBox2.Controls.Add(this.chbTipoIngreso);
            this.ultraGroupBox2.Controls.Add(this.chkTratamiento);
            this.ultraGroupBox2.Controls.Add(this.cboTipoIngreso);
            this.ultraGroupBox2.HeaderPosition = Infragistics.Win.Misc.GroupBoxHeaderPosition.TopOutsideBorder;
            this.ultraGroupBox2.Location = new System.Drawing.Point(568, 3);
            this.ultraGroupBox2.Name = "ultraGroupBox2";
            this.ultraGroupBox2.Size = new System.Drawing.Size(299, 72);
            this.ultraGroupBox2.TabIndex = 2;
            this.ultraGroupBox2.Text = "Atenciones:";
            // 
            // chkFormulario
            // 
            this.chkFormulario.AutoSize = true;
            this.chkFormulario.Location = new System.Drawing.Point(10, 71);
            this.chkFormulario.Name = "chkFormulario";
            this.chkFormulario.Size = new System.Drawing.Size(98, 17);
            this.chkFormulario.TabIndex = 7;
            this.chkFormulario.Text = "Tipo Formulario";
            this.chkFormulario.UseVisualStyleBackColor = true;
            this.chkFormulario.Visible = false;
            this.chkFormulario.CheckedChanged += new System.EventHandler(this.chkFormulario_CheckedChanged);
            // 
            // cmbFormulario
            // 
            this.cmbFormulario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFormulario.Enabled = false;
            this.cmbFormulario.FormattingEnabled = true;
            this.cmbFormulario.Items.AddRange(new object[] {
            "ANAMNESIS",
            "EMERGENCIA",
            "EPICRISIS",
            "EVOLUCION",
            "IMAGENOLOGIA",
            "INTERCONSULTA",
            "LABORATORIO",
            "PROTOCOLO"});
            this.cmbFormulario.Location = new System.Drawing.Point(120, 68);
            this.cmbFormulario.Name = "cmbFormulario";
            this.cmbFormulario.Size = new System.Drawing.Size(163, 21);
            this.cmbFormulario.TabIndex = 6;
            this.cmbFormulario.Visible = false;
            // 
            // cmb_tipoatencion
            // 
            this.cmb_tipoatencion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_tipoatencion.Enabled = false;
            this.cmb_tipoatencion.FormattingEnabled = true;
            this.cmb_tipoatencion.Location = new System.Drawing.Point(125, 24);
            this.cmb_tipoatencion.Name = "cmb_tipoatencion";
            this.cmb_tipoatencion.Size = new System.Drawing.Size(163, 21);
            this.cmb_tipoatencion.TabIndex = 5;
            // 
            // chbTipoIngreso
            // 
            this.chbTipoIngreso.AutoSize = true;
            this.chbTipoIngreso.Location = new System.Drawing.Point(15, 48);
            this.chbTipoIngreso.Name = "chbTipoIngreso";
            this.chbTipoIngreso.Size = new System.Drawing.Size(85, 17);
            this.chbTipoIngreso.TabIndex = 4;
            this.chbTipoIngreso.Text = "Tipo Ingreso";
            this.chbTipoIngreso.UseVisualStyleBackColor = true;
            this.chbTipoIngreso.CheckedChanged += new System.EventHandler(this.chbTipoIngreso_CheckedChanged);
            // 
            // chkTratamiento
            // 
            this.chkTratamiento.AutoSize = true;
            this.chkTratamiento.Location = new System.Drawing.Point(15, 27);
            this.chkTratamiento.Name = "chkTratamiento";
            this.chkTratamiento.Size = new System.Drawing.Size(106, 17);
            this.chkTratamiento.TabIndex = 4;
            this.chkTratamiento.Text = "Tipo Tratamiento";
            this.chkTratamiento.UseVisualStyleBackColor = true;
            this.chkTratamiento.CheckedChanged += new System.EventHandler(this.chkTratamiento_CheckedChanged);
            // 
            // cboTipoIngreso
            // 
            this.cboTipoIngreso.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTipoIngreso.Enabled = false;
            this.cboTipoIngreso.FormattingEnabled = true;
            this.cboTipoIngreso.Location = new System.Drawing.Point(125, 45);
            this.cboTipoIngreso.Name = "cboTipoIngreso";
            this.cboTipoIngreso.Size = new System.Drawing.Size(163, 21);
            this.cboTipoIngreso.TabIndex = 2;
            this.cboTipoIngreso.SelectedIndexChanged += new System.EventHandler(this.cboTipoIngreso_SelectedIndexChanged);
            // 
            // ultraGroupBox1
            // 
            appearance17.BackColor = System.Drawing.Color.Transparent;
            this.ultraGroupBox1.Appearance = appearance17;
            this.ultraGroupBox1.Controls.Add(this.label2);
            this.ultraGroupBox1.Controls.Add(this.chkHC);
            this.ultraGroupBox1.Controls.Add(this.ayudaPacientes);
            this.ultraGroupBox1.Controls.Add(this.txt_historiaclinica);
            this.ultraGroupBox1.HeaderPosition = Infragistics.Win.Misc.GroupBoxHeaderPosition.TopOutsideBorder;
            this.ultraGroupBox1.Location = new System.Drawing.Point(340, 3);
            this.ultraGroupBox1.Name = "ultraGroupBox1";
            this.ultraGroupBox1.Size = new System.Drawing.Size(220, 72);
            this.ultraGroupBox1.TabIndex = 1;
            this.ultraGroupBox1.Text = "Paciente:";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(8, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(201, 25);
            this.label2.TabIndex = 273;
            this.label2.Text = "[Escriba el numero de historia clinica o presione F1 para buscar por nombre.]";
            this.label2.Visible = false;
            // 
            // chkHC
            // 
            this.chkHC.AutoSize = true;
            this.chkHC.Location = new System.Drawing.Point(12, 37);
            this.chkHC.Name = "chkHC";
            this.chkHC.Size = new System.Drawing.Size(90, 17);
            this.chkHC.TabIndex = 272;
            this.chkHC.Text = "Nro. Historia :";
            this.chkHC.UseVisualStyleBackColor = true;
            this.chkHC.CheckedChanged += new System.EventHandler(this.chkHC_CheckedChanged);
            // 
            // ayudaPacientes
            // 
            appearance50.ForeColor = System.Drawing.Color.Navy;
            appearance50.TextHAlignAsString = "Center";
            appearance50.TextVAlignAsString = "Middle";
            this.ayudaPacientes.Appearance = appearance50;
            this.ayudaPacientes.ButtonStyle = Infragistics.Win.UIElementButtonStyle.WindowsXPCommandButton;
            this.ayudaPacientes.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ayudaPacientes.Location = new System.Drawing.Point(177, 32);
            this.ayudaPacientes.Name = "ayudaPacientes";
            this.ayudaPacientes.Size = new System.Drawing.Size(30, 21);
            this.ayudaPacientes.TabIndex = 271;
            this.ayudaPacientes.TabStop = false;
            this.ayudaPacientes.Text = "F1";
            this.ayudaPacientes.Visible = false;
            this.ayudaPacientes.Click += new System.EventHandler(this.ayudaPacientes_Click);
            // 
            // txt_historiaclinica
            // 
            this.txt_historiaclinica.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_historiaclinica.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_historiaclinica.Enabled = false;
            this.txt_historiaclinica.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_historiaclinica.Location = new System.Drawing.Point(104, 31);
            this.txt_historiaclinica.MaxLength = 6;
            this.txt_historiaclinica.Name = "txt_historiaclinica";
            this.txt_historiaclinica.Size = new System.Drawing.Size(67, 24);
            this.txt_historiaclinica.TabIndex = 269;
            this.txt_historiaclinica.Tag = "false";
            this.txt_historiaclinica.Text = "0";
            this.txt_historiaclinica.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_historiaclinica_KeyPress);
            this.txt_historiaclinica.Leave += new System.EventHandler(this.txt_historiaclinica_Leave);
            // 
            // grpFechas
            // 
            appearance16.BackColor = System.Drawing.Color.Transparent;
            this.grpFechas.Appearance = appearance16;
            this.grpFechas.Controls.Add(this.chkFacturacion);
            this.grpFechas.Controls.Add(this.chkAlta);
            this.grpFechas.Controls.Add(this.chkIngreso);
            this.grpFechas.Controls.Add(this.label1);
            this.grpFechas.Controls.Add(this.lblHasta);
            this.grpFechas.Controls.Add(this.dtpFiltroHasta);
            this.grpFechas.Controls.Add(this.dtpFiltroDesde);
            this.grpFechas.HeaderPosition = Infragistics.Win.Misc.GroupBoxHeaderPosition.TopOutsideBorder;
            this.grpFechas.Location = new System.Drawing.Point(6, 3);
            this.grpFechas.Name = "grpFechas";
            this.grpFechas.Size = new System.Drawing.Size(327, 72);
            this.grpFechas.TabIndex = 0;
            this.grpFechas.Text = "Fecha de pedido:";
            // 
            // chkFacturacion
            // 
            this.chkFacturacion.AutoSize = true;
            this.chkFacturacion.Location = new System.Drawing.Point(11, 65);
            this.chkFacturacion.Name = "chkFacturacion";
            this.chkFacturacion.Size = new System.Drawing.Size(82, 17);
            this.chkFacturacion.TabIndex = 10;
            this.chkFacturacion.Text = "Facturacion";
            this.chkFacturacion.UseVisualStyleBackColor = true;
            this.chkFacturacion.Visible = false;
            // 
            // chkAlta
            // 
            this.chkAlta.AutoSize = true;
            this.chkAlta.Location = new System.Drawing.Point(11, 66);
            this.chkAlta.Name = "chkAlta";
            this.chkAlta.Size = new System.Drawing.Size(89, 17);
            this.chkAlta.TabIndex = 9;
            this.chkAlta.Text = "Alta Paciente";
            this.chkAlta.UseVisualStyleBackColor = true;
            this.chkAlta.Visible = false;
            // 
            // chkIngreso
            // 
            this.chkIngreso.AutoSize = true;
            this.chkIngreso.Location = new System.Drawing.Point(11, 63);
            this.chkIngreso.Name = "chkIngreso";
            this.chkIngreso.Size = new System.Drawing.Size(106, 17);
            this.chkIngreso.TabIndex = 8;
            this.chkIngreso.Text = "Ingreso Paciente";
            this.chkIngreso.UseVisualStyleBackColor = true;
            this.chkIngreso.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Desde:";
            // 
            // lblHasta
            // 
            this.lblHasta.AutoSize = true;
            this.lblHasta.Location = new System.Drawing.Point(164, 41);
            this.lblHasta.Name = "lblHasta";
            this.lblHasta.Size = new System.Drawing.Size(38, 13);
            this.lblHasta.TabIndex = 6;
            this.lblHasta.Text = "Hasta:";
            // 
            // dtpFiltroHasta
            // 
            this.dtpFiltroHasta.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFiltroHasta.Location = new System.Drawing.Point(205, 36);
            this.dtpFiltroHasta.Name = "dtpFiltroHasta";
            this.dtpFiltroHasta.Size = new System.Drawing.Size(87, 20);
            this.dtpFiltroHasta.TabIndex = 4;
            // 
            // dtpFiltroDesde
            // 
            this.dtpFiltroDesde.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFiltroDesde.Location = new System.Drawing.Point(56, 35);
            this.dtpFiltroDesde.Name = "dtpFiltroDesde";
            this.dtpFiltroDesde.Size = new System.Drawing.Size(91, 20);
            this.dtpFiltroDesde.TabIndex = 3;
            this.dtpFiltroDesde.Value = new System.DateTime(2010, 1, 1, 0, 0, 0, 0);
            // 
            // MnuCtxHC
            // 
            this.MnuCtxHC.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.detalleToolStripMenuItem,
            this.formulariosToolStripMenuItem,
            this.microfilmDeHCToolStripMenuItem,
            this.historiaClinicaToolStripMenuItem});
            this.MnuCtxHC.Name = "atencionContextMenuStrip";
            this.MnuCtxHC.Size = new System.Drawing.Size(166, 92);
            // 
            // detalleToolStripMenuItem
            // 
            this.detalleToolStripMenuItem.Name = "detalleToolStripMenuItem";
            this.detalleToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.detalleToolStripMenuItem.Text = "Detalle";
            this.detalleToolStripMenuItem.Visible = false;
            // 
            // formulariosToolStripMenuItem
            // 
            this.formulariosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aniadirToolStripMenuItem});
            this.formulariosToolStripMenuItem.Name = "formulariosToolStripMenuItem";
            this.formulariosToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.formulariosToolStripMenuItem.Text = "Formularios";
            this.formulariosToolStripMenuItem.Visible = false;
            // 
            // aniadirToolStripMenuItem
            // 
            this.aniadirToolStripMenuItem.Name = "aniadirToolStripMenuItem";
            this.aniadirToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.aniadirToolStripMenuItem.Text = "Añadir";
            // 
            // microfilmDeHCToolStripMenuItem
            // 
            this.microfilmDeHCToolStripMenuItem.Name = "microfilmDeHCToolStripMenuItem";
            this.microfilmDeHCToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.microfilmDeHCToolStripMenuItem.Text = "Microfilm de HC ";
            this.microfilmDeHCToolStripMenuItem.Visible = false;
            // 
            // historiaClinicaToolStripMenuItem
            // 
            this.historiaClinicaToolStripMenuItem.Name = "historiaClinicaToolStripMenuItem";
            this.historiaClinicaToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.historiaClinicaToolStripMenuItem.Text = "Historia Clinica";
            this.historiaClinicaToolStripMenuItem.Click += new System.EventHandler(this.historiaClinicaToolStripMenuItem_Click);
            // 
            // pacienteContextMenuStrip
            // 
            this.pacienteContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.atencionToolStripMenuItem,
            this.estadoDeCuentaToolStripMenuItem});
            this.pacienteContextMenuStrip.Name = "pacienteContextMenuStrip";
            this.pacienteContextMenuStrip.Size = new System.Drawing.Size(167, 48);
            // 
            // atencionToolStripMenuItem
            // 
            this.atencionToolStripMenuItem.Name = "atencionToolStripMenuItem";
            this.atencionToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.atencionToolStripMenuItem.Text = "Nueva Atención";
            // 
            // estadoDeCuentaToolStripMenuItem
            // 
            this.estadoDeCuentaToolStripMenuItem.Name = "estadoDeCuentaToolStripMenuItem";
            this.estadoDeCuentaToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.estadoDeCuentaToolStripMenuItem.Text = "Estado de Cuenta";
            // 
            // frm_ExploradorFormularios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(874, 469);
            this.Controls.Add(this.frm_ExploraPacientes_Fill_Panel);
            this.Controls.Add(this.tools);
            this.Name = "frm_ExploradorFormularios";
            this.Text = "Pedidos de Imagen";
            this.Load += new System.EventHandler(this.ExploradorFormularios_Load);
            this.tools.ResumeLayout(false);
            this.tools.PerformLayout();
            this.frm_ExploraPacientes_Fill_Panel.ClientArea.ResumeLayout(false);
            this.frm_ExploraPacientes_Fill_Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraGridPacientes)).EndInit();
            this.ultraPanel1.ClientArea.ResumeLayout(false);
            this.ultraPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox2)).EndInit();
            this.ultraGroupBox2.ResumeLayout(false);
            this.ultraGroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox1)).EndInit();
            this.ultraGroupBox1.ResumeLayout(false);
            this.ultraGroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grpFechas)).EndInit();
            this.grpFechas.ResumeLayout(false);
            this.grpFechas.PerformLayout();
            this.MnuCtxHC.ResumeLayout(false);
            this.pacienteContextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStrip tools;
        private System.Windows.Forms.ToolStripButton toolStripButtonActualizar;
        private System.Windows.Forms.ToolStripButton toolStripButtonBuscar;
        private System.Windows.Forms.ToolStripButton toolStripButtonSalir;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private Infragistics.Win.Misc.UltraPanel frm_ExploraPacientes_Fill_Panel;
        private Infragistics.Win.UltraWinGrid.UltraGrid ultraGridPacientes;
        private Infragistics.Win.Misc.UltraPanel ultraPanel1;
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox2;
        private System.Windows.Forms.CheckBox chkTratamiento;
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox1;
        private System.Windows.Forms.CheckBox chbTipoIngreso;
        private System.Windows.Forms.ComboBox cboTipoIngreso;
        private Infragistics.Win.Misc.UltraGroupBox grpFechas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblHasta;
        private System.Windows.Forms.DateTimePicker dtpFiltroHasta;
        private System.Windows.Forms.DateTimePicker dtpFiltroDesde;
        private System.Windows.Forms.ContextMenuStrip MnuCtxHC;
        private System.Windows.Forms.ToolStripMenuItem detalleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formulariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aniadirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem microfilmDeHCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historiaClinicaToolStripMenuItem;
        private Infragistics.Win.UltraWinGrid.ExcelExport.UltraGridExcelExporter ultraGridExcelExporter1;
        private System.Windows.Forms.ContextMenuStrip pacienteContextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem atencionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estadoDeCuentaToolStripMenuItem;
        private System.Windows.Forms.CheckBox chkFacturacion;
        private System.Windows.Forms.CheckBox chkAlta;
        private System.Windows.Forms.CheckBox chkIngreso;
        private Infragistics.Win.Misc.UltraButton ayudaPacientes;
        private System.Windows.Forms.CheckBox chkHC;
        private System.Windows.Forms.ComboBox cmb_tipoatencion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chkFormulario;
        private System.Windows.Forms.ComboBox cmbFormulario;
        public System.Windows.Forms.TextBox txt_historiaclinica;
    }
}