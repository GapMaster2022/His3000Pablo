﻿namespace His.Dietetica
{
    partial class ImagenExamenes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ImagenExamenes));
            Infragistics.Win.Appearance appearance67 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            this.tools = new System.Windows.Forms.ToolStrip();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.ultraGroupBox6 = new Infragistics.Win.Misc.UltraGroupBox();
            this.chkMedioContraste = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ultraGroupBox10 = new Infragistics.Win.Misc.UltraGroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.dtpDesde = new System.Windows.Forms.DateTimePicker();
            this.txtPaciente = new System.Windows.Forms.TextBox();
            this.txtIngreso = new System.Windows.Forms.TextBox();
            this.txtHC = new System.Windows.Forms.TextBox();
            this.txtAtencion = new System.Windows.Forms.TextBox();
            this.txtPEnviadas = new System.Windows.Forms.MaskedTextBox();
            this.txtPDanada = new System.Windows.Forms.MaskedTextBox();
            this.txtPOdonto = new System.Windows.Forms.MaskedTextBox();
            this.txt30x40 = new System.Windows.Forms.MaskedTextBox();
            this.txt8x10 = new System.Windows.Forms.MaskedTextBox();
            this.txt14x14 = new System.Windows.Forms.MaskedTextBox();
            this.txt14x17 = new System.Windows.Forms.MaskedTextBox();
            this.txt18x24 = new System.Windows.Forms.MaskedTextBox();
            this.tools.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox6)).BeginInit();
            this.ultraGroupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox10)).BeginInit();
            this.ultraGroupBox10.SuspendLayout();
            this.SuspendLayout();
            // 
            // tools
            // 
            this.tools.AutoSize = false;
            this.tools.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton3,
            this.toolStripButton4});
            this.tools.Location = new System.Drawing.Point(0, 0);
            this.tools.Name = "tools";
            this.tools.Size = new System.Drawing.Size(405, 45);
            this.tools.TabIndex = 81;
            this.tools.Text = "toolStrip1";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.AutoSize = false;
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(42, 42);
            this.toolStripButton3.Text = "toolStripButton1";
            this.toolStripButton3.ToolTipText = "Guardar";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.AutoSize = false;
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(42, 42);
            this.toolStripButton4.Text = "toolStripButton1";
            this.toolStripButton4.ToolTipText = "Cancelar";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // ultraGroupBox6
            // 
            this.ultraGroupBox6.Controls.Add(this.txt18x24);
            this.ultraGroupBox6.Controls.Add(this.txt14x17);
            this.ultraGroupBox6.Controls.Add(this.txt14x14);
            this.ultraGroupBox6.Controls.Add(this.txt8x10);
            this.ultraGroupBox6.Controls.Add(this.txt30x40);
            this.ultraGroupBox6.Controls.Add(this.txtPOdonto);
            this.ultraGroupBox6.Controls.Add(this.txtPDanada);
            this.ultraGroupBox6.Controls.Add(this.txtPEnviadas);
            this.ultraGroupBox6.Controls.Add(this.dtpDesde);
            this.ultraGroupBox6.Controls.Add(this.label13);
            this.ultraGroupBox6.Controls.Add(this.chkMedioContraste);
            this.ultraGroupBox6.Controls.Add(this.label9);
            this.ultraGroupBox6.Controls.Add(this.label7);
            this.ultraGroupBox6.Controls.Add(this.label6);
            this.ultraGroupBox6.Controls.Add(this.label5);
            this.ultraGroupBox6.Controls.Add(this.label4);
            this.ultraGroupBox6.Controls.Add(this.label2);
            this.ultraGroupBox6.Controls.Add(this.label1);
            this.ultraGroupBox6.Controls.Add(this.label3);
            this.ultraGroupBox6.ForeColor = System.Drawing.Color.Black;
            appearance67.FontData.BoldAsString = "True";
            appearance67.ForeColor = System.Drawing.Color.DimGray;
            this.ultraGroupBox6.HeaderAppearance = appearance67;
            this.ultraGroupBox6.Location = new System.Drawing.Point(18, 161);
            this.ultraGroupBox6.Name = "ultraGroupBox6";
            this.ultraGroupBox6.Size = new System.Drawing.Size(378, 207);
            this.ultraGroupBox6.TabIndex = 82;
            this.ultraGroupBox6.Text = "ESTUDIO REALIZADO";
            // 
            // chkMedioContraste
            // 
            this.chkMedioContraste.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkMedioContraste.AutoSize = true;
            this.chkMedioContraste.BackColor = System.Drawing.Color.Transparent;
            this.chkMedioContraste.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkMedioContraste.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.chkMedioContraste.ForeColor = System.Drawing.Color.Black;
            this.chkMedioContraste.Location = new System.Drawing.Point(15, 165);
            this.chkMedioContraste.Name = "chkMedioContraste";
            this.chkMedioContraste.Size = new System.Drawing.Size(174, 17);
            this.chkMedioContraste.TabIndex = 9;
            this.chkMedioContraste.Text = "CON MEDIO DE CONTRASTE";
            this.chkMedioContraste.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Location = new System.Drawing.Point(22, 101);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 13);
            this.label9.TabIndex = 87;
            this.label9.Text = "PLACAS DAÑADAS";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Location = new System.Drawing.Point(25, 134);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 13);
            this.label7.TabIndex = 86;
            this.label7.Text = "ODONTOLOGICAS";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Location = new System.Drawing.Point(222, 167);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 85;
            this.label6.Text = "18 X 24";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(222, 144);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 84;
            this.label5.Text = "14 X 17";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(222, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 83;
            this.label4.Text = "14 X 14";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(228, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 82;
            this.label2.Text = "8 X 10";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(222, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 81;
            this.label1.Text = "30 X 40";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(22, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 13);
            this.label3.TabIndex = 80;
            this.label3.Text = "PLACAS ENVIADAS";
            // 
            // ultraGroupBox10
            // 
            this.ultraGroupBox10.Controls.Add(this.txtAtencion);
            this.ultraGroupBox10.Controls.Add(this.txtHC);
            this.ultraGroupBox10.Controls.Add(this.txtIngreso);
            this.ultraGroupBox10.Controls.Add(this.txtPaciente);
            this.ultraGroupBox10.Controls.Add(this.label12);
            this.ultraGroupBox10.Controls.Add(this.label11);
            this.ultraGroupBox10.Controls.Add(this.label10);
            this.ultraGroupBox10.Controls.Add(this.label8);
            this.ultraGroupBox10.ForeColor = System.Drawing.Color.Black;
            appearance24.FontData.BoldAsString = "True";
            appearance24.ForeColor = System.Drawing.Color.DimGray;
            appearance24.TextHAlignAsString = "Right";
            this.ultraGroupBox10.HeaderAppearance = appearance24;
            this.ultraGroupBox10.HeaderPosition = Infragistics.Win.Misc.GroupBoxHeaderPosition.TopOnBorder;
            this.ultraGroupBox10.Location = new System.Drawing.Point(18, 48);
            this.ultraGroupBox10.Name = "ultraGroupBox10";
            this.ultraGroupBox10.Size = new System.Drawing.Size(372, 107);
            this.ultraGroupBox10.TabIndex = 98;
            this.ultraGroupBox10.Text = "DATOS DEL PACIENTE:";
            this.ultraGroupBox10.ViewStyle = Infragistics.Win.Misc.GroupBoxViewStyle.XP;
            this.ultraGroupBox10.Click += new System.EventHandler(this.ultraGroupBox10_Click);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(30, 29);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 19);
            this.label8.TabIndex = 96;
            this.label8.Text = "Paciente:";
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(30, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 19);
            this.label10.TabIndex = 97;
            this.label10.Text = "HC:";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(203, 51);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 19);
            this.label11.TabIndex = 98;
            this.label11.Text = "Atencion:";
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(28, 71);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 19);
            this.label12.TabIndex = 99;
            this.label12.Text = "Ingreso:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Location = new System.Drawing.Point(30, 30);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 13);
            this.label13.TabIndex = 97;
            this.label13.Text = "FECHA Y HORA:";
            // 
            // dtpDesde
            // 
            this.dtpDesde.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.dtpDesde.CalendarTitleForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.dtpDesde.CustomFormat = "dd-MM-yyyy HH:mm";
            this.dtpDesde.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDesde.Location = new System.Drawing.Point(150, 24);
            this.dtpDesde.Name = "dtpDesde";
            this.dtpDesde.Size = new System.Drawing.Size(122, 20);
            this.dtpDesde.TabIndex = 5;
            this.dtpDesde.Value = new System.DateTime(2010, 10, 16, 0, 0, 0, 0);
            // 
            // txtPaciente
            // 
            this.txtPaciente.BackColor = System.Drawing.SystemColors.Window;
            this.txtPaciente.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPaciente.Location = new System.Drawing.Point(87, 25);
            this.txtPaciente.MaxLength = 20;
            this.txtPaciente.Name = "txtPaciente";
            this.txtPaciente.ReadOnly = true;
            this.txtPaciente.Size = new System.Drawing.Size(269, 20);
            this.txtPaciente.TabIndex = 1;
            // 
            // txtIngreso
            // 
            this.txtIngreso.BackColor = System.Drawing.SystemColors.Window;
            this.txtIngreso.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtIngreso.Location = new System.Drawing.Point(87, 70);
            this.txtIngreso.MaxLength = 20;
            this.txtIngreso.Name = "txtIngreso";
            this.txtIngreso.ReadOnly = true;
            this.txtIngreso.Size = new System.Drawing.Size(112, 20);
            this.txtIngreso.TabIndex = 4;
            // 
            // txtHC
            // 
            this.txtHC.BackColor = System.Drawing.SystemColors.Window;
            this.txtHC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtHC.Location = new System.Drawing.Point(87, 48);
            this.txtHC.MaxLength = 20;
            this.txtHC.Name = "txtHC";
            this.txtHC.ReadOnly = true;
            this.txtHC.Size = new System.Drawing.Size(112, 20);
            this.txtHC.TabIndex = 2;
            // 
            // txtAtencion
            // 
            this.txtAtencion.BackColor = System.Drawing.SystemColors.Window;
            this.txtAtencion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAtencion.Location = new System.Drawing.Point(265, 47);
            this.txtAtencion.MaxLength = 20;
            this.txtAtencion.Name = "txtAtencion";
            this.txtAtencion.ReadOnly = true;
            this.txtAtencion.Size = new System.Drawing.Size(91, 20);
            this.txtAtencion.TabIndex = 3;
            // 
            // txtPEnviadas
            // 
            this.txtPEnviadas.Location = new System.Drawing.Point(150, 64);
            this.txtPEnviadas.Mask = "99";
            this.txtPEnviadas.Name = "txtPEnviadas";
            this.txtPEnviadas.Size = new System.Drawing.Size(40, 20);
            this.txtPEnviadas.TabIndex = 6;
            this.txtPEnviadas.ValidatingType = typeof(int);
            // 
            // txtPDanada
            // 
            this.txtPDanada.Location = new System.Drawing.Point(150, 98);
            this.txtPDanada.Mask = "99";
            this.txtPDanada.Name = "txtPDanada";
            this.txtPDanada.Size = new System.Drawing.Size(40, 20);
            this.txtPDanada.TabIndex = 7;
            this.txtPDanada.ValidatingType = typeof(int);
            // 
            // txtPOdonto
            // 
            this.txtPOdonto.Location = new System.Drawing.Point(150, 127);
            this.txtPOdonto.Mask = "99";
            this.txtPOdonto.Name = "txtPOdonto";
            this.txtPOdonto.Size = new System.Drawing.Size(40, 20);
            this.txtPOdonto.TabIndex = 8;
            this.txtPOdonto.ValidatingType = typeof(int);
            // 
            // txt30x40
            // 
            this.txt30x40.Location = new System.Drawing.Point(291, 60);
            this.txt30x40.Mask = "99";
            this.txt30x40.Name = "txt30x40";
            this.txt30x40.Size = new System.Drawing.Size(40, 20);
            this.txt30x40.TabIndex = 10;
            this.txt30x40.ValidatingType = typeof(int);
            // 
            // txt8x10
            // 
            this.txt8x10.Location = new System.Drawing.Point(291, 86);
            this.txt8x10.Mask = "99";
            this.txt8x10.Name = "txt8x10";
            this.txt8x10.Size = new System.Drawing.Size(40, 20);
            this.txt8x10.TabIndex = 11;
            this.txt8x10.ValidatingType = typeof(int);
            // 
            // txt14x14
            // 
            this.txt14x14.Location = new System.Drawing.Point(291, 110);
            this.txt14x14.Mask = "99";
            this.txt14x14.Name = "txt14x14";
            this.txt14x14.Size = new System.Drawing.Size(40, 20);
            this.txt14x14.TabIndex = 12;
            this.txt14x14.ValidatingType = typeof(int);
            // 
            // txt14x17
            // 
            this.txt14x17.Location = new System.Drawing.Point(291, 137);
            this.txt14x17.Mask = "99";
            this.txt14x17.Name = "txt14x17";
            this.txt14x17.Size = new System.Drawing.Size(40, 20);
            this.txt14x17.TabIndex = 13;
            this.txt14x17.ValidatingType = typeof(int);
            // 
            // txt18x24
            // 
            this.txt18x24.Location = new System.Drawing.Point(291, 163);
            this.txt18x24.Mask = "99";
            this.txt18x24.Name = "txt18x24";
            this.txt18x24.Size = new System.Drawing.Size(40, 20);
            this.txt18x24.TabIndex = 14;
            this.txt18x24.ValidatingType = typeof(int);
            // 
            // ImagenExamenes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 376);
            this.Controls.Add(this.ultraGroupBox10);
            this.Controls.Add(this.ultraGroupBox6);
            this.Controls.Add(this.tools);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "ImagenExamenes";
            this.Text = "ImagenExamenes";
            this.tools.ResumeLayout(false);
            this.tools.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox6)).EndInit();
            this.ultraGroupBox6.ResumeLayout(false);
            this.ultraGroupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox10)).EndInit();
            this.ultraGroupBox10.ResumeLayout(false);
            this.ultraGroupBox10.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStrip tools;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox6;
        private System.Windows.Forms.CheckBox chkMedioContraste;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dtpDesde;
        private System.Windows.Forms.TextBox txtPaciente;
        private System.Windows.Forms.TextBox txtAtencion;
        private System.Windows.Forms.TextBox txtHC;
        private System.Windows.Forms.TextBox txtIngreso;
        private System.Windows.Forms.MaskedTextBox txtPEnviadas;
        private System.Windows.Forms.MaskedTextBox txt18x24;
        private System.Windows.Forms.MaskedTextBox txt14x17;
        private System.Windows.Forms.MaskedTextBox txt14x14;
        private System.Windows.Forms.MaskedTextBox txt8x10;
        private System.Windows.Forms.MaskedTextBox txt30x40;
        private System.Windows.Forms.MaskedTextBox txtPOdonto;
        private System.Windows.Forms.MaskedTextBox txtPDanada;
    }
}