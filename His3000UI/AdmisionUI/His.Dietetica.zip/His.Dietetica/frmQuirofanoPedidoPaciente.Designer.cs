﻿namespace His.Dietetica
{
    partial class frmQuirofanoPedidoPaciente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmQuirofanoPedidoPaciente));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tools = new System.Windows.Forms.ToolStrip();
            this.toolStripAgregar = new System.Windows.Forms.ToolStripButton();
            this.btnGuardar = new System.Windows.Forms.ToolStripButton();
            this.btnadicional = new System.Windows.Forms.ToolStripButton();
            this.btnEditar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripRegistro = new System.Windows.Forms.ToolStripButton();
            this.toolStripDespachar = new System.Windows.Forms.ToolStripButton();
            this.toolStripCerrar = new System.Windows.Forms.ToolStripButton();
            this.btncancelar = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonSalir = new System.Windows.Forms.ToolStripButton();
            this.TablaProcedimientos = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblpaciente = new System.Windows.Forms.Label();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btnenter = new System.Windows.Forms.Button();
            this.panelTecladoNumerico = new System.Windows.Forms.Panel();
            this.btnborrar = new System.Windows.Forms.Button();
            this.lblcantoriginal = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblcantusada = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblmedico = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblseguro = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbltipo = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblreferido = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblgenero = new System.Windows.Forms.Label();
            this.panelPaciente = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.cmbProcedimiento = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label31 = new System.Windows.Forms.Label();
            this.lblduracion = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.lblhf = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lblhi = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lblfecha = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblinstrumentista = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.lblpatologo = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbltipoanestesia = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblcirujano = new System.Windows.Forms.Label();
            this.lblayudante = new System.Windows.Forms.Label();
            this.lblayudantia = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblanestesiologo = new System.Windows.Forms.Label();
            this.lblcirculante = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lblatencion = new System.Windows.Forms.Label();
            this.tools.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TablaProcedimientos)).BeginInit();
            this.panelTecladoNumerico.SuspendLayout();
            this.panelPaciente.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tools
            // 
            this.tools.AutoSize = false;
            this.tools.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripAgregar,
            this.btnGuardar,
            this.btnadicional,
            this.btnEditar,
            this.toolStripSeparator1,
            this.toolStripRegistro,
            this.toolStripDespachar,
            this.toolStripCerrar,
            this.btncancelar,
            this.toolStripButtonSalir});
            this.tools.Location = new System.Drawing.Point(0, 0);
            this.tools.Name = "tools";
            this.tools.Size = new System.Drawing.Size(1235, 45);
            this.tools.TabIndex = 79;
            this.tools.Text = "toolStrip1";
            // 
            // toolStripAgregar
            // 
            this.toolStripAgregar.AutoSize = false;
            this.toolStripAgregar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripAgregar.Image = ((System.Drawing.Image)(resources.GetObject("toolStripAgregar.Image")));
            this.toolStripAgregar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripAgregar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAgregar.Name = "toolStripAgregar";
            this.toolStripAgregar.Size = new System.Drawing.Size(42, 42);
            this.toolStripAgregar.Text = "Agregar Producto";
            this.toolStripAgregar.ToolTipText = "Agregar Producto";
            this.toolStripAgregar.Click += new System.EventHandler(this.toolStripAgregar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.AutoSize = false;
            this.btnGuardar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnGuardar.Image = ((System.Drawing.Image)(resources.GetObject("btnGuardar.Image")));
            this.btnGuardar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnGuardar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(42, 42);
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.ToolTipText = "Guardar";
            this.btnGuardar.Click += new System.EventHandler(this.toolStripButtonActualizar_Click);
            // 
            // btnadicional
            // 
            this.btnadicional.AutoSize = false;
            this.btnadicional.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnadicional.Image = ((System.Drawing.Image)(resources.GetObject("btnadicional.Image")));
            this.btnadicional.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnadicional.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnadicional.Name = "btnadicional";
            this.btnadicional.Size = new System.Drawing.Size(42, 42);
            this.btnadicional.Text = "Pedir Adicional";
            this.btnadicional.ToolTipText = "Pedir Adicional";
            this.btnadicional.Click += new System.EventHandler(this.btnadicional_Click);
            // 
            // btnEditar
            // 
            this.btnEditar.AutoSize = false;
            this.btnEditar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnEditar.Image = ((System.Drawing.Image)(resources.GetObject("btnEditar.Image")));
            this.btnEditar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnEditar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(42, 42);
            this.btnEditar.Text = "Editar Devolución";
            this.btnEditar.ToolTipText = "Editar Devolución";
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 45);
            // 
            // toolStripRegistro
            // 
            this.toolStripRegistro.AutoSize = false;
            this.toolStripRegistro.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripRegistro.Image = ((System.Drawing.Image)(resources.GetObject("toolStripRegistro.Image")));
            this.toolStripRegistro.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripRegistro.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripRegistro.Name = "toolStripRegistro";
            this.toolStripRegistro.Size = new System.Drawing.Size(42, 42);
            this.toolStripRegistro.Text = "Ver Registro";
            this.toolStripRegistro.ToolTipText = "Ver Registro";
            this.toolStripRegistro.Visible = false;
            this.toolStripRegistro.Click += new System.EventHandler(this.toolStripRegistro_Click);
            // 
            // toolStripDespachar
            // 
            this.toolStripDespachar.AutoSize = false;
            this.toolStripDespachar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDespachar.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDespachar.Image")));
            this.toolStripDespachar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripDespachar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDespachar.Name = "toolStripDespachar";
            this.toolStripDespachar.Size = new System.Drawing.Size(42, 42);
            this.toolStripDespachar.Text = "Despachar";
            this.toolStripDespachar.ToolTipText = "Despachar";
            this.toolStripDespachar.Click += new System.EventHandler(this.toolStripDespachar_Click);
            // 
            // toolStripCerrar
            // 
            this.toolStripCerrar.AutoSize = false;
            this.toolStripCerrar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripCerrar.Image = ((System.Drawing.Image)(resources.GetObject("toolStripCerrar.Image")));
            this.toolStripCerrar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripCerrar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripCerrar.Name = "toolStripCerrar";
            this.toolStripCerrar.Size = new System.Drawing.Size(42, 42);
            this.toolStripCerrar.Text = "Cerrar";
            this.toolStripCerrar.ToolTipText = "Cerrar Procedimiento";
            this.toolStripCerrar.Click += new System.EventHandler(this.toolStripCerrar_Click);
            // 
            // btncancelar
            // 
            this.btncancelar.AutoSize = false;
            this.btncancelar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btncancelar.Image = ((System.Drawing.Image)(resources.GetObject("btncancelar.Image")));
            this.btncancelar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btncancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btncancelar.Name = "btncancelar";
            this.btncancelar.Size = new System.Drawing.Size(42, 42);
            this.btncancelar.Text = "Cancelar";
            this.btncancelar.ToolTipText = "Cancelar";
            this.btncancelar.Click += new System.EventHandler(this.btncancelar_Click);
            // 
            // toolStripButtonSalir
            // 
            this.toolStripButtonSalir.AutoSize = false;
            this.toolStripButtonSalir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonSalir.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSalir.Image")));
            this.toolStripButtonSalir.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonSalir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSalir.Name = "toolStripButtonSalir";
            this.toolStripButtonSalir.Size = new System.Drawing.Size(42, 42);
            this.toolStripButtonSalir.Text = "toolStripButton1";
            this.toolStripButtonSalir.ToolTipText = "Salir";
            this.toolStripButtonSalir.Click += new System.EventHandler(this.toolStripButtonSalir_Click);
            // 
            // TablaProcedimientos
            // 
            this.TablaProcedimientos.AllowUserToAddRows = false;
            this.TablaProcedimientos.AllowUserToDeleteRows = false;
            this.TablaProcedimientos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TablaProcedimientos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.TablaProcedimientos.BackgroundColor = System.Drawing.Color.White;
            this.TablaProcedimientos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.TablaProcedimientos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.TablaProcedimientos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TablaProcedimientos.Location = new System.Drawing.Point(0, 343);
            this.TablaProcedimientos.Name = "TablaProcedimientos";
            this.TablaProcedimientos.RowHeadersVisible = false;
            this.TablaProcedimientos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.TablaProcedimientos.Size = new System.Drawing.Size(965, 289);
            this.TablaProcedimientos.TabIndex = 80;
            this.TablaProcedimientos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.TablaProcedimientos_CellClick);
            this.TablaProcedimientos.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.TablaProcedimientos_CellEnter);
            this.TablaProcedimientos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TablaProcedimientos_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 16);
            this.label1.TabIndex = 81;
            this.label1.Text = "Paciente:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(797, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 16);
            this.label2.TabIndex = 82;
            this.label2.Text = "Procedimiento:";
            // 
            // lblpaciente
            // 
            this.lblpaciente.AutoSize = true;
            this.lblpaciente.Location = new System.Drawing.Point(85, 27);
            this.lblpaciente.Name = "lblpaciente";
            this.lblpaciente.Size = new System.Drawing.Size(35, 13);
            this.lblpaciente.TabIndex = 83;
            this.lblpaciente.Text = "label3";
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btn7.FlatAppearance.BorderSize = 0;
            this.btn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7.Location = new System.Drawing.Point(12, 13);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(75, 40);
            this.btn7.TabIndex = 85;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btn8.FlatAppearance.BorderSize = 0;
            this.btn8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.Location = new System.Drawing.Point(93, 13);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(75, 40);
            this.btn8.TabIndex = 86;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btn9.FlatAppearance.BorderSize = 0;
            this.btn9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.Location = new System.Drawing.Point(174, 13);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(75, 40);
            this.btn9.TabIndex = 87;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btn4.FlatAppearance.BorderSize = 0;
            this.btn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4.Location = new System.Drawing.Point(12, 59);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(75, 40);
            this.btn4.TabIndex = 88;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btn5.FlatAppearance.BorderSize = 0;
            this.btn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5.Location = new System.Drawing.Point(93, 59);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(75, 40);
            this.btn5.TabIndex = 89;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btn6.FlatAppearance.BorderSize = 0;
            this.btn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.Location = new System.Drawing.Point(174, 59);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(75, 40);
            this.btn6.TabIndex = 90;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btn1.FlatAppearance.BorderSize = 0;
            this.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.Location = new System.Drawing.Point(12, 105);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(75, 40);
            this.btn1.TabIndex = 91;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btn2.FlatAppearance.BorderSize = 0;
            this.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.Location = new System.Drawing.Point(93, 105);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(75, 40);
            this.btn2.TabIndex = 92;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btn3.FlatAppearance.BorderSize = 0;
            this.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.Location = new System.Drawing.Point(174, 105);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(75, 40);
            this.btn3.TabIndex = 93;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn0
            // 
            this.btn0.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btn0.FlatAppearance.BorderSize = 0;
            this.btn0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn0.Location = new System.Drawing.Point(12, 151);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(75, 40);
            this.btn0.TabIndex = 94;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = false;
            this.btn0.Click += new System.EventHandler(this.btn0_Click);
            // 
            // btnenter
            // 
            this.btnenter.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btnenter.FlatAppearance.BorderSize = 0;
            this.btnenter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnenter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnenter.Location = new System.Drawing.Point(93, 151);
            this.btnenter.Name = "btnenter";
            this.btnenter.Size = new System.Drawing.Size(156, 40);
            this.btnenter.TabIndex = 95;
            this.btnenter.Text = "ENTER";
            this.btnenter.UseVisualStyleBackColor = false;
            this.btnenter.Click += new System.EventHandler(this.btnenter_Click);
            // 
            // panelTecladoNumerico
            // 
            this.panelTecladoNumerico.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.panelTecladoNumerico.Controls.Add(this.btnborrar);
            this.panelTecladoNumerico.Controls.Add(this.btn1);
            this.panelTecladoNumerico.Controls.Add(this.btn7);
            this.panelTecladoNumerico.Controls.Add(this.btnenter);
            this.panelTecladoNumerico.Controls.Add(this.btn8);
            this.panelTecladoNumerico.Controls.Add(this.btn0);
            this.panelTecladoNumerico.Controls.Add(this.btn9);
            this.panelTecladoNumerico.Controls.Add(this.btn3);
            this.panelTecladoNumerico.Controls.Add(this.btn4);
            this.panelTecladoNumerico.Controls.Add(this.btn2);
            this.panelTecladoNumerico.Controls.Add(this.btn5);
            this.panelTecladoNumerico.Controls.Add(this.btn6);
            this.panelTecladoNumerico.Location = new System.Drawing.Point(971, 371);
            this.panelTecladoNumerico.Name = "panelTecladoNumerico";
            this.panelTecladoNumerico.Size = new System.Drawing.Size(257, 244);
            this.panelTecladoNumerico.TabIndex = 97;
            this.panelTecladoNumerico.Visible = false;
            // 
            // btnborrar
            // 
            this.btnborrar.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btnborrar.FlatAppearance.BorderSize = 0;
            this.btnborrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnborrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnborrar.Location = new System.Drawing.Point(12, 197);
            this.btnborrar.Name = "btnborrar";
            this.btnborrar.Size = new System.Drawing.Size(237, 40);
            this.btnborrar.TabIndex = 96;
            this.btnborrar.Text = "BORRAR";
            this.btnborrar.UseVisualStyleBackColor = false;
            this.btnborrar.Click += new System.EventHandler(this.btnborrar_Click);
            // 
            // lblcantoriginal
            // 
            this.lblcantoriginal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblcantoriginal.AutoSize = true;
            this.lblcantoriginal.Location = new System.Drawing.Point(644, 642);
            this.lblcantoriginal.Name = "lblcantoriginal";
            this.lblcantoriginal.Size = new System.Drawing.Size(13, 13);
            this.lblcantoriginal.TabIndex = 99;
            this.lblcantoriginal.Text = "0";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(493, 640);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(145, 16);
            this.label4.TabIndex = 98;
            this.label4.Text = "Total Cant. Original:";
            // 
            // lblcantusada
            // 
            this.lblcantusada.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblcantusada.AutoSize = true;
            this.lblcantusada.Location = new System.Drawing.Point(881, 642);
            this.lblcantusada.Name = "lblcantusada";
            this.lblcantusada.Size = new System.Drawing.Size(13, 13);
            this.lblcantusada.TabIndex = 101;
            this.lblcantusada.Text = "0";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(719, 640);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 16);
            this.label5.TabIndex = 100;
            this.label5.Text = "Total Cant. Adicional:";
            // 
            // lblmedico
            // 
            this.lblmedico.AutoSize = true;
            this.lblmedico.Location = new System.Drawing.Point(490, 89);
            this.lblmedico.Name = "lblmedico";
            this.lblmedico.Size = new System.Drawing.Size(35, 13);
            this.lblmedico.TabIndex = 103;
            this.lblmedico.Text = "label3";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(417, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 16);
            this.label6.TabIndex = 102;
            this.label6.Text = "Médico :";
            // 
            // lblseguro
            // 
            this.lblseguro.Location = new System.Drawing.Point(118, 88);
            this.lblseguro.Name = "lblseguro";
            this.lblseguro.Size = new System.Drawing.Size(293, 38);
            this.lblseguro.TabIndex = 105;
            this.lblseguro.Text = "label3";
            this.lblseguro.UseCompatibleTextRendering = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 86);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(106, 16);
            this.label7.TabIndex = 104;
            this.label7.Text = "Aseguradora :";
            // 
            // lbltipo
            // 
            this.lbltipo.AutoSize = true;
            this.lbltipo.Location = new System.Drawing.Point(558, 59);
            this.lbltipo.Name = "lbltipo";
            this.lbltipo.Size = new System.Drawing.Size(35, 13);
            this.lbltipo.TabIndex = 107;
            this.lbltipo.Text = "label3";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(417, 57);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(135, 16);
            this.label8.TabIndex = 106;
            this.label8.Text = "Tipo Tratamiento :";
            // 
            // lblreferido
            // 
            this.lblreferido.AutoSize = true;
            this.lblreferido.Location = new System.Drawing.Point(535, 27);
            this.lblreferido.Name = "lblreferido";
            this.lblreferido.Size = new System.Drawing.Size(35, 13);
            this.lblreferido.TabIndex = 109;
            this.lblreferido.Text = "label3";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(417, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(112, 16);
            this.label9.TabIndex = 108;
            this.label9.Text = "Tipo Referido :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 16);
            this.label3.TabIndex = 110;
            this.label3.Text = "Genero :";
            // 
            // lblgenero
            // 
            this.lblgenero.AutoSize = true;
            this.lblgenero.Location = new System.Drawing.Point(79, 59);
            this.lblgenero.Name = "lblgenero";
            this.lblgenero.Size = new System.Drawing.Size(35, 13);
            this.lblgenero.TabIndex = 111;
            this.lblgenero.Text = "label3";
            // 
            // panelPaciente
            // 
            this.panelPaciente.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelPaciente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(245)))), ((int)(((byte)(253)))));
            this.panelPaciente.Controls.Add(this.label6);
            this.panelPaciente.Controls.Add(this.lblmedico);
            this.panelPaciente.Controls.Add(this.checkBox1);
            this.panelPaciente.Controls.Add(this.cmbProcedimiento);
            this.panelPaciente.Controls.Add(this.label1);
            this.panelPaciente.Controls.Add(this.lblgenero);
            this.panelPaciente.Controls.Add(this.label2);
            this.panelPaciente.Controls.Add(this.label3);
            this.panelPaciente.Controls.Add(this.lblpaciente);
            this.panelPaciente.Controls.Add(this.lblreferido);
            this.panelPaciente.Controls.Add(this.label9);
            this.panelPaciente.Controls.Add(this.lbltipo);
            this.panelPaciente.Controls.Add(this.label8);
            this.panelPaciente.Controls.Add(this.label7);
            this.panelPaciente.Controls.Add(this.lblseguro);
            this.panelPaciente.Location = new System.Drawing.Point(0, 48);
            this.panelPaciente.Name = "panelPaciente";
            this.panelPaciente.Size = new System.Drawing.Size(1235, 129);
            this.panelPaciente.TabIndex = 112;
            this.panelPaciente.TabStop = false;
            this.panelPaciente.Text = "Datos de Paciente";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Enabled = false;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(800, 58);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(147, 19);
            this.checkBox1.TabIndex = 115;
            this.checkBox1.Text = "Igualar Cantidades";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // cmbProcedimiento
            // 
            this.cmbProcedimiento.FormattingEnabled = true;
            this.cmbProcedimiento.Location = new System.Drawing.Point(909, 24);
            this.cmbProcedimiento.Name = "cmbProcedimiento";
            this.cmbProcedimiento.Size = new System.Drawing.Size(319, 21);
            this.cmbProcedimiento.TabIndex = 113;
            this.cmbProcedimiento.SelectedIndexChanged += new System.EventHandler(this.cmbProcedimiento_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(245)))), ((int)(((byte)(253)))));
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.lblduracion);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.lblhf);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.lblhi);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.lblfecha);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.lblinstrumentista);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.lblpatologo);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.lbltipoanestesia);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.lblcirujano);
            this.groupBox1.Controls.Add(this.lblayudante);
            this.groupBox1.Controls.Add(this.lblayudantia);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.lblanestesiologo);
            this.groupBox1.Controls.Add(this.lblcirculante);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.lblatencion);
            this.groupBox1.Location = new System.Drawing.Point(0, 183);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1235, 154);
            this.groupBox1.TabIndex = 113;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos de Registro";
            this.groupBox1.Visible = false;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(797, 125);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(74, 16);
            this.label31.TabIndex = 122;
            this.label31.Text = "Duración:";
            // 
            // lblduracion
            // 
            this.lblduracion.AutoSize = true;
            this.lblduracion.Location = new System.Drawing.Point(877, 127);
            this.lblduracion.Name = "lblduracion";
            this.lblduracion.Size = new System.Drawing.Size(35, 13);
            this.lblduracion.TabIndex = 123;
            this.lblduracion.Text = "label3";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(535, 125);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(36, 16);
            this.label29.TabIndex = 120;
            this.label29.Text = "H.F:";
            // 
            // lblhf
            // 
            this.lblhf.AutoSize = true;
            this.lblhf.Location = new System.Drawing.Point(577, 127);
            this.lblhf.Name = "lblhf";
            this.lblhf.Size = new System.Drawing.Size(35, 13);
            this.lblhf.TabIndex = 121;
            this.lblhf.Text = "label3";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(417, 125);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(31, 16);
            this.label27.TabIndex = 118;
            this.label27.Text = "H.I:";
            // 
            // lblhi
            // 
            this.lblhi.AutoSize = true;
            this.lblhi.Location = new System.Drawing.Point(454, 127);
            this.lblhi.Name = "lblhi";
            this.lblhi.Size = new System.Drawing.Size(35, 13);
            this.lblhi.TabIndex = 119;
            this.lblhi.Text = "label3";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(6, 125);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(55, 16);
            this.label16.TabIndex = 116;
            this.label16.Text = "Fecha:";
            // 
            // lblfecha
            // 
            this.lblfecha.AutoSize = true;
            this.lblfecha.Location = new System.Drawing.Point(67, 127);
            this.lblfecha.Name = "lblfecha";
            this.lblfecha.Size = new System.Drawing.Size(35, 13);
            this.lblfecha.TabIndex = 117;
            this.lblfecha.Text = "label3";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(6, 90);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(107, 16);
            this.label14.TabIndex = 114;
            this.label14.Text = "Instrumentista:";
            // 
            // lblinstrumentista
            // 
            this.lblinstrumentista.AutoSize = true;
            this.lblinstrumentista.Location = new System.Drawing.Point(119, 92);
            this.lblinstrumentista.Name = "lblinstrumentista";
            this.lblinstrumentista.Size = new System.Drawing.Size(35, 13);
            this.lblinstrumentista.TabIndex = 115;
            this.lblinstrumentista.Text = "label3";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(417, 90);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(79, 16);
            this.label24.TabIndex = 112;
            this.label24.Text = "Patología:";
            // 
            // lblpatologo
            // 
            this.lblpatologo.AutoSize = true;
            this.lblpatologo.Location = new System.Drawing.Point(502, 92);
            this.lblpatologo.Name = "lblpatologo";
            this.lblpatologo.Size = new System.Drawing.Size(35, 13);
            this.lblpatologo.TabIndex = 113;
            this.lblpatologo.Text = "label3";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(6, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(69, 16);
            this.label10.TabIndex = 81;
            this.label10.Text = "Cirujano:";
            // 
            // lbltipoanestesia
            // 
            this.lbltipoanestesia.AutoSize = true;
            this.lbltipoanestesia.Location = new System.Drawing.Point(151, 59);
            this.lbltipoanestesia.Name = "lbltipoanestesia";
            this.lbltipoanestesia.Size = new System.Drawing.Size(35, 13);
            this.lbltipoanestesia.TabIndex = 111;
            this.lbltipoanestesia.Text = "label3";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(797, 25);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 16);
            this.label12.TabIndex = 82;
            this.label12.Text = "Ayudantía(C):";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(6, 57);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(139, 16);
            this.label13.TabIndex = 110;
            this.label13.Text = "Tipo de Anestesia:";
            // 
            // lblcirujano
            // 
            this.lblcirujano.AutoSize = true;
            this.lblcirujano.Location = new System.Drawing.Point(81, 27);
            this.lblcirujano.Name = "lblcirujano";
            this.lblcirujano.Size = new System.Drawing.Size(35, 13);
            this.lblcirujano.TabIndex = 83;
            this.lblcirujano.Text = "label3";
            // 
            // lblayudante
            // 
            this.lblayudante.AutoSize = true;
            this.lblayudante.Location = new System.Drawing.Point(520, 27);
            this.lblayudante.Name = "lblayudante";
            this.lblayudante.Size = new System.Drawing.Size(35, 13);
            this.lblayudante.TabIndex = 109;
            this.lblayudante.Text = "label3";
            // 
            // lblayudantia
            // 
            this.lblayudantia.AutoSize = true;
            this.lblayudantia.Location = new System.Drawing.Point(900, 27);
            this.lblayudantia.Name = "lblayudantia";
            this.lblayudantia.Size = new System.Drawing.Size(35, 13);
            this.lblayudantia.TabIndex = 84;
            this.lblayudantia.Text = "label3";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(417, 25);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(97, 16);
            this.label17.TabIndex = 108;
            this.label17.Text = "Ayudante(P):";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(797, 57);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(81, 16);
            this.label18.TabIndex = 102;
            this.label18.Text = "Circulante:";
            // 
            // lblanestesiologo
            // 
            this.lblanestesiologo.AutoSize = true;
            this.lblanestesiologo.Location = new System.Drawing.Point(535, 59);
            this.lblanestesiologo.Name = "lblanestesiologo";
            this.lblanestesiologo.Size = new System.Drawing.Size(35, 13);
            this.lblanestesiologo.TabIndex = 107;
            this.lblanestesiologo.Text = "label3";
            // 
            // lblcirculante
            // 
            this.lblcirculante.AutoSize = true;
            this.lblcirculante.Location = new System.Drawing.Point(884, 59);
            this.lblcirculante.Name = "lblcirculante";
            this.lblcirculante.Size = new System.Drawing.Size(35, 13);
            this.lblcirculante.TabIndex = 103;
            this.lblcirculante.Text = "label3";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(417, 57);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(112, 16);
            this.label21.TabIndex = 106;
            this.label21.Text = "Anestesiólogo:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(797, 90);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(130, 16);
            this.label22.TabIndex = 104;
            this.label22.Text = "Tipo de Atención:";
            // 
            // lblatencion
            // 
            this.lblatencion.AutoSize = true;
            this.lblatencion.Location = new System.Drawing.Point(933, 92);
            this.lblatencion.Name = "lblatencion";
            this.lblatencion.Size = new System.Drawing.Size(35, 13);
            this.lblatencion.TabIndex = 105;
            this.lblatencion.Text = "label3";
            // 
            // frmQuirofanoPedidoPaciente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1235, 665);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panelPaciente);
            this.Controls.Add(this.lblcantusada);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblcantoriginal);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panelTecladoNumerico);
            this.Controls.Add(this.TablaProcedimientos);
            this.Controls.Add(this.tools);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmQuirofanoPedidoPaciente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pedido Paciente";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmQuirofanoPedidoPaciente_Load);
            this.tools.ResumeLayout(false);
            this.tools.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TablaProcedimientos)).EndInit();
            this.panelTecladoNumerico.ResumeLayout(false);
            this.panelPaciente.ResumeLayout(false);
            this.panelPaciente.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip tools;
        private System.Windows.Forms.ToolStripButton btnGuardar;
        private System.Windows.Forms.ToolStripButton btnEditar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButtonSalir;
        private System.Windows.Forms.DataGridView TablaProcedimientos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblpaciente;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btnenter;
        private System.Windows.Forms.Panel panelTecladoNumerico;
        private System.Windows.Forms.Label lblcantoriginal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblcantusada;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ToolStripButton toolStripDespachar;
        private System.Windows.Forms.Label lblmedico;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblseguro;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbltipo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblreferido;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblgenero;
        private System.Windows.Forms.GroupBox panelPaciente;
        private System.Windows.Forms.Button btnborrar;
        private System.Windows.Forms.ComboBox cmbProcedimiento;
        private System.Windows.Forms.ToolStripButton btnadicional;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ToolStripButton btncancelar;
        private System.Windows.Forms.ToolStripButton toolStripRegistro;
        private System.Windows.Forms.ToolStripButton toolStripAgregar;
        private System.Windows.Forms.ToolStripButton toolStripCerrar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbltipoanestesia;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblcirujano;
        private System.Windows.Forms.Label lblayudante;
        private System.Windows.Forms.Label lblayudantia;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblanestesiologo;
        private System.Windows.Forms.Label lblcirculante;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblatencion;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lblpatologo;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblfecha;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblinstrumentista;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label lblduracion;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label lblhf;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label lblhi;
    }
}