﻿namespace His.Dietetica
{
    partial class MDI_PE
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MDI_PE));
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinStatusBar.UltraStatusPanel ultraStatusPanel1 = new Infragistics.Win.UltraWinStatusBar.UltraStatusPanel();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinStatusBar.UltraStatusPanel ultraStatusPanel2 = new Infragistics.Win.UltraWinStatusBar.UltraStatusPanel();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinStatusBar.UltraStatusPanel ultraStatusPanel3 = new Infragistics.Win.UltraWinStatusBar.UltraStatusPanel();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinStatusBar.UltraStatusPanel ultraStatusPanel4 = new Infragistics.Win.UltraWinStatusBar.UltraStatusPanel();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinStatusBar.UltraStatusPanel ultraStatusPanel5 = new Infragistics.Win.UltraWinStatusBar.UltraStatusPanel();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinStatusBar.UltraStatusPanel ultraStatusPanel6 = new Infragistics.Win.UltraWinStatusBar.UltraStatusPanel();
            Infragistics.Win.UltraWinStatusBar.UltraStatusPanel ultraStatusPanel7 = new Infragistics.Win.UltraWinStatusBar.UltraStatusPanel();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.mnu_archivo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.smnu_salir = new System.Windows.Forms.ToolStripMenuItem();
            this.pedidosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dieteticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImagen = new System.Windows.Forms.ToolStripMenuItem();
            this.agendamientoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.examenesRealizadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.informeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exploradorDePedidosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.horarioDeMédicosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.planificarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.explorarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.laboratorioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pacientesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuLabPat = new System.Windows.Forms.ToolStripMenuItem();
            this.quirofanoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agregarProcedimientoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agregarProductoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pedidoPacienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.windowsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.cascadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tileVerticalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tileHorizontalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.arrangeIconsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.contentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.indexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.ultraFormManager1 = new Infragistics.Win.UltraWinForm.UltraFormManager(this.components);
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Left = new Infragistics.Win.UltraWinForm.UltraFormDockArea();
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Right = new Infragistics.Win.UltraWinForm.UltraFormDockArea();
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Top = new Infragistics.Win.UltraWinForm.UltraFormDockArea();
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Bottom = new Infragistics.Win.UltraWinForm.UltraFormDockArea();
            this.ultraStatusBarTarifario = new Infragistics.Win.UltraWinStatusBar.UltraStatusBar();
            this.ultraTabbedMdiManager1 = new Infragistics.Win.UltraWinTabbedMdi.UltraTabbedMdiManager(this.components);
            this.garantiasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNENToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pacientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.atencionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.habitacionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formulariosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.admisiónEmergenciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.procedimientosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.catalogoDeCostosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraFormManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraStatusBarTarifario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTabbedMdiManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(223)))), ((int)(((byte)(245)))));
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnu_archivo,
            this.pedidosToolStripMenuItem,
            this.mnuImagen,
            this.laboratorioToolStripMenuItem,
            this.mnuLabPat,
            this.quirofanoToolStripMenuItem,
            this.windowsMenu,
            this.helpMenu});
            this.menuStrip.Location = new System.Drawing.Point(4, 28);
            this.menuStrip.MdiWindowListItem = this.windowsMenu;
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(865, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // mnu_archivo
            // 
            this.mnu_archivo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator2,
            this.smnu_salir});
            this.mnu_archivo.Name = "mnu_archivo";
            this.mnu_archivo.Size = new System.Drawing.Size(60, 20);
            this.mnu_archivo.Text = "Archivo";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(93, 6);
            // 
            // smnu_salir
            // 
            this.smnu_salir.Name = "smnu_salir";
            this.smnu_salir.Size = new System.Drawing.Size(96, 22);
            this.smnu_salir.Text = "Salir";
            this.smnu_salir.Click += new System.EventHandler(this.smnu_salir_Click);
            // 
            // pedidosToolStripMenuItem
            // 
            this.pedidosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dieteticaToolStripMenuItem});
            this.pedidosToolStripMenuItem.Name = "pedidosToolStripMenuItem";
            this.pedidosToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.pedidosToolStripMenuItem.Text = "Dietetica";
            // 
            // dieteticaToolStripMenuItem
            // 
            this.dieteticaToolStripMenuItem.Name = "dieteticaToolStripMenuItem";
            this.dieteticaToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.dieteticaToolStripMenuItem.Text = "Pedido";
            this.dieteticaToolStripMenuItem.Click += new System.EventHandler(this.dieteticaToolStripMenuItem_Click);
            // 
            // mnuImagen
            // 
            this.mnuImagen.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.agendamientoToolStripMenuItem,
            this.examenesRealizadosToolStripMenuItem,
            this.informeToolStripMenuItem,
            this.toolStripSeparator1,
            this.exploradorDePedidosToolStripMenuItem,
            this.toolStripSeparator3,
            this.horarioDeMédicosToolStripMenuItem1});
            this.mnuImagen.Name = "mnuImagen";
            this.mnuImagen.Size = new System.Drawing.Size(59, 20);
            this.mnuImagen.Text = "Imagen";
            // 
            // agendamientoToolStripMenuItem
            // 
            this.agendamientoToolStripMenuItem.Name = "agendamientoToolStripMenuItem";
            this.agendamientoToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.agendamientoToolStripMenuItem.Text = "Agendamiento";
            this.agendamientoToolStripMenuItem.Click += new System.EventHandler(this.agendamientoToolStripMenuItem_Click);
            // 
            // examenesRealizadosToolStripMenuItem
            // 
            this.examenesRealizadosToolStripMenuItem.Name = "examenesRealizadosToolStripMenuItem";
            this.examenesRealizadosToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.examenesRealizadosToolStripMenuItem.Text = "Exámenes Agendados";
            this.examenesRealizadosToolStripMenuItem.Click += new System.EventHandler(this.examenesRealizadosToolStripMenuItem_Click);
            // 
            // informeToolStripMenuItem
            // 
            this.informeToolStripMenuItem.Name = "informeToolStripMenuItem";
            this.informeToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.informeToolStripMenuItem.Text = "Informe";
            this.informeToolStripMenuItem.Click += new System.EventHandler(this.informeToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(189, 6);
            // 
            // exploradorDePedidosToolStripMenuItem
            // 
            this.exploradorDePedidosToolStripMenuItem.Name = "exploradorDePedidosToolStripMenuItem";
            this.exploradorDePedidosToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.exploradorDePedidosToolStripMenuItem.Text = "Explorador de Pedidos";
            this.exploradorDePedidosToolStripMenuItem.Click += new System.EventHandler(this.exploradorDePedidosToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(189, 6);
            // 
            // horarioDeMédicosToolStripMenuItem1
            // 
            this.horarioDeMédicosToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.planificarToolStripMenuItem1,
            this.explorarToolStripMenuItem1});
            this.horarioDeMédicosToolStripMenuItem1.Name = "horarioDeMédicosToolStripMenuItem1";
            this.horarioDeMédicosToolStripMenuItem1.Size = new System.Drawing.Size(192, 22);
            this.horarioDeMédicosToolStripMenuItem1.Text = "Horario de Médicos";
            // 
            // planificarToolStripMenuItem1
            // 
            this.planificarToolStripMenuItem1.Name = "planificarToolStripMenuItem1";
            this.planificarToolStripMenuItem1.Size = new System.Drawing.Size(123, 22);
            this.planificarToolStripMenuItem1.Text = "Planificar";
            this.planificarToolStripMenuItem1.Click += new System.EventHandler(this.planificarToolStripMenuItem1_Click);
            // 
            // explorarToolStripMenuItem1
            // 
            this.explorarToolStripMenuItem1.Name = "explorarToolStripMenuItem1";
            this.explorarToolStripMenuItem1.Size = new System.Drawing.Size(123, 22);
            this.explorarToolStripMenuItem1.Text = "Explorar";
            this.explorarToolStripMenuItem1.Click += new System.EventHandler(this.explorarToolStripMenuItem1_Click);
            // 
            // laboratorioToolStripMenuItem
            // 
            this.laboratorioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pacientesToolStripMenuItem1});
            this.laboratorioToolStripMenuItem.Name = "laboratorioToolStripMenuItem";
            this.laboratorioToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.laboratorioToolStripMenuItem.Text = "Lab. Clínico";
            // 
            // pacientesToolStripMenuItem1
            // 
            this.pacientesToolStripMenuItem1.Name = "pacientesToolStripMenuItem1";
            this.pacientesToolStripMenuItem1.Size = new System.Drawing.Size(124, 22);
            this.pacientesToolStripMenuItem1.Text = "Pacientes";
            this.pacientesToolStripMenuItem1.Click += new System.EventHandler(this.pacientesToolStripMenuItem1_Click_1);
            // 
            // mnuLabPat
            // 
            this.mnuLabPat.Name = "mnuLabPat";
            this.mnuLabPat.Size = new System.Drawing.Size(101, 20);
            this.mnuLabPat.Text = "Lab. Patológico";
            // 
            // quirofanoToolStripMenuItem
            // 
            this.quirofanoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.agregarProductoToolStripMenuItem,
            this.agregarProcedimientoToolStripMenuItem,
            this.pedidoPacienteToolStripMenuItem});
            this.quirofanoToolStripMenuItem.Name = "quirofanoToolStripMenuItem";
            this.quirofanoToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.quirofanoToolStripMenuItem.Text = "Quirofano";
            // 
            // agregarProcedimientoToolStripMenuItem
            // 
            this.agregarProcedimientoToolStripMenuItem.Name = "agregarProcedimientoToolStripMenuItem";
            this.agregarProcedimientoToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.agregarProcedimientoToolStripMenuItem.Text = "Agregar Procedimiento";
            this.agregarProcedimientoToolStripMenuItem.Click += new System.EventHandler(this.agregarProcedimientoToolStripMenuItem_Click);
            // 
            // agregarProductoToolStripMenuItem
            // 
            this.agregarProductoToolStripMenuItem.Name = "agregarProductoToolStripMenuItem";
            this.agregarProductoToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.agregarProductoToolStripMenuItem.Text = "Agregar Producto";
            this.agregarProductoToolStripMenuItem.Click += new System.EventHandler(this.agregarProductoToolStripMenuItem_Click);
            // 
            // pedidoPacienteToolStripMenuItem
            // 
            this.pedidoPacienteToolStripMenuItem.Name = "pedidoPacienteToolStripMenuItem";
            this.pedidoPacienteToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.pedidoPacienteToolStripMenuItem.Text = "Pedido Paciente";
            this.pedidoPacienteToolStripMenuItem.Click += new System.EventHandler(this.pedidoPacienteToolStripMenuItem_Click);
            // 
            // windowsMenu
            // 
            this.windowsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cascadeToolStripMenuItem,
            this.tileVerticalToolStripMenuItem,
            this.tileHorizontalToolStripMenuItem,
            this.closeAllToolStripMenuItem,
            this.arrangeIconsToolStripMenuItem});
            this.windowsMenu.Name = "windowsMenu";
            this.windowsMenu.Size = new System.Drawing.Size(66, 20);
            this.windowsMenu.Text = "&Ventanas";
            // 
            // cascadeToolStripMenuItem
            // 
            this.cascadeToolStripMenuItem.Name = "cascadeToolStripMenuItem";
            this.cascadeToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.cascadeToolStripMenuItem.Text = "&Cascada";
            this.cascadeToolStripMenuItem.Click += new System.EventHandler(this.CascadeToolStripMenuItem_Click);
            // 
            // tileVerticalToolStripMenuItem
            // 
            this.tileVerticalToolStripMenuItem.Name = "tileVerticalToolStripMenuItem";
            this.tileVerticalToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.tileVerticalToolStripMenuItem.Text = "Mosaico &vertical";
            this.tileVerticalToolStripMenuItem.Click += new System.EventHandler(this.TileVerticalToolStripMenuItem_Click);
            // 
            // tileHorizontalToolStripMenuItem
            // 
            this.tileHorizontalToolStripMenuItem.Name = "tileHorizontalToolStripMenuItem";
            this.tileHorizontalToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.tileHorizontalToolStripMenuItem.Text = "Mosaico &horizontal";
            this.tileHorizontalToolStripMenuItem.Click += new System.EventHandler(this.TileHorizontalToolStripMenuItem_Click);
            // 
            // closeAllToolStripMenuItem
            // 
            this.closeAllToolStripMenuItem.Name = "closeAllToolStripMenuItem";
            this.closeAllToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.closeAllToolStripMenuItem.Text = "C&errar todo";
            this.closeAllToolStripMenuItem.Click += new System.EventHandler(this.CloseAllToolStripMenuItem_Click);
            // 
            // arrangeIconsToolStripMenuItem
            // 
            this.arrangeIconsToolStripMenuItem.Name = "arrangeIconsToolStripMenuItem";
            this.arrangeIconsToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.arrangeIconsToolStripMenuItem.Text = "&Organizar iconos";
            this.arrangeIconsToolStripMenuItem.Click += new System.EventHandler(this.ArrangeIconsToolStripMenuItem_Click);
            // 
            // helpMenu
            // 
            this.helpMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contentsToolStripMenuItem,
            this.indexToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.toolStripSeparator8,
            this.aboutToolStripMenuItem});
            this.helpMenu.Name = "helpMenu";
            this.helpMenu.Size = new System.Drawing.Size(53, 20);
            this.helpMenu.Text = "Ay&uda";
            // 
            // contentsToolStripMenuItem
            // 
            this.contentsToolStripMenuItem.Name = "contentsToolStripMenuItem";
            this.contentsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F1)));
            this.contentsToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.contentsToolStripMenuItem.Text = "&Contenido";
            // 
            // indexToolStripMenuItem
            // 
            this.indexToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("indexToolStripMenuItem.Image")));
            this.indexToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.indexToolStripMenuItem.Name = "indexToolStripMenuItem";
            this.indexToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.indexToolStripMenuItem.Text = "&Índice";
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("searchToolStripMenuItem.Image")));
            this.searchToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.searchToolStripMenuItem.Text = "&Buscar";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(173, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.aboutToolStripMenuItem.Text = "&Acerca de... ...";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // ultraFormManager1
            // 
            this.ultraFormManager1.Form = this;
            this.ultraFormManager1.FormStyleSettings.Style = Infragistics.Win.UltraWinForm.UltraFormStyle.Office2007;
            // 
            // _MDI_Dietetica_UltraFormManager_Dock_Area_Left
            // 
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Left.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Left.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Left.DockedPosition = Infragistics.Win.UltraWinForm.DockedPosition.Left;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Left.ForeColor = System.Drawing.SystemColors.ControlText;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Left.FormManager = this.ultraFormManager1;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Left.InitialResizeAreaExtent = 4;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Left.Location = new System.Drawing.Point(0, 28);
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Left.Name = "_MDI_Dietetica_UltraFormManager_Dock_Area_Left";
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Left.Size = new System.Drawing.Size(4, 445);
            // 
            // _MDI_Dietetica_UltraFormManager_Dock_Area_Right
            // 
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Right.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Right.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Right.DockedPosition = Infragistics.Win.UltraWinForm.DockedPosition.Right;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Right.ForeColor = System.Drawing.SystemColors.ControlText;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Right.FormManager = this.ultraFormManager1;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Right.InitialResizeAreaExtent = 4;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Right.Location = new System.Drawing.Point(869, 28);
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Right.Name = "_MDI_Dietetica_UltraFormManager_Dock_Area_Right";
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Right.Size = new System.Drawing.Size(4, 445);
            // 
            // _MDI_Dietetica_UltraFormManager_Dock_Area_Top
            // 
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Top.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Top.DockedPosition = Infragistics.Win.UltraWinForm.DockedPosition.Top;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Top.ForeColor = System.Drawing.SystemColors.ControlText;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Top.FormManager = this.ultraFormManager1;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Top.Location = new System.Drawing.Point(0, 0);
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Top.Name = "_MDI_Dietetica_UltraFormManager_Dock_Area_Top";
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Top.Size = new System.Drawing.Size(873, 28);
            // 
            // _MDI_Dietetica_UltraFormManager_Dock_Area_Bottom
            // 
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Bottom.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Bottom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Bottom.DockedPosition = Infragistics.Win.UltraWinForm.DockedPosition.Bottom;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Bottom.ForeColor = System.Drawing.SystemColors.ControlText;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Bottom.FormManager = this.ultraFormManager1;
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Bottom.Location = new System.Drawing.Point(0, 473);
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Bottom.Name = "_MDI_Dietetica_UltraFormManager_Dock_Area_Bottom";
            this._MDI_Dietetica_UltraFormManager_Dock_Area_Bottom.Size = new System.Drawing.Size(873, 0);
            // 
            // ultraStatusBarTarifario
            // 
            appearance1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(210)))), ((int)(((byte)(234)))));
            appearance1.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(223)))), ((int)(((byte)(245)))));
            appearance1.ForeColor = System.Drawing.Color.DimGray;
            appearance1.ForeColorDisabled = System.Drawing.Color.Silver;
            this.ultraStatusBarTarifario.Appearance = appearance1;
            this.ultraStatusBarTarifario.BorderStyle = Infragistics.Win.UIElementBorderStyle.WindowsVista;
            this.ultraStatusBarTarifario.BorderStylePanel = Infragistics.Win.UIElementBorderStyle.WindowsVista;
            this.ultraStatusBarTarifario.Location = new System.Drawing.Point(0, 473);
            this.ultraStatusBarTarifario.Name = "ultraStatusBarTarifario";
            appearance2.TextVAlignAsString = "Middle";
            this.ultraStatusBarTarifario.PanelAppearance = appearance2;
            appearance3.TextHAlignAsString = "Center";
            appearance3.TextVAlignAsString = "Middle";
            ultraStatusPanel1.Appearance = appearance3;
            ultraStatusPanel1.Key = "empresa";
            ultraStatusPanel1.ToolTipText = "Empresa";
            ultraStatusPanel1.Width = 200;
            appearance4.TextHAlignAsString = "Center";
            appearance4.TextVAlignAsString = "Middle";
            ultraStatusPanel2.Appearance = appearance4;
            ultraStatusPanel2.Key = "usuario";
            ultraStatusPanel2.ToolTipText = "Usuario ";
            ultraStatusPanel2.Width = 160;
            appearance5.TextHAlignAsString = "Center";
            appearance5.TextVAlignAsString = "Middle";
            ultraStatusPanel3.Appearance = appearance5;
            ultraStatusPanel3.Key = "fecha";
            ultraStatusPanel3.Style = Infragistics.Win.UltraWinStatusBar.PanelStyle.Date;
            ultraStatusPanel3.ToolTipText = "Fecha actual";
            ultraStatusPanel3.Width = 80;
            appearance6.TextHAlignAsString = "Center";
            ultraStatusPanel4.Appearance = appearance6;
            ultraStatusPanel4.BorderStyle = Infragistics.Win.UIElementBorderStyle.WindowsVista;
            ultraStatusPanel4.Key = "hora";
            ultraStatusPanel4.Padding = new System.Drawing.Size(1, 1);
            ultraStatusPanel4.Style = Infragistics.Win.UltraWinStatusBar.PanelStyle.Time;
            ultraStatusPanel4.ToolTipText = "Hora actual";
            ultraStatusPanel4.Width = 60;
            appearance7.BackColor = System.Drawing.Color.Transparent;
            ultraStatusPanel5.Appearance = appearance7;
            ultraStatusPanel5.BorderStyle = Infragistics.Win.UIElementBorderStyle.WindowsVista;
            ultraStatusPanel5.Style = Infragistics.Win.UltraWinStatusBar.PanelStyle.MDIList;
            ultraStatusPanel5.Width = 1200;
            ultraStatusPanel6.Key = "ELog";
            ultraStatusPanel7.Key = "cod_user";
            ultraStatusPanel7.Visible = false;
            this.ultraStatusBarTarifario.Panels.AddRange(new Infragistics.Win.UltraWinStatusBar.UltraStatusPanel[] {
            ultraStatusPanel1,
            ultraStatusPanel2,
            ultraStatusPanel3,
            ultraStatusPanel4,
            ultraStatusPanel5,
            ultraStatusPanel6,
            ultraStatusPanel7});
            this.ultraStatusBarTarifario.Size = new System.Drawing.Size(873, 37);
            this.ultraStatusBarTarifario.TabIndex = 33;
            this.ultraStatusBarTarifario.Text = "ultraStatusBarTarifario";
            this.ultraStatusBarTarifario.ViewStyle = Infragistics.Win.UltraWinStatusBar.ViewStyle.Standard;
            // 
            // ultraTabbedMdiManager1
            // 
            appearance8.BackColor = System.Drawing.Color.GhostWhite;
            appearance8.BackColor2 = System.Drawing.Color.Gainsboro;
            appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            this.ultraTabbedMdiManager1.Appearance = appearance8;
            this.ultraTabbedMdiManager1.MdiParent = this;
            this.ultraTabbedMdiManager1.TabGroupSettings.TabAreaMargins.Bottom = 2;
            this.ultraTabbedMdiManager1.TabGroupSettings.TabAreaMargins.Left = 2;
            this.ultraTabbedMdiManager1.TabGroupSettings.TabAreaMargins.Right = 2;
            this.ultraTabbedMdiManager1.TabGroupSettings.TabAreaMargins.Top = 2;
            this.ultraTabbedMdiManager1.TabGroupSettings.TabButtonStyle = Infragistics.Win.UIElementButtonStyle.Office2010ScrollbarButton;
            this.ultraTabbedMdiManager1.TabGroupSettings.TabOrientation = Infragistics.Win.UltraWinTabs.TabOrientation.LeftTop;
            this.ultraTabbedMdiManager1.TabGroupSettings.TabPadding = new System.Drawing.Size(5, 5);
            this.ultraTabbedMdiManager1.ViewStyle = Infragistics.Win.UltraWinTabbedMdi.ViewStyle.Office2007;
            // 
            // garantiasToolStripMenuItem
            // 
            this.garantiasToolStripMenuItem.Name = "garantiasToolStripMenuItem";
            this.garantiasToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.garantiasToolStripMenuItem.Text = "Garantias";
            this.garantiasToolStripMenuItem.Click += new System.EventHandler(this.garantiasToolStripMenuItem_Click);
            // 
            // iNENToolStripMenuItem
            // 
            this.iNENToolStripMenuItem.Name = "iNENToolStripMenuItem";
            this.iNENToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.iNENToolStripMenuItem.Text = "INEN";
            this.iNENToolStripMenuItem.Click += new System.EventHandler(this.iNENToolStripMenuItem_Click);
            // 
            // pacientesToolStripMenuItem
            // 
            this.pacientesToolStripMenuItem.Name = "pacientesToolStripMenuItem";
            this.pacientesToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.pacientesToolStripMenuItem.Text = "Pacientes";
            this.pacientesToolStripMenuItem.Click += new System.EventHandler(this.pacientesToolStripMenuItem_Click);
            // 
            // atencionesToolStripMenuItem
            // 
            this.atencionesToolStripMenuItem.Name = "atencionesToolStripMenuItem";
            this.atencionesToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.atencionesToolStripMenuItem.Text = "Atenciones";
            this.atencionesToolStripMenuItem.Click += new System.EventHandler(this.atencionesToolStripMenuItem_Click);
            // 
            // habitacionesToolStripMenuItem
            // 
            this.habitacionesToolStripMenuItem.Name = "habitacionesToolStripMenuItem";
            this.habitacionesToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.habitacionesToolStripMenuItem.Text = "Habitaciones";
            this.habitacionesToolStripMenuItem.Click += new System.EventHandler(this.habitacionesToolStripMenuItem_Click_1);
            // 
            // formulariosToolStripMenuItem1
            // 
            this.formulariosToolStripMenuItem1.Name = "formulariosToolStripMenuItem1";
            this.formulariosToolStripMenuItem1.Size = new System.Drawing.Size(154, 22);
            this.formulariosToolStripMenuItem1.Text = "Historia Clinica";
            this.formulariosToolStripMenuItem1.Click += new System.EventHandler(this.formulariosToolStripMenuItem1_Click);
            // 
            // admisiónEmergenciaToolStripMenuItem
            // 
            this.admisiónEmergenciaToolStripMenuItem.Name = "admisiónEmergenciaToolStripMenuItem";
            this.admisiónEmergenciaToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.admisiónEmergenciaToolStripMenuItem.Text = "Admisión Emergencia";
            this.admisiónEmergenciaToolStripMenuItem.Click += new System.EventHandler(this.admisiónEmergenciaToolStripMenuItem_Click_1);
            // 
            // procedimientosToolStripMenuItem
            // 
            this.procedimientosToolStripMenuItem.Name = "procedimientosToolStripMenuItem";
            this.procedimientosToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.procedimientosToolStripMenuItem.Text = "Servicios Externos";
            this.procedimientosToolStripMenuItem.Click += new System.EventHandler(this.procedimientosToolStripMenuItem_Click);
            // 
            // catalogoDeCostosToolStripMenuItem
            // 
            this.catalogoDeCostosToolStripMenuItem.Name = "catalogoDeCostosToolStripMenuItem";
            this.catalogoDeCostosToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.catalogoDeCostosToolStripMenuItem.Text = "Catalogo de Costos";
            // 
            // MDI_PE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 510);
            this.Controls.Add(this.menuStrip);
            this.Controls.Add(this._MDI_Dietetica_UltraFormManager_Dock_Area_Left);
            this.Controls.Add(this._MDI_Dietetica_UltraFormManager_Dock_Area_Right);
            this.Controls.Add(this._MDI_Dietetica_UltraFormManager_Dock_Area_Top);
            this.Controls.Add(this._MDI_Dietetica_UltraFormManager_Dock_Area_Bottom);
            this.Controls.Add(this.ultraStatusBarTarifario);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "MDI_PE";
            this.Text = "Pedidos Especiales";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MDI_Admision_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraFormManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraStatusBarTarifario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTabbedMdiManager1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tileHorizontalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem windowsMenu;
        private System.Windows.Forms.ToolStripMenuItem cascadeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tileVerticalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem arrangeIconsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpMenu;
        private System.Windows.Forms.ToolStripMenuItem contentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem indexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem mnu_archivo;
        private System.Windows.Forms.ToolStripMenuItem smnu_salir;
        private Infragistics.Win.UltraWinForm.UltraFormManager ultraFormManager1;
        private Infragistics.Win.UltraWinForm.UltraFormDockArea _MDI_Dietetica_UltraFormManager_Dock_Area_Left;
        private Infragistics.Win.UltraWinForm.UltraFormDockArea _MDI_Dietetica_UltraFormManager_Dock_Area_Right;
        private Infragistics.Win.UltraWinForm.UltraFormDockArea _MDI_Dietetica_UltraFormManager_Dock_Area_Top;
        private Infragistics.Win.UltraWinForm.UltraFormDockArea _MDI_Dietetica_UltraFormManager_Dock_Area_Bottom;
        private Infragistics.Win.UltraWinTabbedMdi.UltraTabbedMdiManager ultraTabbedMdiManager1;
        private System.Windows.Forms.ToolStripMenuItem garantiasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNENToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pacientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem atencionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem habitacionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formulariosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem admisiónEmergenciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem procedimientosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem catalogoDeCostosToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem pedidosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dieteticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuLabPat;
        private System.Windows.Forms.ToolStripMenuItem mnuImagen;
        private System.Windows.Forms.ToolStripMenuItem agendamientoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem informeToolStripMenuItem;
        public Infragistics.Win.UltraWinStatusBar.UltraStatusBar ultraStatusBarTarifario;
        private System.Windows.Forms.ToolStripMenuItem laboratorioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pacientesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exploradorDePedidosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quirofanoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agregarProcedimientoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agregarProductoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pedidoPacienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem examenesRealizadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem horarioDeMédicosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem planificarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem explorarToolStripMenuItem1;
    }
}



