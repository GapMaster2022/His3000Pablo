﻿namespace His.Dietetica
{
    partial class ImagenInforme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance52 = new Infragistics.Win.Appearance();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ImagenInforme));
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance67 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance91 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance92 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab21 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab22 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab23 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab24 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab1 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            this.ultraTabPageControl1 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.ultraGroupBox11 = new Infragistics.Win.Misc.UltraGroupBox();
            this.ultraLabel5 = new Infragistics.Win.Misc.UltraLabel();
            this.txtMedicoCOD = new System.Windows.Forms.TextBox();
            this.txtMedico = new System.Windows.Forms.TextBox();
            this.btnAddMedico = new System.Windows.Forms.Button();
            this.ultraGroupBox10 = new Infragistics.Win.Misc.UltraGroupBox();
            this.txtPaciente = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.label8 = new System.Windows.Forms.Label();
            this.ultraGroupBox9 = new Infragistics.Win.Misc.UltraGroupBox();
            this.dtpEntrega = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.dtpInforme = new System.Windows.Forms.DateTimePicker();
            this.label58 = new System.Windows.Forms.Label();
            this.ultraGroupBox8 = new Infragistics.Win.Misc.UltraGroupBox();
            this.gridEstudios = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ESTUDIO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CODSUB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBoxTipoDoc = new Infragistics.Win.Misc.UltraGroupBox();
            this.rbControl = new System.Windows.Forms.RadioButton();
            this.rbNormal = new System.Windows.Forms.RadioButton();
            this.rdUrgente = new System.Windows.Forms.RadioButton();
            this.ultraTabPageControl2 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.ultraGroupBox1 = new Infragistics.Win.Misc.UltraGroupBox();
            this.txt_diagnosticoMedico = new System.Windows.Forms.TextBox();
            this.ultraTabPageControl3 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.ultraGroupBox3 = new Infragistics.Win.Misc.UltraGroupBox();
            this.txt_sacoDouglas = new System.Windows.Forms.TextBox();
            this.chkOcupada = new System.Windows.Forms.CheckBox();
            this.chkVacia = new System.Windows.Forms.CheckBox();
            this.chkQuiste = new System.Windows.Forms.CheckBox();
            this.chkHidrosalpix = new System.Windows.Forms.CheckBox();
            this.chkAusente = new System.Windows.Forms.CheckBox();
            this.chkMioma = new System.Windows.Forms.CheckBox();
            this.chkFibroma = new System.Windows.Forms.CheckBox();
            this.chkDiu = new System.Windows.Forms.CheckBox();
            this.chkRetroversion = new System.Windows.Forms.CheckBox();
            this.chkAnteversion = new System.Windows.Forms.CheckBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.ultraGroupBox2 = new Infragistics.Win.Misc.UltraGroupBox();
            this.txt_gradomadurez = new System.Windows.Forms.TextBox();
            this.txt_pap = new System.Windows.Forms.TextBox();
            this.txt_paeg = new System.Windows.Forms.TextBox();
            this.txt_pav = new System.Windows.Forms.TextBox();
            this.txt_lfp = new System.Windows.Forms.TextBox();
            this.txt_lfeg = new System.Windows.Forms.TextBox();
            this.txt_lfv = new System.Windows.Forms.TextBox();
            this.txt_dbp = new System.Windows.Forms.TextBox();
            this.txt_dbeg = new System.Windows.Forms.TextBox();
            this.txt_dbv = new System.Windows.Forms.TextBox();
            this.chkMultiple = new System.Windows.Forms.CheckBox();
            this.chkFemenino = new System.Windows.Forms.CheckBox();
            this.chkMasculino = new System.Windows.Forms.CheckBox();
            this.chkPrevia = new System.Windows.Forms.CheckBox();
            this.chkMarginal = new System.Windows.Forms.CheckBox();
            this.chkFundica = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ultraTabPageControl11 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.ultraGroupBox5 = new Infragistics.Win.Misc.UltraGroupBox();
            this.txtRecomendaciones = new System.Windows.Forms.TextBox();
            this.ultraGroupBox4 = new Infragistics.Win.Misc.UltraGroupBox();
            this.btnAddDiagnotico = new System.Windows.Forms.Button();
            this.gridDiagnosticos = new System.Windows.Forms.DataGridView();
            this.CIE10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DIAGNOSTICO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TIPO = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ultraTabPageControl6 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.ultraGroupBox7 = new Infragistics.Win.Misc.UltraGroupBox();
            this.txtCODRadiologo = new System.Windows.Forms.TextBox();
            this.txtRadiologo = new System.Windows.Forms.TextBox();
            this.txtCODTecnologo = new System.Windows.Forms.TextBox();
            this.btnRadiologo = new System.Windows.Forms.Button();
            this.ultraLabel8 = new Infragistics.Win.Misc.UltraLabel();
            this.ultraLabel9 = new Infragistics.Win.Misc.UltraLabel();
            this.btnTecnologo = new System.Windows.Forms.Button();
            this.txtTecnologo = new System.Windows.Forms.TextBox();
            this.ultraGroupBox6 = new Infragistics.Win.Misc.UltraGroupBox();
            this.txt14x14 = new System.Windows.Forms.TextBox();
            this.txt8x10 = new System.Windows.Forms.TextBox();
            this.chkMedioContraste = new System.Windows.Forms.CheckBox();
            this.txt18x24 = new System.Windows.Forms.TextBox();
            this.txt14x17 = new System.Windows.Forms.TextBox();
            this.txt30x40 = new System.Windows.Forms.TextBox();
            this.txtPOdonto = new System.Windows.Forms.TextBox();
            this.txtPDanada = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPEnviadas = new System.Windows.Forms.TextBox();
            this.tools = new System.Windows.Forms.ToolStrip();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.tabulador = new Infragistics.Win.UltraWinTabControl.UltraTabControl();
            this.ultraTabSharedControlsPage1 = new Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage();
            this.grid = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.ultraTabPageControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox11)).BeginInit();
            this.ultraGroupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox10)).BeginInit();
            this.ultraGroupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtPaciente)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox9)).BeginInit();
            this.ultraGroupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox8)).BeginInit();
            this.ultraGroupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridEstudios)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupBoxTipoDoc)).BeginInit();
            this.groupBoxTipoDoc.SuspendLayout();
            this.ultraTabPageControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox1)).BeginInit();
            this.ultraGroupBox1.SuspendLayout();
            this.ultraTabPageControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox3)).BeginInit();
            this.ultraGroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox2)).BeginInit();
            this.ultraGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.ultraTabPageControl11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox5)).BeginInit();
            this.ultraGroupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox4)).BeginInit();
            this.ultraGroupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDiagnosticos)).BeginInit();
            this.ultraTabPageControl6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox7)).BeginInit();
            this.ultraGroupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox6)).BeginInit();
            this.ultraGroupBox6.SuspendLayout();
            this.tools.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabulador)).BeginInit();
            this.tabulador.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            this.SuspendLayout();
            // 
            // ultraTabPageControl1
            // 
            this.ultraTabPageControl1.Controls.Add(this.ultraGroupBox11);
            this.ultraTabPageControl1.Controls.Add(this.ultraGroupBox10);
            this.ultraTabPageControl1.Controls.Add(this.ultraGroupBox9);
            this.ultraTabPageControl1.Controls.Add(this.ultraGroupBox8);
            this.ultraTabPageControl1.Controls.Add(this.groupBoxTipoDoc);
            this.ultraTabPageControl1.Location = new System.Drawing.Point(1, 22);
            this.ultraTabPageControl1.Name = "ultraTabPageControl1";
            this.ultraTabPageControl1.Size = new System.Drawing.Size(784, 468);
            // 
            // ultraGroupBox11
            // 
            this.ultraGroupBox11.Controls.Add(this.ultraLabel5);
            this.ultraGroupBox11.Controls.Add(this.txtMedicoCOD);
            this.ultraGroupBox11.Controls.Add(this.txtMedico);
            this.ultraGroupBox11.Controls.Add(this.btnAddMedico);
            this.ultraGroupBox11.ForeColor = System.Drawing.Color.Black;
            appearance21.FontData.BoldAsString = "True";
            appearance21.ForeColor = System.Drawing.Color.DimGray;
            appearance21.TextHAlignAsString = "Right";
            this.ultraGroupBox11.HeaderAppearance = appearance21;
            this.ultraGroupBox11.HeaderPosition = Infragistics.Win.Misc.GroupBoxHeaderPosition.TopOnBorder;
            this.ultraGroupBox11.Location = new System.Drawing.Point(18, 155);
            this.ultraGroupBox11.Name = "ultraGroupBox11";
            this.ultraGroupBox11.Size = new System.Drawing.Size(601, 48);
            this.ultraGroupBox11.TabIndex = 102;
            // 
            // ultraLabel5
            // 
            this.ultraLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel5.Location = new System.Drawing.Point(22, 18);
            this.ultraLabel5.Name = "ultraLabel5";
            this.ultraLabel5.Size = new System.Drawing.Size(108, 24);
            this.ultraLabel5.TabIndex = 98;
            this.ultraLabel5.Text = "Médico solicitante:";
            // 
            // txtMedicoCOD
            // 
            this.txtMedicoCOD.Location = new System.Drawing.Point(529, 15);
            this.txtMedicoCOD.Name = "txtMedicoCOD";
            this.txtMedicoCOD.Size = new System.Drawing.Size(38, 20);
            this.txtMedicoCOD.TabIndex = 100;
            this.txtMedicoCOD.Visible = false;
            // 
            // txtMedico
            // 
            this.txtMedico.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMedico.Location = new System.Drawing.Point(170, 15);
            this.txtMedico.Name = "txtMedico";
            this.txtMedico.ReadOnly = true;
            this.txtMedico.Size = new System.Drawing.Size(353, 20);
            this.txtMedico.TabIndex = 101;
            // 
            // btnAddMedico
            // 
            this.btnAddMedico.Location = new System.Drawing.Point(136, 13);
            this.btnAddMedico.Name = "btnAddMedico";
            this.btnAddMedico.Size = new System.Drawing.Size(28, 22);
            this.btnAddMedico.TabIndex = 99;
            this.btnAddMedico.Text = "...";
            this.btnAddMedico.UseVisualStyleBackColor = true;
            this.btnAddMedico.Click += new System.EventHandler(this.btnAddMedico_Click);
            // 
            // ultraGroupBox10
            // 
            this.ultraGroupBox10.Controls.Add(this.txtPaciente);
            this.ultraGroupBox10.Controls.Add(this.label8);
            this.ultraGroupBox10.ForeColor = System.Drawing.Color.Black;
            appearance24.FontData.BoldAsString = "True";
            appearance24.ForeColor = System.Drawing.Color.DimGray;
            appearance24.TextHAlignAsString = "Right";
            this.ultraGroupBox10.HeaderAppearance = appearance24;
            this.ultraGroupBox10.HeaderPosition = Infragistics.Win.Misc.GroupBoxHeaderPosition.TopOnBorder;
            this.ultraGroupBox10.Location = new System.Drawing.Point(18, 13);
            this.ultraGroupBox10.Name = "ultraGroupBox10";
            this.ultraGroupBox10.Size = new System.Drawing.Size(597, 48);
            this.ultraGroupBox10.TabIndex = 97;
            // 
            // txtPaciente
            // 
            appearance23.BackColor = System.Drawing.Color.White;
            this.txtPaciente.Appearance = appearance23;
            this.txtPaciente.BackColor = System.Drawing.Color.White;
            this.txtPaciente.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1;
            this.txtPaciente.DisplayStyle = Infragistics.Win.EmbeddableElementDisplayStyle.ScenicRibbon;
            this.txtPaciente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPaciente.Location = new System.Drawing.Point(82, 17);
            this.txtPaciente.Name = "txtPaciente";
            this.txtPaciente.ReadOnly = true;
            this.txtPaciente.Size = new System.Drawing.Size(498, 21);
            this.txtPaciente.TabIndex = 97;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(24, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 13);
            this.label8.TabIndex = 96;
            this.label8.Text = "Paciente:";
            // 
            // ultraGroupBox9
            // 
            this.ultraGroupBox9.Controls.Add(this.dtpEntrega);
            this.ultraGroupBox9.Controls.Add(this.label10);
            this.ultraGroupBox9.Controls.Add(this.dtpInforme);
            this.ultraGroupBox9.Controls.Add(this.label58);
            this.ultraGroupBox9.ForeColor = System.Drawing.Color.Black;
            appearance14.FontData.BoldAsString = "True";
            appearance14.ForeColor = System.Drawing.Color.DimGray;
            appearance14.TextHAlignAsString = "Right";
            this.ultraGroupBox9.HeaderAppearance = appearance14;
            this.ultraGroupBox9.HeaderPosition = Infragistics.Win.Misc.GroupBoxHeaderPosition.TopOnBorder;
            this.ultraGroupBox9.Location = new System.Drawing.Point(335, 76);
            this.ultraGroupBox9.Name = "ultraGroupBox9";
            this.ultraGroupBox9.Size = new System.Drawing.Size(280, 73);
            this.ultraGroupBox9.TabIndex = 3;
            // 
            // dtpEntrega
            // 
            this.dtpEntrega.CustomFormat = "  /  /       :  ";
            this.dtpEntrega.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEntrega.Location = new System.Drawing.Point(155, 37);
            this.dtpEntrega.MaxDate = new System.DateTime(3000, 12, 31, 0, 0, 0, 0);
            this.dtpEntrega.Name = "dtpEntrega";
            this.dtpEntrega.Size = new System.Drawing.Size(108, 20);
            this.dtpEntrega.TabIndex = 96;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(26, 40);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(95, 13);
            this.label10.TabIndex = 97;
            this.label10.Text = "Fecha de Entrega:";
            // 
            // dtpInforme
            // 
            this.dtpInforme.CustomFormat = "  /  /       :  ";
            this.dtpInforme.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpInforme.Location = new System.Drawing.Point(155, 11);
            this.dtpInforme.MaxDate = new System.DateTime(3000, 12, 31, 0, 0, 0, 0);
            this.dtpInforme.Name = "dtpInforme";
            this.dtpInforme.Size = new System.Drawing.Size(108, 20);
            this.dtpInforme.TabIndex = 1;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.ForeColor = System.Drawing.Color.Black;
            this.label58.Location = new System.Drawing.Point(26, 14);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(93, 13);
            this.label58.TabIndex = 95;
            this.label58.Text = "Fecha de Informe:";
            // 
            // ultraGroupBox8
            // 
            this.ultraGroupBox8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.ultraGroupBox8.Controls.Add(this.gridEstudios);
            this.ultraGroupBox8.ForeColor = System.Drawing.Color.Black;
            appearance1.FontData.BoldAsString = "True";
            appearance1.ForeColor = System.Drawing.Color.DimGray;
            appearance1.TextHAlignAsString = "Right";
            this.ultraGroupBox8.HeaderAppearance = appearance1;
            this.ultraGroupBox8.HeaderPosition = Infragistics.Win.Misc.GroupBoxHeaderPosition.TopOnBorder;
            this.ultraGroupBox8.Location = new System.Drawing.Point(18, 250);
            this.ultraGroupBox8.Name = "ultraGroupBox8";
            this.ultraGroupBox8.Size = new System.Drawing.Size(597, 202);
            this.ultraGroupBox8.TabIndex = 96;
            this.ultraGroupBox8.Text = "1. ESTUDIO DE IMAGENOLOGIA REALIZADO";
            this.ultraGroupBox8.Click += new System.EventHandler(this.ultraGroupBox8_Click);
            // 
            // gridEstudios
            // 
            this.gridEstudios.AllowUserToAddRows = false;
            this.gridEstudios.AllowUserToDeleteRows = false;
            this.gridEstudios.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridEstudios.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridEstudios.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gridEstudios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridEstudios.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.ESTUDIO,
            this.CODSUB});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridEstudios.DefaultCellStyle = dataGridViewCellStyle2;
            this.gridEstudios.Location = new System.Drawing.Point(27, 26);
            this.gridEstudios.Name = "gridEstudios";
            this.gridEstudios.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridEstudios.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.gridEstudios.Size = new System.Drawing.Size(553, 164);
            this.gridEstudios.TabIndex = 38;
            // 
            // ID
            // 
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Width = 50;
            // 
            // ESTUDIO
            // 
            this.ESTUDIO.HeaderText = "ESTUDIO";
            this.ESTUDIO.Name = "ESTUDIO";
            this.ESTUDIO.ReadOnly = true;
            this.ESTUDIO.Width = 250;
            // 
            // CODSUB
            // 
            this.CODSUB.HeaderText = "CODSUB";
            this.CODSUB.Name = "CODSUB";
            this.CODSUB.ReadOnly = true;
            this.CODSUB.Visible = false;
            // 
            // groupBoxTipoDoc
            // 
            this.groupBoxTipoDoc.Controls.Add(this.rbControl);
            this.groupBoxTipoDoc.Controls.Add(this.rbNormal);
            this.groupBoxTipoDoc.Controls.Add(this.rdUrgente);
            this.groupBoxTipoDoc.ForeColor = System.Drawing.Color.Black;
            appearance20.FontData.BoldAsString = "True";
            appearance20.ForeColor = System.Drawing.Color.DimGray;
            appearance20.TextHAlignAsString = "Right";
            this.groupBoxTipoDoc.HeaderAppearance = appearance20;
            this.groupBoxTipoDoc.HeaderPosition = Infragistics.Win.Misc.GroupBoxHeaderPosition.TopOnBorder;
            this.groupBoxTipoDoc.Location = new System.Drawing.Point(18, 67);
            this.groupBoxTipoDoc.Name = "groupBoxTipoDoc";
            this.groupBoxTipoDoc.Size = new System.Drawing.Size(299, 66);
            this.groupBoxTipoDoc.TabIndex = 0;
            this.groupBoxTipoDoc.Text = "Prioridad del Informe";
            // 
            // rbControl
            // 
            this.rbControl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rbControl.AutoSize = true;
            this.rbControl.Checked = true;
            this.rbControl.Location = new System.Drawing.Point(216, 33);
            this.rbControl.Name = "rbControl";
            this.rbControl.Size = new System.Drawing.Size(58, 17);
            this.rbControl.TabIndex = 2;
            this.rbControl.TabStop = true;
            this.rbControl.Text = "Control";
            this.rbControl.UseVisualStyleBackColor = true;
            // 
            // rbNormal
            // 
            this.rbNormal.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rbNormal.AutoSize = true;
            this.rbNormal.Location = new System.Drawing.Point(132, 33);
            this.rbNormal.Name = "rbNormal";
            this.rbNormal.Size = new System.Drawing.Size(58, 17);
            this.rbNormal.TabIndex = 1;
            this.rbNormal.Text = "Normal";
            this.rbNormal.UseVisualStyleBackColor = true;
            // 
            // rdUrgente
            // 
            this.rdUrgente.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rdUrgente.AutoSize = true;
            this.rdUrgente.Location = new System.Drawing.Point(46, 33);
            this.rdUrgente.Name = "rdUrgente";
            this.rdUrgente.Size = new System.Drawing.Size(63, 17);
            this.rdUrgente.TabIndex = 0;
            this.rdUrgente.Text = "Urgente";
            this.rdUrgente.UseVisualStyleBackColor = true;
            // 
            // ultraTabPageControl2
            // 
            this.ultraTabPageControl2.Controls.Add(this.ultraGroupBox1);
            this.ultraTabPageControl2.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabPageControl2.Name = "ultraTabPageControl2";
            this.ultraTabPageControl2.Size = new System.Drawing.Size(784, 468);
            // 
            // ultraGroupBox1
            // 
            this.ultraGroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.ultraGroupBox1.Controls.Add(this.txt_diagnosticoMedico);
            this.ultraGroupBox1.ForeColor = System.Drawing.Color.Black;
            appearance17.FontData.BoldAsString = "True";
            appearance17.ForeColor = System.Drawing.Color.DimGray;
            appearance17.TextHAlignAsString = "Right";
            this.ultraGroupBox1.HeaderAppearance = appearance17;
            this.ultraGroupBox1.HeaderPosition = Infragistics.Win.Misc.GroupBoxHeaderPosition.TopOnBorder;
            this.ultraGroupBox1.Location = new System.Drawing.Point(19, 27);
            this.ultraGroupBox1.Name = "ultraGroupBox1";
            this.ultraGroupBox1.Size = new System.Drawing.Size(509, 424);
            this.ultraGroupBox1.TabIndex = 1;
            this.ultraGroupBox1.Text = "2. INFORME DE IMAGENOLOGIA";
            // 
            // txt_diagnosticoMedico
            // 
            this.txt_diagnosticoMedico.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_diagnosticoMedico.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_diagnosticoMedico.Location = new System.Drawing.Point(16, 31);
            this.txt_diagnosticoMedico.Multiline = true;
            this.txt_diagnosticoMedico.Name = "txt_diagnosticoMedico";
            this.txt_diagnosticoMedico.Size = new System.Drawing.Size(473, 373);
            this.txt_diagnosticoMedico.TabIndex = 11;
            // 
            // ultraTabPageControl3
            // 
            this.ultraTabPageControl3.Controls.Add(this.ultraGroupBox3);
            this.ultraTabPageControl3.Controls.Add(this.ultraGroupBox2);
            this.ultraTabPageControl3.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabPageControl3.Name = "ultraTabPageControl3";
            this.ultraTabPageControl3.Size = new System.Drawing.Size(784, 468);
            // 
            // ultraGroupBox3
            // 
            this.ultraGroupBox3.Controls.Add(this.txt_sacoDouglas);
            this.ultraGroupBox3.Controls.Add(this.chkOcupada);
            this.ultraGroupBox3.Controls.Add(this.chkVacia);
            this.ultraGroupBox3.Controls.Add(this.chkQuiste);
            this.ultraGroupBox3.Controls.Add(this.chkHidrosalpix);
            this.ultraGroupBox3.Controls.Add(this.chkAusente);
            this.ultraGroupBox3.Controls.Add(this.chkMioma);
            this.ultraGroupBox3.Controls.Add(this.chkFibroma);
            this.ultraGroupBox3.Controls.Add(this.chkDiu);
            this.ultraGroupBox3.Controls.Add(this.chkRetroversion);
            this.ultraGroupBox3.Controls.Add(this.chkAnteversion);
            this.ultraGroupBox3.Controls.Add(this.pictureBox2);
            this.ultraGroupBox3.ForeColor = System.Drawing.Color.Black;
            appearance52.FontData.BoldAsString = "True";
            appearance52.ForeColor = System.Drawing.Color.DimGray;
            appearance52.TextHAlignAsString = "Right";
            this.ultraGroupBox3.HeaderAppearance = appearance52;
            this.ultraGroupBox3.HeaderPosition = Infragistics.Win.Misc.GroupBoxHeaderPosition.TopOnBorder;
            this.ultraGroupBox3.Location = new System.Drawing.Point(15, 209);
            this.ultraGroupBox3.Name = "ultraGroupBox3";
            this.ultraGroupBox3.Size = new System.Drawing.Size(468, 178);
            this.ultraGroupBox3.TabIndex = 3;
            this.ultraGroupBox3.Text = "4.  DATOS BASICOS DE ECOGRAFIA GINECOLOGICA";
            // 
            // txt_sacoDouglas
            // 
            this.txt_sacoDouglas.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_sacoDouglas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_sacoDouglas.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_sacoDouglas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_sacoDouglas.Location = new System.Drawing.Point(99, 139);
            this.txt_sacoDouglas.MaxLength = 255;
            this.txt_sacoDouglas.Multiline = true;
            this.txt_sacoDouglas.Name = "txt_sacoDouglas";
            this.txt_sacoDouglas.Size = new System.Drawing.Size(343, 20);
            this.txt_sacoDouglas.TabIndex = 20;
            // 
            // chkOcupada
            // 
            this.chkOcupada.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkOcupada.AutoSize = true;
            this.chkOcupada.BackColor = System.Drawing.Color.Transparent;
            this.chkOcupada.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOcupada.ForeColor = System.Drawing.Color.LightSlateGray;
            this.chkOcupada.Location = new System.Drawing.Point(428, 116);
            this.chkOcupada.Name = "chkOcupada";
            this.chkOcupada.Size = new System.Drawing.Size(15, 14);
            this.chkOcupada.TabIndex = 19;
            this.chkOcupada.UseVisualStyleBackColor = false;
            // 
            // chkVacia
            // 
            this.chkVacia.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkVacia.AutoSize = true;
            this.chkVacia.BackColor = System.Drawing.Color.Transparent;
            this.chkVacia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkVacia.ForeColor = System.Drawing.Color.LightSlateGray;
            this.chkVacia.Location = new System.Drawing.Point(314, 116);
            this.chkVacia.Name = "chkVacia";
            this.chkVacia.Size = new System.Drawing.Size(15, 14);
            this.chkVacia.TabIndex = 18;
            this.chkVacia.UseVisualStyleBackColor = false;
            // 
            // chkQuiste
            // 
            this.chkQuiste.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkQuiste.AutoSize = true;
            this.chkQuiste.BackColor = System.Drawing.Color.Transparent;
            this.chkQuiste.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkQuiste.ForeColor = System.Drawing.Color.LightSlateGray;
            this.chkQuiste.Location = new System.Drawing.Point(428, 58);
            this.chkQuiste.Name = "chkQuiste";
            this.chkQuiste.Size = new System.Drawing.Size(15, 14);
            this.chkQuiste.TabIndex = 17;
            this.chkQuiste.UseVisualStyleBackColor = false;
            // 
            // chkHidrosalpix
            // 
            this.chkHidrosalpix.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkHidrosalpix.AutoSize = true;
            this.chkHidrosalpix.BackColor = System.Drawing.Color.Transparent;
            this.chkHidrosalpix.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkHidrosalpix.ForeColor = System.Drawing.Color.LightSlateGray;
            this.chkHidrosalpix.Location = new System.Drawing.Point(314, 58);
            this.chkHidrosalpix.Name = "chkHidrosalpix";
            this.chkHidrosalpix.Size = new System.Drawing.Size(15, 14);
            this.chkHidrosalpix.TabIndex = 16;
            this.chkHidrosalpix.UseVisualStyleBackColor = false;
            // 
            // chkAusente
            // 
            this.chkAusente.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkAusente.AutoSize = true;
            this.chkAusente.BackColor = System.Drawing.Color.Transparent;
            this.chkAusente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkAusente.ForeColor = System.Drawing.Color.LightSlateGray;
            this.chkAusente.Location = new System.Drawing.Point(214, 116);
            this.chkAusente.Name = "chkAusente";
            this.chkAusente.Size = new System.Drawing.Size(15, 14);
            this.chkAusente.TabIndex = 15;
            this.chkAusente.UseVisualStyleBackColor = false;
            // 
            // chkMioma
            // 
            this.chkMioma.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkMioma.AutoSize = true;
            this.chkMioma.BackColor = System.Drawing.Color.Transparent;
            this.chkMioma.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMioma.ForeColor = System.Drawing.Color.LightSlateGray;
            this.chkMioma.Location = new System.Drawing.Point(214, 87);
            this.chkMioma.Name = "chkMioma";
            this.chkMioma.Size = new System.Drawing.Size(15, 14);
            this.chkMioma.TabIndex = 14;
            this.chkMioma.UseVisualStyleBackColor = false;
            // 
            // chkFibroma
            // 
            this.chkFibroma.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkFibroma.AutoSize = true;
            this.chkFibroma.BackColor = System.Drawing.Color.Transparent;
            this.chkFibroma.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkFibroma.ForeColor = System.Drawing.Color.LightSlateGray;
            this.chkFibroma.Location = new System.Drawing.Point(214, 58);
            this.chkFibroma.Name = "chkFibroma";
            this.chkFibroma.Size = new System.Drawing.Size(15, 14);
            this.chkFibroma.TabIndex = 13;
            this.chkFibroma.UseVisualStyleBackColor = false;
            // 
            // chkDiu
            // 
            this.chkDiu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkDiu.AutoSize = true;
            this.chkDiu.BackColor = System.Drawing.Color.Transparent;
            this.chkDiu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDiu.ForeColor = System.Drawing.Color.LightSlateGray;
            this.chkDiu.Location = new System.Drawing.Point(100, 116);
            this.chkDiu.Name = "chkDiu";
            this.chkDiu.Size = new System.Drawing.Size(15, 14);
            this.chkDiu.TabIndex = 12;
            this.chkDiu.UseVisualStyleBackColor = false;
            // 
            // chkRetroversion
            // 
            this.chkRetroversion.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkRetroversion.AutoSize = true;
            this.chkRetroversion.BackColor = System.Drawing.Color.Transparent;
            this.chkRetroversion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRetroversion.ForeColor = System.Drawing.Color.LightSlateGray;
            this.chkRetroversion.Location = new System.Drawing.Point(100, 87);
            this.chkRetroversion.Name = "chkRetroversion";
            this.chkRetroversion.Size = new System.Drawing.Size(15, 14);
            this.chkRetroversion.TabIndex = 11;
            this.chkRetroversion.UseVisualStyleBackColor = false;
            // 
            // chkAnteversion
            // 
            this.chkAnteversion.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkAnteversion.AutoSize = true;
            this.chkAnteversion.BackColor = System.Drawing.Color.Transparent;
            this.chkAnteversion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkAnteversion.ForeColor = System.Drawing.Color.LightSlateGray;
            this.chkAnteversion.Location = new System.Drawing.Point(100, 58);
            this.chkAnteversion.Name = "chkAnteversion";
            this.chkAnteversion.Size = new System.Drawing.Size(15, 14);
            this.chkAnteversion.TabIndex = 10;
            this.chkAnteversion.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(8, 19);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(440, 146);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // ultraGroupBox2
            // 
            this.ultraGroupBox2.Controls.Add(this.txt_gradomadurez);
            this.ultraGroupBox2.Controls.Add(this.txt_pap);
            this.ultraGroupBox2.Controls.Add(this.txt_paeg);
            this.ultraGroupBox2.Controls.Add(this.txt_pav);
            this.ultraGroupBox2.Controls.Add(this.txt_lfp);
            this.ultraGroupBox2.Controls.Add(this.txt_lfeg);
            this.ultraGroupBox2.Controls.Add(this.txt_lfv);
            this.ultraGroupBox2.Controls.Add(this.txt_dbp);
            this.ultraGroupBox2.Controls.Add(this.txt_dbeg);
            this.ultraGroupBox2.Controls.Add(this.txt_dbv);
            this.ultraGroupBox2.Controls.Add(this.chkMultiple);
            this.ultraGroupBox2.Controls.Add(this.chkFemenino);
            this.ultraGroupBox2.Controls.Add(this.chkMasculino);
            this.ultraGroupBox2.Controls.Add(this.chkPrevia);
            this.ultraGroupBox2.Controls.Add(this.chkMarginal);
            this.ultraGroupBox2.Controls.Add(this.chkFundica);
            this.ultraGroupBox2.Controls.Add(this.pictureBox1);
            this.ultraGroupBox2.ForeColor = System.Drawing.Color.Black;
            appearance19.FontData.BoldAsString = "True";
            appearance19.ForeColor = System.Drawing.Color.DimGray;
            appearance19.TextHAlignAsString = "Right";
            this.ultraGroupBox2.HeaderAppearance = appearance19;
            this.ultraGroupBox2.HeaderPosition = Infragistics.Win.Misc.GroupBoxHeaderPosition.TopOnBorder;
            this.ultraGroupBox2.Location = new System.Drawing.Point(15, 19);
            this.ultraGroupBox2.Name = "ultraGroupBox2";
            this.ultraGroupBox2.Size = new System.Drawing.Size(468, 184);
            this.ultraGroupBox2.TabIndex = 2;
            this.ultraGroupBox2.Text = "3. DATOS BASICOS DE ECOGRAFIA OBSTETRICA";
            // 
            // txt_gradomadurez
            // 
            this.txt_gradomadurez.BackColor = System.Drawing.SystemColors.Window;
            this.txt_gradomadurez.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_gradomadurez.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_gradomadurez.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_gradomadurez.Location = new System.Drawing.Point(341, 147);
            this.txt_gradomadurez.MaxLength = 20;
            this.txt_gradomadurez.Name = "txt_gradomadurez";
            this.txt_gradomadurez.Size = new System.Drawing.Size(48, 15);
            this.txt_gradomadurez.TabIndex = 103;
            // 
            // txt_pap
            // 
            this.txt_pap.BackColor = System.Drawing.SystemColors.Window;
            this.txt_pap.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_pap.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_pap.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_pap.Location = new System.Drawing.Point(208, 119);
            this.txt_pap.MaxLength = 20;
            this.txt_pap.Name = "txt_pap";
            this.txt_pap.Size = new System.Drawing.Size(48, 15);
            this.txt_pap.TabIndex = 102;
            // 
            // txt_paeg
            // 
            this.txt_paeg.BackColor = System.Drawing.SystemColors.Window;
            this.txt_paeg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_paeg.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_paeg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_paeg.Location = new System.Drawing.Point(154, 119);
            this.txt_paeg.MaxLength = 20;
            this.txt_paeg.Name = "txt_paeg";
            this.txt_paeg.Size = new System.Drawing.Size(48, 15);
            this.txt_paeg.TabIndex = 101;
            // 
            // txt_pav
            // 
            this.txt_pav.BackColor = System.Drawing.SystemColors.Window;
            this.txt_pav.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_pav.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_pav.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_pav.Location = new System.Drawing.Point(100, 119);
            this.txt_pav.MaxLength = 20;
            this.txt_pav.Name = "txt_pav";
            this.txt_pav.Size = new System.Drawing.Size(48, 15);
            this.txt_pav.TabIndex = 100;
            // 
            // txt_lfp
            // 
            this.txt_lfp.BackColor = System.Drawing.SystemColors.Window;
            this.txt_lfp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_lfp.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_lfp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_lfp.Location = new System.Drawing.Point(208, 89);
            this.txt_lfp.MaxLength = 20;
            this.txt_lfp.Name = "txt_lfp";
            this.txt_lfp.Size = new System.Drawing.Size(48, 15);
            this.txt_lfp.TabIndex = 99;
            // 
            // txt_lfeg
            // 
            this.txt_lfeg.BackColor = System.Drawing.SystemColors.Window;
            this.txt_lfeg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_lfeg.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_lfeg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_lfeg.Location = new System.Drawing.Point(154, 89);
            this.txt_lfeg.MaxLength = 20;
            this.txt_lfeg.Name = "txt_lfeg";
            this.txt_lfeg.Size = new System.Drawing.Size(48, 15);
            this.txt_lfeg.TabIndex = 98;
            // 
            // txt_lfv
            // 
            this.txt_lfv.BackColor = System.Drawing.SystemColors.Window;
            this.txt_lfv.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_lfv.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_lfv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_lfv.Location = new System.Drawing.Point(100, 89);
            this.txt_lfv.MaxLength = 20;
            this.txt_lfv.Name = "txt_lfv";
            this.txt_lfv.Size = new System.Drawing.Size(48, 15);
            this.txt_lfv.TabIndex = 97;
            // 
            // txt_dbp
            // 
            this.txt_dbp.BackColor = System.Drawing.SystemColors.Window;
            this.txt_dbp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_dbp.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_dbp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dbp.Location = new System.Drawing.Point(204, 58);
            this.txt_dbp.MaxLength = 20;
            this.txt_dbp.Name = "txt_dbp";
            this.txt_dbp.Size = new System.Drawing.Size(48, 15);
            this.txt_dbp.TabIndex = 96;
            // 
            // txt_dbeg
            // 
            this.txt_dbeg.BackColor = System.Drawing.SystemColors.Window;
            this.txt_dbeg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_dbeg.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_dbeg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dbeg.Location = new System.Drawing.Point(153, 58);
            this.txt_dbeg.MaxLength = 20;
            this.txt_dbeg.Name = "txt_dbeg";
            this.txt_dbeg.Size = new System.Drawing.Size(48, 15);
            this.txt_dbeg.TabIndex = 95;
            // 
            // txt_dbv
            // 
            this.txt_dbv.BackColor = System.Drawing.SystemColors.Window;
            this.txt_dbv.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_dbv.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_dbv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dbv.Location = new System.Drawing.Point(99, 59);
            this.txt_dbv.MaxLength = 20;
            this.txt_dbv.Name = "txt_dbv";
            this.txt_dbv.Size = new System.Drawing.Size(48, 15);
            this.txt_dbv.TabIndex = 94;
            // 
            // chkMultiple
            // 
            this.chkMultiple.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkMultiple.AutoSize = true;
            this.chkMultiple.BackColor = System.Drawing.Color.Transparent;
            this.chkMultiple.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMultiple.ForeColor = System.Drawing.Color.LightSlateGray;
            this.chkMultiple.Location = new System.Drawing.Point(237, 147);
            this.chkMultiple.Name = "chkMultiple";
            this.chkMultiple.Size = new System.Drawing.Size(15, 14);
            this.chkMultiple.TabIndex = 9;
            this.chkMultiple.UseVisualStyleBackColor = false;
            // 
            // chkFemenino
            // 
            this.chkFemenino.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkFemenino.AutoSize = true;
            this.chkFemenino.BackColor = System.Drawing.Color.Transparent;
            this.chkFemenino.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkFemenino.ForeColor = System.Drawing.Color.LightSlateGray;
            this.chkFemenino.Location = new System.Drawing.Point(156, 147);
            this.chkFemenino.Name = "chkFemenino";
            this.chkFemenino.Size = new System.Drawing.Size(15, 14);
            this.chkFemenino.TabIndex = 8;
            this.chkFemenino.UseVisualStyleBackColor = false;
            // 
            // chkMasculino
            // 
            this.chkMasculino.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkMasculino.AutoSize = true;
            this.chkMasculino.BackColor = System.Drawing.Color.Transparent;
            this.chkMasculino.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMasculino.ForeColor = System.Drawing.Color.LightSlateGray;
            this.chkMasculino.Location = new System.Drawing.Point(75, 147);
            this.chkMasculino.Name = "chkMasculino";
            this.chkMasculino.Size = new System.Drawing.Size(15, 14);
            this.chkMasculino.TabIndex = 7;
            this.chkMasculino.UseVisualStyleBackColor = false;
            // 
            // chkPrevia
            // 
            this.chkPrevia.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkPrevia.AutoSize = true;
            this.chkPrevia.BackColor = System.Drawing.Color.Transparent;
            this.chkPrevia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPrevia.ForeColor = System.Drawing.Color.LightSlateGray;
            this.chkPrevia.Location = new System.Drawing.Point(370, 119);
            this.chkPrevia.Name = "chkPrevia";
            this.chkPrevia.Size = new System.Drawing.Size(15, 14);
            this.chkPrevia.TabIndex = 6;
            this.chkPrevia.UseVisualStyleBackColor = false;
            // 
            // chkMarginal
            // 
            this.chkMarginal.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkMarginal.AutoSize = true;
            this.chkMarginal.BackColor = System.Drawing.Color.Transparent;
            this.chkMarginal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMarginal.ForeColor = System.Drawing.Color.LightSlateGray;
            this.chkMarginal.Location = new System.Drawing.Point(370, 91);
            this.chkMarginal.Name = "chkMarginal";
            this.chkMarginal.Size = new System.Drawing.Size(15, 14);
            this.chkMarginal.TabIndex = 5;
            this.chkMarginal.UseVisualStyleBackColor = false;
            // 
            // chkFundica
            // 
            this.chkFundica.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkFundica.AutoSize = true;
            this.chkFundica.BackColor = System.Drawing.Color.Transparent;
            this.chkFundica.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkFundica.ForeColor = System.Drawing.Color.LightSlateGray;
            this.chkFundica.Location = new System.Drawing.Point(370, 58);
            this.chkFundica.Name = "chkFundica";
            this.chkFundica.Size = new System.Drawing.Size(15, 14);
            this.chkFundica.TabIndex = 4;
            this.chkFundica.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(15, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(378, 150);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // ultraTabPageControl11
            // 
            this.ultraTabPageControl11.Controls.Add(this.ultraGroupBox5);
            this.ultraTabPageControl11.Controls.Add(this.ultraGroupBox4);
            this.ultraTabPageControl11.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabPageControl11.Name = "ultraTabPageControl11";
            this.ultraTabPageControl11.Size = new System.Drawing.Size(784, 468);
            // 
            // ultraGroupBox5
            // 
            this.ultraGroupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ultraGroupBox5.Controls.Add(this.txtRecomendaciones);
            this.ultraGroupBox5.ForeColor = System.Drawing.Color.Black;
            appearance15.FontData.BoldAsString = "True";
            appearance15.ForeColor = System.Drawing.Color.DimGray;
            appearance15.TextHAlignAsString = "Right";
            this.ultraGroupBox5.HeaderAppearance = appearance15;
            this.ultraGroupBox5.HeaderPosition = Infragistics.Win.Misc.GroupBoxHeaderPosition.TopOnBorder;
            this.ultraGroupBox5.Location = new System.Drawing.Point(15, 180);
            this.ultraGroupBox5.Name = "ultraGroupBox5";
            this.ultraGroupBox5.Size = new System.Drawing.Size(560, 279);
            this.ultraGroupBox5.TabIndex = 38;
            this.ultraGroupBox5.Text = "6. RECOMENDACIONES";
            // 
            // txtRecomendaciones
            // 
            this.txtRecomendaciones.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRecomendaciones.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtRecomendaciones.Location = new System.Drawing.Point(16, 24);
            this.txtRecomendaciones.Multiline = true;
            this.txtRecomendaciones.Name = "txtRecomendaciones";
            this.txtRecomendaciones.Size = new System.Drawing.Size(521, 237);
            this.txtRecomendaciones.TabIndex = 11;
            // 
            // ultraGroupBox4
            // 
            this.ultraGroupBox4.Controls.Add(this.btnAddDiagnotico);
            this.ultraGroupBox4.Controls.Add(this.gridDiagnosticos);
            this.ultraGroupBox4.ForeColor = System.Drawing.Color.Black;
            appearance22.FontData.BoldAsString = "True";
            appearance22.ForeColor = System.Drawing.Color.DimGray;
            appearance22.TextHAlignAsString = "Right";
            this.ultraGroupBox4.HeaderAppearance = appearance22;
            this.ultraGroupBox4.HeaderPosition = Infragistics.Win.Misc.GroupBoxHeaderPosition.TopOnBorder;
            this.ultraGroupBox4.Location = new System.Drawing.Point(13, 21);
            this.ultraGroupBox4.Name = "ultraGroupBox4";
            this.ultraGroupBox4.Size = new System.Drawing.Size(562, 153);
            this.ultraGroupBox4.TabIndex = 37;
            this.ultraGroupBox4.Text = "5. DIAGNOSTICOS DE IMAGENOLOGIA";
            // 
            // btnAddDiagnotico
            // 
            this.btnAddDiagnotico.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddDiagnotico.Image = ((System.Drawing.Image)(resources.GetObject("btnAddDiagnotico.Image")));
            this.btnAddDiagnotico.Location = new System.Drawing.Point(6, 26);
            this.btnAddDiagnotico.Name = "btnAddDiagnotico";
            this.btnAddDiagnotico.Size = new System.Drawing.Size(41, 42);
            this.btnAddDiagnotico.TabIndex = 37;
            this.btnAddDiagnotico.UseVisualStyleBackColor = true;
            this.btnAddDiagnotico.Click += new System.EventHandler(this.btnAddDiagnotico_Click);
            // 
            // gridDiagnosticos
            // 
            this.gridDiagnosticos.AllowUserToAddRows = false;
            this.gridDiagnosticos.AllowUserToOrderColumns = true;
            this.gridDiagnosticos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridDiagnosticos.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridDiagnosticos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.gridDiagnosticos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridDiagnosticos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CIE10,
            this.DIAGNOSTICO,
            this.TIPO});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridDiagnosticos.DefaultCellStyle = dataGridViewCellStyle5;
            this.gridDiagnosticos.Location = new System.Drawing.Point(53, 26);
            this.gridDiagnosticos.Name = "gridDiagnosticos";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridDiagnosticos.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.gridDiagnosticos.Size = new System.Drawing.Size(503, 121);
            this.gridDiagnosticos.TabIndex = 36;
            // 
            // CIE10
            // 
            this.CIE10.HeaderText = "CIE10";
            this.CIE10.Name = "CIE10";
            this.CIE10.ReadOnly = true;
            // 
            // DIAGNOSTICO
            // 
            this.DIAGNOSTICO.HeaderText = "DIAGNOSTICO";
            this.DIAGNOSTICO.Name = "DIAGNOSTICO";
            this.DIAGNOSTICO.ReadOnly = true;
            this.DIAGNOSTICO.Width = 230;
            // 
            // TIPO
            // 
            this.TIPO.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.TIPO.DisplayStyleForCurrentCellOnly = true;
            this.TIPO.HeaderText = "TIPO";
            this.TIPO.Items.AddRange(new object[] {
            "PRESUNTIVO",
            "DEFINITIVO"});
            this.TIPO.Name = "TIPO";
            this.TIPO.Width = 120;
            // 
            // ultraTabPageControl6
            // 
            this.ultraTabPageControl6.Controls.Add(this.ultraGroupBox7);
            this.ultraTabPageControl6.Controls.Add(this.ultraGroupBox6);
            this.ultraTabPageControl6.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabPageControl6.Name = "ultraTabPageControl6";
            this.ultraTabPageControl6.Size = new System.Drawing.Size(784, 468);
            // 
            // ultraGroupBox7
            // 
            this.ultraGroupBox7.Controls.Add(this.txtCODRadiologo);
            this.ultraGroupBox7.Controls.Add(this.txtRadiologo);
            this.ultraGroupBox7.Controls.Add(this.txtCODTecnologo);
            this.ultraGroupBox7.Controls.Add(this.btnRadiologo);
            this.ultraGroupBox7.Controls.Add(this.ultraLabel8);
            this.ultraGroupBox7.Controls.Add(this.ultraLabel9);
            this.ultraGroupBox7.Controls.Add(this.btnTecnologo);
            this.ultraGroupBox7.Controls.Add(this.txtTecnologo);
            this.ultraGroupBox7.ForeColor = System.Drawing.Color.Black;
            appearance16.FontData.BoldAsString = "True";
            appearance16.ForeColor = System.Drawing.Color.DimGray;
            appearance16.TextHAlignAsString = "Right";
            this.ultraGroupBox7.HeaderAppearance = appearance16;
            this.ultraGroupBox7.HeaderPosition = Infragistics.Win.Misc.GroupBoxHeaderPosition.TopOnBorder;
            this.ultraGroupBox7.Location = new System.Drawing.Point(15, 209);
            this.ultraGroupBox7.Name = "ultraGroupBox7";
            this.ultraGroupBox7.Size = new System.Drawing.Size(378, 101);
            this.ultraGroupBox7.TabIndex = 13;
            this.ultraGroupBox7.Text = "Medicos responsable";
            // 
            // txtCODRadiologo
            // 
            this.txtCODRadiologo.Location = new System.Drawing.Point(287, 55);
            this.txtCODRadiologo.Name = "txtCODRadiologo";
            this.txtCODRadiologo.Size = new System.Drawing.Size(38, 20);
            this.txtCODRadiologo.TabIndex = 103;
            this.txtCODRadiologo.Text = "0";
            this.txtCODRadiologo.Visible = false;
            // 
            // txtRadiologo
            // 
            this.txtRadiologo.Location = new System.Drawing.Point(100, 57);
            this.txtRadiologo.Name = "txtRadiologo";
            this.txtRadiologo.ReadOnly = true;
            this.txtRadiologo.Size = new System.Drawing.Size(225, 20);
            this.txtRadiologo.TabIndex = 105;
            // 
            // txtCODTecnologo
            // 
            this.txtCODTecnologo.Location = new System.Drawing.Point(287, 29);
            this.txtCODTecnologo.Name = "txtCODTecnologo";
            this.txtCODTecnologo.Size = new System.Drawing.Size(38, 20);
            this.txtCODTecnologo.TabIndex = 102;
            this.txtCODTecnologo.Text = "0";
            this.txtCODTecnologo.Visible = false;
            // 
            // btnRadiologo
            // 
            this.btnRadiologo.Location = new System.Drawing.Point(331, 57);
            this.btnRadiologo.Name = "btnRadiologo";
            this.btnRadiologo.Size = new System.Drawing.Size(28, 21);
            this.btnRadiologo.TabIndex = 98;
            this.btnRadiologo.Text = "...";
            this.btnRadiologo.UseVisualStyleBackColor = true;
            this.btnRadiologo.Visible = false;
            // 
            // ultraLabel8
            // 
            this.ultraLabel8.Location = new System.Drawing.Point(12, 32);
            this.ultraLabel8.Name = "ultraLabel8";
            this.ultraLabel8.Size = new System.Drawing.Size(82, 17);
            this.ultraLabel8.TabIndex = 99;
            this.ultraLabel8.Text = "Tecnólogo:";
            this.ultraLabel8.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // ultraLabel9
            // 
            this.ultraLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel9.Location = new System.Drawing.Point(12, 60);
            this.ultraLabel9.Name = "ultraLabel9";
            this.ultraLabel9.Size = new System.Drawing.Size(82, 17);
            this.ultraLabel9.TabIndex = 100;
            this.ultraLabel9.Text = "Radiólogo:";
            // 
            // btnTecnologo
            // 
            this.btnTecnologo.Location = new System.Drawing.Point(331, 29);
            this.btnTecnologo.Name = "btnTecnologo";
            this.btnTecnologo.Size = new System.Drawing.Size(28, 21);
            this.btnTecnologo.TabIndex = 101;
            this.btnTecnologo.Text = "...";
            this.btnTecnologo.UseVisualStyleBackColor = true;
            this.btnTecnologo.Visible = false;
            // 
            // txtTecnologo
            // 
            this.txtTecnologo.Location = new System.Drawing.Point(100, 29);
            this.txtTecnologo.Name = "txtTecnologo";
            this.txtTecnologo.ReadOnly = true;
            this.txtTecnologo.Size = new System.Drawing.Size(225, 20);
            this.txtTecnologo.TabIndex = 104;
            // 
            // ultraGroupBox6
            // 
            this.ultraGroupBox6.Controls.Add(this.txt14x14);
            this.ultraGroupBox6.Controls.Add(this.txt8x10);
            this.ultraGroupBox6.Controls.Add(this.chkMedioContraste);
            this.ultraGroupBox6.Controls.Add(this.txt18x24);
            this.ultraGroupBox6.Controls.Add(this.txt14x17);
            this.ultraGroupBox6.Controls.Add(this.txt30x40);
            this.ultraGroupBox6.Controls.Add(this.txtPOdonto);
            this.ultraGroupBox6.Controls.Add(this.txtPDanada);
            this.ultraGroupBox6.Controls.Add(this.label9);
            this.ultraGroupBox6.Controls.Add(this.label7);
            this.ultraGroupBox6.Controls.Add(this.label6);
            this.ultraGroupBox6.Controls.Add(this.label5);
            this.ultraGroupBox6.Controls.Add(this.label4);
            this.ultraGroupBox6.Controls.Add(this.label2);
            this.ultraGroupBox6.Controls.Add(this.label1);
            this.ultraGroupBox6.Controls.Add(this.label3);
            this.ultraGroupBox6.Controls.Add(this.txtPEnviadas);
            this.ultraGroupBox6.ForeColor = System.Drawing.Color.Black;
            appearance67.FontData.BoldAsString = "True";
            appearance67.ForeColor = System.Drawing.Color.DimGray;
            this.ultraGroupBox6.HeaderAppearance = appearance67;
            this.ultraGroupBox6.Location = new System.Drawing.Point(15, 21);
            this.ultraGroupBox6.Name = "ultraGroupBox6";
            this.ultraGroupBox6.Size = new System.Drawing.Size(378, 182);
            this.ultraGroupBox6.TabIndex = 12;
            this.ultraGroupBox6.Text = "Otros";
            // 
            // txt14x14
            // 
            this.txt14x14.BackColor = System.Drawing.SystemColors.Window;
            this.txt14x14.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt14x14.Location = new System.Drawing.Point(285, 79);
            this.txt14x14.MaxLength = 20;
            this.txt14x14.Name = "txt14x14";
            this.txt14x14.Size = new System.Drawing.Size(40, 20);
            this.txt14x14.TabIndex = 96;
            // 
            // txt8x10
            // 
            this.txt8x10.BackColor = System.Drawing.SystemColors.Window;
            this.txt8x10.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt8x10.Location = new System.Drawing.Point(285, 49);
            this.txt8x10.MaxLength = 20;
            this.txt8x10.Name = "txt8x10";
            this.txt8x10.Size = new System.Drawing.Size(40, 20);
            this.txt8x10.TabIndex = 95;
            // 
            // chkMedioContraste
            // 
            this.chkMedioContraste.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkMedioContraste.AutoSize = true;
            this.chkMedioContraste.BackColor = System.Drawing.Color.Transparent;
            this.chkMedioContraste.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkMedioContraste.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.chkMedioContraste.ForeColor = System.Drawing.Color.Black;
            this.chkMedioContraste.Location = new System.Drawing.Point(6, 124);
            this.chkMedioContraste.Name = "chkMedioContraste";
            this.chkMedioContraste.Size = new System.Drawing.Size(174, 17);
            this.chkMedioContraste.TabIndex = 94;
            this.chkMedioContraste.Text = "CON MEDIO DE CONTRASTE";
            this.chkMedioContraste.UseVisualStyleBackColor = false;
            // 
            // txt18x24
            // 
            this.txt18x24.BackColor = System.Drawing.SystemColors.Window;
            this.txt18x24.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt18x24.Location = new System.Drawing.Point(285, 141);
            this.txt18x24.MaxLength = 20;
            this.txt18x24.Name = "txt18x24";
            this.txt18x24.Size = new System.Drawing.Size(40, 20);
            this.txt18x24.TabIndex = 93;
            // 
            // txt14x17
            // 
            this.txt14x17.BackColor = System.Drawing.SystemColors.Window;
            this.txt14x17.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt14x17.Location = new System.Drawing.Point(285, 111);
            this.txt14x17.MaxLength = 20;
            this.txt14x17.Name = "txt14x17";
            this.txt14x17.Size = new System.Drawing.Size(40, 20);
            this.txt14x17.TabIndex = 92;
            // 
            // txt30x40
            // 
            this.txt30x40.BackColor = System.Drawing.SystemColors.Window;
            this.txt30x40.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt30x40.Location = new System.Drawing.Point(285, 19);
            this.txt30x40.MaxLength = 20;
            this.txt30x40.Name = "txt30x40";
            this.txt30x40.Size = new System.Drawing.Size(40, 20);
            this.txt30x40.TabIndex = 91;
            // 
            // txtPOdonto
            // 
            this.txtPOdonto.BackColor = System.Drawing.SystemColors.Window;
            this.txtPOdonto.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPOdonto.Location = new System.Drawing.Point(141, 89);
            this.txtPOdonto.MaxLength = 20;
            this.txtPOdonto.Name = "txtPOdonto";
            this.txtPOdonto.Size = new System.Drawing.Size(40, 20);
            this.txtPOdonto.TabIndex = 90;
            // 
            // txtPDanada
            // 
            this.txtPDanada.BackColor = System.Drawing.SystemColors.Window;
            this.txtPDanada.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPDanada.Location = new System.Drawing.Point(141, 60);
            this.txtPDanada.MaxLength = 20;
            this.txtPDanada.Name = "txtPDanada";
            this.txtPDanada.Size = new System.Drawing.Size(40, 20);
            this.txtPDanada.TabIndex = 89;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Location = new System.Drawing.Point(13, 60);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 13);
            this.label9.TabIndex = 87;
            this.label9.Text = "PLACAS DAÑADAS";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Location = new System.Drawing.Point(16, 93);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 13);
            this.label7.TabIndex = 86;
            this.label7.Text = "ODONTOLOGICAS";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Location = new System.Drawing.Point(217, 141);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 85;
            this.label6.Text = "18 X 24";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(217, 114);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 84;
            this.label5.Text = "14 X 17";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(217, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 83;
            this.label4.Text = "14 X 14";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(223, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 82;
            this.label2.Text = "8 X 10";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(217, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 81;
            this.label1.Text = "30 X 40";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(13, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 13);
            this.label3.TabIndex = 80;
            this.label3.Text = "PLACAS ENVIADAS";
            // 
            // txtPEnviadas
            // 
            this.txtPEnviadas.BackColor = System.Drawing.SystemColors.Window;
            this.txtPEnviadas.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPEnviadas.Location = new System.Drawing.Point(141, 27);
            this.txtPEnviadas.MaxLength = 20;
            this.txtPEnviadas.Name = "txtPEnviadas";
            this.txtPEnviadas.Size = new System.Drawing.Size(40, 20);
            this.txtPEnviadas.TabIndex = 0;
            // 
            // tools
            // 
            this.tools.AutoSize = false;
            this.tools.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton3,
            this.toolStripButton4});
            this.tools.Location = new System.Drawing.Point(0, 0);
            this.tools.Name = "tools";
            this.tools.Size = new System.Drawing.Size(786, 45);
            this.tools.TabIndex = 80;
            this.tools.Text = "toolStrip1";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.AutoSize = false;
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(42, 42);
            this.toolStripButton3.Text = "toolStripButton1";
            this.toolStripButton3.ToolTipText = "Guardar";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.AutoSize = false;
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(42, 42);
            this.toolStripButton4.Text = "toolStripButton1";
            this.toolStripButton4.ToolTipText = "Cancelar";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // tabulador
            // 
            this.tabulador.Controls.Add(this.ultraTabSharedControlsPage1);
            this.tabulador.Controls.Add(this.ultraTabPageControl1);
            this.tabulador.Controls.Add(this.ultraTabPageControl2);
            this.tabulador.Controls.Add(this.ultraTabPageControl3);
            this.tabulador.Controls.Add(this.ultraTabPageControl11);
            this.tabulador.Controls.Add(this.ultraTabPageControl6);
            this.tabulador.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabulador.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabulador.Location = new System.Drawing.Point(0, 45);
            this.tabulador.Name = "tabulador";
            appearance91.FontData.BoldAsString = "True";
            appearance91.FontData.Name = "Arial";
            appearance91.FontData.SizeInPoints = 9F;
            this.tabulador.SelectedTabAppearance = appearance91;
            this.tabulador.SharedControlsPage = this.ultraTabSharedControlsPage1;
            this.tabulador.Size = new System.Drawing.Size(786, 491);
            this.tabulador.Style = Infragistics.Win.UltraWinTabControl.UltraTabControlStyle.Office2007Ribbon;
            this.tabulador.TabButtonStyle = Infragistics.Win.UIElementButtonStyle.Office2010ScrollbarButton;
            appearance92.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(181)))), ((int)(((byte)(210)))), ((int)(((byte)(251)))));
            appearance92.ForeColor = System.Drawing.Color.White;
            appearance92.ForeColorDisabled = System.Drawing.Color.White;
            this.tabulador.TabHeaderAreaAppearance = appearance92;
            this.tabulador.TabIndex = 81;
            this.tabulador.TabLayoutStyle = Infragistics.Win.UltraWinTabs.TabLayoutStyle.MultiRowSizeToFit;
            ultraTab21.Key = "paciente";
            ultraTab21.TabPage = this.ultraTabPageControl1;
            ultraTab21.Text = "Estudios";
            ultraTab22.Key = "atencion";
            ultraTab22.TabPage = this.ultraTabPageControl2;
            ultraTab22.Text = "Informe";
            ultraTab23.Key = "gridatenciones";
            ultraTab23.TabPage = this.ultraTabPageControl3;
            ultraTab23.Text = "Ecografia";
            ultraTab24.Key = "certificado";
            ultraTab24.TabPage = this.ultraTabPageControl11;
            ultraTab24.Text = "Diagnosticos y Recomendaciones";
            ultraTab1.TabPage = this.ultraTabPageControl6;
            ultraTab1.Text = "Placas";
            this.tabulador.Tabs.AddRange(new Infragistics.Win.UltraWinTabControl.UltraTab[] {
            ultraTab21,
            ultraTab22,
            ultraTab23,
            ultraTab24,
            ultraTab1});
            this.tabulador.ViewStyle = Infragistics.Win.UltraWinTabControl.ViewStyle.Office2007;
            // 
            // ultraTabSharedControlsPage1
            // 
            this.ultraTabSharedControlsPage1.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabSharedControlsPage1.Name = "ultraTabSharedControlsPage1";
            this.ultraTabSharedControlsPage1.Size = new System.Drawing.Size(784, 468);
            // 
            // grid
            // 
            this.grid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            appearance2.BackColor = System.Drawing.SystemColors.Window;
            appearance2.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grid.DisplayLayout.Appearance = appearance2;
            this.grid.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grid.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance3.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance3.BorderColor = System.Drawing.SystemColors.Window;
            this.grid.DisplayLayout.GroupByBox.Appearance = appearance3;
            appearance4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grid.DisplayLayout.GroupByBox.BandLabelAppearance = appearance4;
            this.grid.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance5.BackColor2 = System.Drawing.SystemColors.Control;
            appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance5.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grid.DisplayLayout.GroupByBox.PromptAppearance = appearance5;
            this.grid.DisplayLayout.MaxColScrollRegions = 1;
            this.grid.DisplayLayout.MaxRowScrollRegions = 1;
            appearance6.BackColor = System.Drawing.SystemColors.Window;
            appearance6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grid.DisplayLayout.Override.ActiveCellAppearance = appearance6;
            appearance7.BackColor = System.Drawing.SystemColors.Highlight;
            appearance7.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grid.DisplayLayout.Override.ActiveRowAppearance = appearance7;
            this.grid.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.grid.DisplayLayout.Override.AllowDelete = Infragistics.Win.DefaultableBoolean.False;
            this.grid.DisplayLayout.Override.AllowUpdate = Infragistics.Win.DefaultableBoolean.False;
            this.grid.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grid.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance8.BackColor = System.Drawing.SystemColors.Window;
            this.grid.DisplayLayout.Override.CardAreaAppearance = appearance8;
            appearance9.BorderColor = System.Drawing.Color.Silver;
            appearance9.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grid.DisplayLayout.Override.CellAppearance = appearance9;
            this.grid.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grid.DisplayLayout.Override.CellPadding = 0;
            appearance10.BackColor = System.Drawing.SystemColors.Control;
            appearance10.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance10.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance10.BorderColor = System.Drawing.SystemColors.Window;
            this.grid.DisplayLayout.Override.GroupByRowAppearance = appearance10;
            appearance11.TextHAlignAsString = "Left";
            this.grid.DisplayLayout.Override.HeaderAppearance = appearance11;
            this.grid.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grid.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance12.BackColor = System.Drawing.SystemColors.Window;
            appearance12.BorderColor = System.Drawing.Color.Silver;
            this.grid.DisplayLayout.Override.RowAppearance = appearance12;
            this.grid.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance13.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grid.DisplayLayout.Override.TemplateAddRowAppearance = appearance13;
            this.grid.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grid.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grid.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grid.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grid.Location = new System.Drawing.Point(1, 48);
            this.grid.Name = "grid";
            this.grid.Size = new System.Drawing.Size(785, 491);
            this.grid.TabIndex = 82;
            // 
            // ImagenInforme
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(786, 536);
            this.Controls.Add(this.tabulador);
            this.Controls.Add(this.tools);
            this.Controls.Add(this.grid);
            this.Name = "ImagenInforme";
            this.Text = "Imagen - Informe";
            this.ultraTabPageControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox11)).EndInit();
            this.ultraGroupBox11.ResumeLayout(false);
            this.ultraGroupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox10)).EndInit();
            this.ultraGroupBox10.ResumeLayout(false);
            this.ultraGroupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtPaciente)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox9)).EndInit();
            this.ultraGroupBox9.ResumeLayout(false);
            this.ultraGroupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox8)).EndInit();
            this.ultraGroupBox8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridEstudios)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupBoxTipoDoc)).EndInit();
            this.groupBoxTipoDoc.ResumeLayout(false);
            this.groupBoxTipoDoc.PerformLayout();
            this.ultraTabPageControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox1)).EndInit();
            this.ultraGroupBox1.ResumeLayout(false);
            this.ultraGroupBox1.PerformLayout();
            this.ultraTabPageControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox3)).EndInit();
            this.ultraGroupBox3.ResumeLayout(false);
            this.ultraGroupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox2)).EndInit();
            this.ultraGroupBox2.ResumeLayout(false);
            this.ultraGroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ultraTabPageControl11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox5)).EndInit();
            this.ultraGroupBox5.ResumeLayout(false);
            this.ultraGroupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox4)).EndInit();
            this.ultraGroupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridDiagnosticos)).EndInit();
            this.ultraTabPageControl6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox7)).EndInit();
            this.ultraGroupBox7.ResumeLayout(false);
            this.ultraGroupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox6)).EndInit();
            this.ultraGroupBox6.ResumeLayout(false);
            this.ultraGroupBox6.PerformLayout();
            this.tools.ResumeLayout(false);
            this.tools.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabulador)).EndInit();
            this.tabulador.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ToolStrip tools;
        private Infragistics.Win.UltraWinTabControl.UltraTabControl tabulador;
        private Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage ultraTabSharedControlsPage1;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl1;
        private Infragistics.Win.Misc.UltraGroupBox groupBoxTipoDoc;
        private System.Windows.Forms.RadioButton rbControl;
        private System.Windows.Forms.RadioButton rbNormal;
        private System.Windows.Forms.RadioButton rdUrgente;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.DateTimePicker dtpInforme;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl2;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl3;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl11;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl6;
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox1;
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox3;
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.CheckBox chkFundica;
        private System.Windows.Forms.TextBox txt_diagnosticoMedico;
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox4;
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox5;
        private System.Windows.Forms.TextBox txtRecomendaciones;
        private System.Windows.Forms.Button btnAddDiagnotico;
        private System.Windows.Forms.DataGridView gridDiagnosticos;
        private System.Windows.Forms.DataGridViewTextBoxColumn CIE10;
        private System.Windows.Forms.DataGridViewTextBoxColumn DIAGNOSTICO;
        private System.Windows.Forms.DataGridViewComboBoxColumn TIPO;
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox6;
        private System.Windows.Forms.TextBox txt14x14;
        private System.Windows.Forms.TextBox txt8x10;
        private System.Windows.Forms.CheckBox chkMedioContraste;
        private System.Windows.Forms.TextBox txt18x24;
        private System.Windows.Forms.TextBox txt14x17;
        private System.Windows.Forms.TextBox txt30x40;
        private System.Windows.Forms.TextBox txtPOdonto;
        private System.Windows.Forms.TextBox txtPDanada;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPEnviadas;
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox7;
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox8;
        private System.Windows.Forms.TextBox txtCODRadiologo;
        private System.Windows.Forms.TextBox txtRadiologo;
        private System.Windows.Forms.TextBox txtCODTecnologo;
        private System.Windows.Forms.Button btnRadiologo;
        private Infragistics.Win.Misc.UltraLabel ultraLabel8;
        private Infragistics.Win.Misc.UltraLabel ultraLabel9;
        private System.Windows.Forms.Button btnTecnologo;
        private System.Windows.Forms.TextBox txtTecnologo;
        private System.Windows.Forms.DataGridView gridEstudios;
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox9;
        private System.Windows.Forms.CheckBox chkOcupada;
        private System.Windows.Forms.CheckBox chkVacia;
        private System.Windows.Forms.CheckBox chkQuiste;
        private System.Windows.Forms.CheckBox chkHidrosalpix;
        private System.Windows.Forms.CheckBox chkAusente;
        private System.Windows.Forms.CheckBox chkMioma;
        private System.Windows.Forms.CheckBox chkFibroma;
        private System.Windows.Forms.CheckBox chkDiu;
        private System.Windows.Forms.CheckBox chkRetroversion;
        private System.Windows.Forms.CheckBox chkAnteversion;
        private System.Windows.Forms.TextBox txt_gradomadurez;
        private System.Windows.Forms.TextBox txt_pap;
        private System.Windows.Forms.TextBox txt_paeg;
        private System.Windows.Forms.TextBox txt_pav;
        private System.Windows.Forms.TextBox txt_lfp;
        private System.Windows.Forms.TextBox txt_lfeg;
        private System.Windows.Forms.TextBox txt_lfv;
        private System.Windows.Forms.TextBox txt_dbp;
        private System.Windows.Forms.TextBox txt_dbeg;
        private System.Windows.Forms.TextBox txt_dbv;
        private System.Windows.Forms.CheckBox chkMultiple;
        private System.Windows.Forms.CheckBox chkFemenino;
        private System.Windows.Forms.CheckBox chkMasculino;
        private System.Windows.Forms.TextBox txt_sacoDouglas;
        private System.Windows.Forms.CheckBox chkPrevia;
        private System.Windows.Forms.CheckBox chkMarginal;
        private Infragistics.Win.UltraWinGrid.UltraGrid grid;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ESTUDIO;
        private System.Windows.Forms.DataGridViewTextBoxColumn CODSUB;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtPaciente;
        private System.Windows.Forms.DateTimePicker dtpEntrega;
        private System.Windows.Forms.Label label10;
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox11;
        private Infragistics.Win.Misc.UltraLabel ultraLabel5;
        private System.Windows.Forms.TextBox txtMedicoCOD;
        private System.Windows.Forms.TextBox txtMedico;
        private System.Windows.Forms.Button btnAddMedico;
    }
}