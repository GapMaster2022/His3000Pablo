﻿namespace His.Dietetica
{
    partial class frmQuirofanoRegistro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmQuirofanoRegistro));
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance50 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            this.tools = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonGuardar = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonEditar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonSalir = new System.Windows.Forms.ToolStripButton();
            this.groupgenerales = new System.Windows.Forms.GroupBox();
            this.HoraFin = new System.Windows.Forms.DateTimePicker();
            this.lblatencion = new System.Windows.Forms.Label();
            this.txtpatologia = new System.Windows.Forms.TextBox();
            this.btnpatologia = new Infragistics.Win.Misc.UltraButton();
            this.txtinstrumentista = new System.Windows.Forms.TextBox();
            this.btninstrumentista = new Infragistics.Win.Misc.UltraButton();
            this.txtcirculante = new System.Windows.Forms.TextBox();
            this.btncirculante = new Infragistics.Win.Misc.UltraButton();
            this.txtduracion = new System.Windows.Forms.TextBox();
            this.cbanestesia = new System.Windows.Forms.ComboBox();
            this.ckbno = new System.Windows.Forms.CheckBox();
            this.ckbsi = new System.Windows.Forms.CheckBox();
            this.txtanestesiologo = new System.Windows.Forms.TextBox();
            this.btnanestesiologo = new Infragistics.Win.Misc.UltraButton();
            this.txtayudantia = new System.Windows.Forms.TextBox();
            this.btnayudantia = new Infragistics.Win.Misc.UltraButton();
            this.txtayudante = new System.Windows.Forms.TextBox();
            this.btnayudante = new Infragistics.Win.Misc.UltraButton();
            this.txtcirujano = new System.Windows.Forms.TextBox();
            this.lblprocedimiento = new System.Windows.Forms.Label();
            this.lbledad = new System.Windows.Forms.Label();
            this.lblhabitacion = new System.Windows.Forms.Label();
            this.lblpaciente = new System.Windows.Forms.Label();
            this.lblfecha = new System.Windows.Forms.Label();
            this.cbHabQuirofano = new System.Windows.Forms.ComboBox();
            this.ckbEmergencia = new System.Windows.Forms.CheckBox();
            this.ckbProgramada = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblrecuperacion = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btncirujano = new Infragistics.Win.Misc.UltraButton();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.txthorainicio = new System.Windows.Forms.DateTimePicker();
            this.tools.SuspendLayout();
            this.groupgenerales.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // tools
            // 
            this.tools.AutoSize = false;
            this.tools.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonGuardar,
            this.toolStripButtonEditar,
            this.toolStripSeparator1,
            this.toolStripButtonSalir});
            this.tools.Location = new System.Drawing.Point(0, 0);
            this.tools.Name = "tools";
            this.tools.Size = new System.Drawing.Size(1213, 45);
            this.tools.TabIndex = 79;
            this.tools.Text = "toolStrip1";
            // 
            // toolStripButtonGuardar
            // 
            this.toolStripButtonGuardar.AutoSize = false;
            this.toolStripButtonGuardar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonGuardar.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonGuardar.Image")));
            this.toolStripButtonGuardar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonGuardar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonGuardar.Name = "toolStripButtonGuardar";
            this.toolStripButtonGuardar.Size = new System.Drawing.Size(42, 42);
            this.toolStripButtonGuardar.Text = "Guardar";
            this.toolStripButtonGuardar.ToolTipText = "Guardar";
            this.toolStripButtonGuardar.Click += new System.EventHandler(this.toolStripButtonGuardar_Click);
            // 
            // toolStripButtonEditar
            // 
            this.toolStripButtonEditar.AutoSize = false;
            this.toolStripButtonEditar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonEditar.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonEditar.Image")));
            this.toolStripButtonEditar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonEditar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonEditar.Name = "toolStripButtonEditar";
            this.toolStripButtonEditar.Size = new System.Drawing.Size(42, 42);
            this.toolStripButtonEditar.Text = "Modificar";
            this.toolStripButtonEditar.ToolTipText = "Modificar";
            this.toolStripButtonEditar.Click += new System.EventHandler(this.toolStripButtonEditar_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 45);
            // 
            // toolStripButtonSalir
            // 
            this.toolStripButtonSalir.AutoSize = false;
            this.toolStripButtonSalir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonSalir.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSalir.Image")));
            this.toolStripButtonSalir.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonSalir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSalir.Name = "toolStripButtonSalir";
            this.toolStripButtonSalir.Size = new System.Drawing.Size(42, 42);
            this.toolStripButtonSalir.Text = "toolStripButton1";
            this.toolStripButtonSalir.ToolTipText = "Salir";
            this.toolStripButtonSalir.Click += new System.EventHandler(this.toolStripButtonSalir_Click);
            // 
            // groupgenerales
            // 
            this.groupgenerales.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupgenerales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(227)))), ((int)(((byte)(243)))));
            this.groupgenerales.Controls.Add(this.txthorainicio);
            this.groupgenerales.Controls.Add(this.HoraFin);
            this.groupgenerales.Controls.Add(this.lblatencion);
            this.groupgenerales.Controls.Add(this.txtpatologia);
            this.groupgenerales.Controls.Add(this.btnpatologia);
            this.groupgenerales.Controls.Add(this.txtinstrumentista);
            this.groupgenerales.Controls.Add(this.btninstrumentista);
            this.groupgenerales.Controls.Add(this.txtcirculante);
            this.groupgenerales.Controls.Add(this.btncirculante);
            this.groupgenerales.Controls.Add(this.txtduracion);
            this.groupgenerales.Controls.Add(this.cbanestesia);
            this.groupgenerales.Controls.Add(this.ckbno);
            this.groupgenerales.Controls.Add(this.ckbsi);
            this.groupgenerales.Controls.Add(this.txtanestesiologo);
            this.groupgenerales.Controls.Add(this.btnanestesiologo);
            this.groupgenerales.Controls.Add(this.txtayudantia);
            this.groupgenerales.Controls.Add(this.btnayudantia);
            this.groupgenerales.Controls.Add(this.txtayudante);
            this.groupgenerales.Controls.Add(this.btnayudante);
            this.groupgenerales.Controls.Add(this.txtcirujano);
            this.groupgenerales.Controls.Add(this.lblprocedimiento);
            this.groupgenerales.Controls.Add(this.lbledad);
            this.groupgenerales.Controls.Add(this.lblhabitacion);
            this.groupgenerales.Controls.Add(this.lblpaciente);
            this.groupgenerales.Controls.Add(this.lblfecha);
            this.groupgenerales.Controls.Add(this.cbHabQuirofano);
            this.groupgenerales.Controls.Add(this.ckbEmergencia);
            this.groupgenerales.Controls.Add(this.ckbProgramada);
            this.groupgenerales.Controls.Add(this.label15);
            this.groupgenerales.Controls.Add(this.label14);
            this.groupgenerales.Controls.Add(this.label13);
            this.groupgenerales.Controls.Add(this.label12);
            this.groupgenerales.Controls.Add(this.label11);
            this.groupgenerales.Controls.Add(this.label10);
            this.groupgenerales.Controls.Add(this.label9);
            this.groupgenerales.Controls.Add(this.label8);
            this.groupgenerales.Controls.Add(this.lblrecuperacion);
            this.groupgenerales.Controls.Add(this.label6);
            this.groupgenerales.Controls.Add(this.btncirujano);
            this.groupgenerales.Controls.Add(this.label5);
            this.groupgenerales.Controls.Add(this.label4);
            this.groupgenerales.Controls.Add(this.label3);
            this.groupgenerales.Controls.Add(this.label2);
            this.groupgenerales.Controls.Add(this.label1);
            this.groupgenerales.Controls.Add(this.label24);
            this.groupgenerales.Controls.Add(this.label);
            this.groupgenerales.Controls.Add(this.label23);
            this.groupgenerales.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupgenerales.Location = new System.Drawing.Point(0, 48);
            this.groupgenerales.Name = "groupgenerales";
            this.groupgenerales.Size = new System.Drawing.Size(1213, 211);
            this.groupgenerales.TabIndex = 80;
            this.groupgenerales.TabStop = false;
            // 
            // HoraFin
            // 
            this.HoraFin.CustomFormat = "HH:mm:ss";
            this.HoraFin.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.HoraFin.Location = new System.Drawing.Point(161, 132);
            this.HoraFin.Name = "HoraFin";
            this.HoraFin.ShowUpDown = true;
            this.HoraFin.Size = new System.Drawing.Size(70, 20);
            this.HoraFin.TabIndex = 318;
            this.HoraFin.KeyDown += new System.Windows.Forms.KeyEventHandler(this.HoraFin_KeyDown);
            this.HoraFin.Leave += new System.EventHandler(this.HoraFin_Leave);
            // 
            // lblatencion
            // 
            this.lblatencion.AutoSize = true;
            this.lblatencion.BackColor = System.Drawing.Color.Transparent;
            this.lblatencion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblatencion.Location = new System.Drawing.Point(788, 183);
            this.lblatencion.Name = "lblatencion";
            this.lblatencion.Size = new System.Drawing.Size(118, 15);
            this.lblatencion.TabIndex = 317;
            this.lblatencion.Text = "Tipo de Atención:";
            // 
            // txtpatologia
            // 
            this.txtpatologia.Location = new System.Drawing.Point(463, 179);
            this.txtpatologia.Name = "txtpatologia";
            this.txtpatologia.ReadOnly = true;
            this.txtpatologia.Size = new System.Drawing.Size(237, 20);
            this.txtpatologia.TabIndex = 316;
            // 
            // btnpatologia
            // 
            appearance3.ForeColor = System.Drawing.Color.Navy;
            appearance3.TextHAlignAsString = "Center";
            appearance3.TextVAlignAsString = "Middle";
            this.btnpatologia.Appearance = appearance3;
            this.btnpatologia.ButtonStyle = Infragistics.Win.UIElementButtonStyle.WindowsXPCommandButton;
            this.btnpatologia.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpatologia.Location = new System.Drawing.Point(715, 179);
            this.btnpatologia.Name = "btnpatologia";
            this.btnpatologia.Size = new System.Drawing.Size(30, 21);
            this.btnpatologia.TabIndex = 315;
            this.btnpatologia.TabStop = false;
            this.btnpatologia.Text = "F1";
            this.btnpatologia.Click += new System.EventHandler(this.btnpatologia_Click);
            // 
            // txtinstrumentista
            // 
            this.txtinstrumentista.Location = new System.Drawing.Point(120, 179);
            this.txtinstrumentista.Name = "txtinstrumentista";
            this.txtinstrumentista.ReadOnly = true;
            this.txtinstrumentista.Size = new System.Drawing.Size(186, 20);
            this.txtinstrumentista.TabIndex = 314;
            // 
            // btninstrumentista
            // 
            appearance2.ForeColor = System.Drawing.Color.Navy;
            appearance2.TextHAlignAsString = "Center";
            appearance2.TextVAlignAsString = "Middle";
            this.btninstrumentista.Appearance = appearance2;
            this.btninstrumentista.ButtonStyle = Infragistics.Win.UIElementButtonStyle.WindowsXPCommandButton;
            this.btninstrumentista.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninstrumentista.Location = new System.Drawing.Point(318, 179);
            this.btninstrumentista.Name = "btninstrumentista";
            this.btninstrumentista.Size = new System.Drawing.Size(30, 21);
            this.btninstrumentista.TabIndex = 313;
            this.btninstrumentista.TabStop = false;
            this.btninstrumentista.Text = "F1";
            this.btninstrumentista.Click += new System.EventHandler(this.btninstrumentista_Click);
            // 
            // txtcirculante
            // 
            this.txtcirculante.Location = new System.Drawing.Point(467, 132);
            this.txtcirculante.Name = "txtcirculante";
            this.txtcirculante.ReadOnly = true;
            this.txtcirculante.Size = new System.Drawing.Size(233, 20);
            this.txtcirculante.TabIndex = 312;
            // 
            // btncirculante
            // 
            appearance4.ForeColor = System.Drawing.Color.Navy;
            appearance4.TextHAlignAsString = "Center";
            appearance4.TextVAlignAsString = "Middle";
            this.btncirculante.Appearance = appearance4;
            this.btncirculante.ButtonStyle = Infragistics.Win.UIElementButtonStyle.WindowsXPCommandButton;
            this.btncirculante.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncirculante.Location = new System.Drawing.Point(715, 133);
            this.btncirculante.Name = "btncirculante";
            this.btncirculante.Size = new System.Drawing.Size(30, 21);
            this.btncirculante.TabIndex = 311;
            this.btncirculante.TabStop = false;
            this.btncirculante.Text = "F1";
            this.btncirculante.Click += new System.EventHandler(this.btncirculante_Click);
            // 
            // txtduracion
            // 
            this.txtduracion.Location = new System.Drawing.Point(304, 132);
            this.txtduracion.Name = "txtduracion";
            this.txtduracion.ReadOnly = true;
            this.txtduracion.Size = new System.Drawing.Size(50, 20);
            this.txtduracion.TabIndex = 309;
            // 
            // cbanestesia
            // 
            this.cbanestesia.FormattingEnabled = true;
            this.cbanestesia.Location = new System.Drawing.Point(91, 92);
            this.cbanestesia.Name = "cbanestesia";
            this.cbanestesia.Size = new System.Drawing.Size(249, 21);
            this.cbanestesia.TabIndex = 304;
            // 
            // ckbno
            // 
            this.ckbno.AutoSize = true;
            this.ckbno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckbno.Location = new System.Drawing.Point(606, 92);
            this.ckbno.Name = "ckbno";
            this.ckbno.Size = new System.Drawing.Size(42, 19);
            this.ckbno.TabIndex = 303;
            this.ckbno.Text = "No";
            this.ckbno.UseVisualStyleBackColor = true;
            this.ckbno.CheckedChanged += new System.EventHandler(this.ckbno_CheckedChanged);
            // 
            // ckbsi
            // 
            this.ckbsi.AutoSize = true;
            this.ckbsi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckbsi.Location = new System.Drawing.Point(529, 92);
            this.ckbsi.Name = "ckbsi";
            this.ckbsi.Size = new System.Drawing.Size(37, 19);
            this.ckbsi.TabIndex = 302;
            this.ckbsi.Text = "Sí";
            this.ckbsi.UseVisualStyleBackColor = true;
            this.ckbsi.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // txtanestesiologo
            // 
            this.txtanestesiologo.Location = new System.Drawing.Point(895, 92);
            this.txtanestesiologo.Name = "txtanestesiologo";
            this.txtanestesiologo.ReadOnly = true;
            this.txtanestesiologo.Size = new System.Drawing.Size(210, 20);
            this.txtanestesiologo.TabIndex = 301;
            // 
            // btnanestesiologo
            // 
            appearance1.ForeColor = System.Drawing.Color.Navy;
            appearance1.TextHAlignAsString = "Center";
            appearance1.TextVAlignAsString = "Middle";
            this.btnanestesiologo.Appearance = appearance1;
            this.btnanestesiologo.ButtonStyle = Infragistics.Win.UIElementButtonStyle.WindowsXPCommandButton;
            this.btnanestesiologo.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnanestesiologo.Location = new System.Drawing.Point(1122, 93);
            this.btnanestesiologo.Name = "btnanestesiologo";
            this.btnanestesiologo.Size = new System.Drawing.Size(30, 21);
            this.btnanestesiologo.TabIndex = 300;
            this.btnanestesiologo.TabStop = false;
            this.btnanestesiologo.Text = "F1";
            this.btnanestesiologo.Click += new System.EventHandler(this.btnanestesiologo_Click);
            // 
            // txtayudantia
            // 
            this.txtayudantia.Location = new System.Drawing.Point(884, 52);
            this.txtayudantia.Name = "txtayudantia";
            this.txtayudantia.ReadOnly = true;
            this.txtayudantia.Size = new System.Drawing.Size(221, 20);
            this.txtayudantia.TabIndex = 299;
            // 
            // btnayudantia
            // 
            appearance50.ForeColor = System.Drawing.Color.Navy;
            appearance50.TextHAlignAsString = "Center";
            appearance50.TextVAlignAsString = "Middle";
            this.btnayudantia.Appearance = appearance50;
            this.btnayudantia.ButtonStyle = Infragistics.Win.UIElementButtonStyle.WindowsXPCommandButton;
            this.btnayudantia.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnayudantia.Location = new System.Drawing.Point(1122, 52);
            this.btnayudantia.Name = "btnayudantia";
            this.btnayudantia.Size = new System.Drawing.Size(30, 21);
            this.btnayudantia.TabIndex = 298;
            this.btnayudantia.TabStop = false;
            this.btnayudantia.Text = "F1";
            this.btnayudantia.Click += new System.EventHandler(this.btnayudantia_Click);
            // 
            // txtayudante
            // 
            this.txtayudante.Location = new System.Drawing.Point(479, 52);
            this.txtayudante.Name = "txtayudante";
            this.txtayudante.ReadOnly = true;
            this.txtayudante.Size = new System.Drawing.Size(221, 20);
            this.txtayudante.TabIndex = 297;
            // 
            // btnayudante
            // 
            appearance5.ForeColor = System.Drawing.Color.Navy;
            appearance5.TextHAlignAsString = "Center";
            appearance5.TextVAlignAsString = "Middle";
            this.btnayudante.Appearance = appearance5;
            this.btnayudante.ButtonStyle = Infragistics.Win.UIElementButtonStyle.WindowsXPCommandButton;
            this.btnayudante.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnayudante.Location = new System.Drawing.Point(715, 52);
            this.btnayudante.Name = "btnayudante";
            this.btnayudante.Size = new System.Drawing.Size(30, 21);
            this.btnayudante.TabIndex = 296;
            this.btnayudante.TabStop = false;
            this.btnayudante.Text = "F1";
            this.btnayudante.Click += new System.EventHandler(this.btnayudante_Click);
            // 
            // txtcirujano
            // 
            this.txtcirujano.Location = new System.Drawing.Point(83, 52);
            this.txtcirujano.Name = "txtcirujano";
            this.txtcirujano.ReadOnly = true;
            this.txtcirujano.Size = new System.Drawing.Size(221, 20);
            this.txtcirujano.TabIndex = 295;
            // 
            // lblprocedimiento
            // 
            this.lblprocedimiento.AutoSize = true;
            this.lblprocedimiento.Location = new System.Drawing.Point(883, 135);
            this.lblprocedimiento.Name = "lblprocedimiento";
            this.lblprocedimiento.Size = new System.Drawing.Size(41, 13);
            this.lblprocedimiento.TabIndex = 294;
            this.lblprocedimiento.Text = "label16";
            // 
            // lbledad
            // 
            this.lbledad.AutoSize = true;
            this.lbledad.Location = new System.Drawing.Point(1158, 18);
            this.lbledad.Name = "lbledad";
            this.lbledad.Size = new System.Drawing.Size(41, 13);
            this.lbledad.TabIndex = 293;
            this.lbledad.Text = "label16";
            // 
            // lblhabitacion
            // 
            this.lblhabitacion.AutoSize = true;
            this.lblhabitacion.Location = new System.Drawing.Point(1042, 18);
            this.lblhabitacion.Name = "lblhabitacion";
            this.lblhabitacion.Size = new System.Drawing.Size(41, 13);
            this.lblhabitacion.TabIndex = 292;
            this.lblhabitacion.Text = "label16";
            // 
            // lblpaciente
            // 
            this.lblpaciente.AutoSize = true;
            this.lblpaciente.Location = new System.Drawing.Point(458, 18);
            this.lblpaciente.Name = "lblpaciente";
            this.lblpaciente.Size = new System.Drawing.Size(41, 13);
            this.lblpaciente.TabIndex = 291;
            this.lblpaciente.Text = "label16";
            // 
            // lblfecha
            // 
            this.lblfecha.AutoSize = true;
            this.lblfecha.Location = new System.Drawing.Point(68, 18);
            this.lblfecha.Name = "lblfecha";
            this.lblfecha.Size = new System.Drawing.Size(41, 13);
            this.lblfecha.TabIndex = 81;
            this.lblfecha.Text = "label16";
            // 
            // cbHabQuirofano
            // 
            this.cbHabQuirofano.FormattingEnabled = true;
            this.cbHabQuirofano.Location = new System.Drawing.Point(868, 15);
            this.cbHabQuirofano.Name = "cbHabQuirofano";
            this.cbHabQuirofano.Size = new System.Drawing.Size(97, 21);
            this.cbHabQuirofano.TabIndex = 288;
            // 
            // ckbEmergencia
            // 
            this.ckbEmergencia.AutoSize = true;
            this.ckbEmergencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckbEmergencia.Location = new System.Drawing.Point(1049, 182);
            this.ckbEmergencia.Name = "ckbEmergencia";
            this.ckbEmergencia.Size = new System.Drawing.Size(106, 19);
            this.ckbEmergencia.TabIndex = 285;
            this.ckbEmergencia.Text = "EMERGENCIA";
            this.ckbEmergencia.UseVisualStyleBackColor = true;
            this.ckbEmergencia.CheckedChanged += new System.EventHandler(this.ckbEmergencia_CheckedChanged);
            // 
            // ckbProgramada
            // 
            this.ckbProgramada.AutoSize = true;
            this.ckbProgramada.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckbProgramada.Location = new System.Drawing.Point(925, 182);
            this.ckbProgramada.Name = "ckbProgramada";
            this.ckbProgramada.Size = new System.Drawing.Size(111, 19);
            this.ckbProgramada.TabIndex = 284;
            this.ckbProgramada.Text = "PROGRAMADA";
            this.ckbProgramada.UseVisualStyleBackColor = true;
            this.ckbProgramada.CheckedChanged += new System.EventHandler(this.ckbProgramada_CheckedChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(385, 180);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 15);
            this.label15.TabIndex = 283;
            this.label15.Text = "Patología:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(12, 180);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(102, 15);
            this.label14.TabIndex = 282;
            this.label14.Text = "Instrumentista:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(385, 133);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 15);
            this.label13.TabIndex = 281;
            this.label13.Text = "Circulante:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(237, 133);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 15);
            this.label12.TabIndex = 280;
            this.label12.Text = "Duración:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(126, 133);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 15);
            this.label11.TabIndex = 279;
            this.label11.Text = "H.T:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(12, 133);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 15);
            this.label10.TabIndex = 278;
            this.label10.Text = "H.I:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(788, 133);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 30);
            this.label9.TabIndex = 277;
            this.label9.Text = "Intervención:\r\n(Procedimiento)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(788, 93);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 15);
            this.label8.TabIndex = 276;
            this.label8.Text = "Anestesiólogo:";
            // 
            // lblrecuperacion
            // 
            this.lblrecuperacion.AutoSize = true;
            this.lblrecuperacion.BackColor = System.Drawing.Color.Transparent;
            this.lblrecuperacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrecuperacion.Location = new System.Drawing.Point(385, 93);
            this.lblrecuperacion.Name = "lblrecuperacion";
            this.lblrecuperacion.Size = new System.Drawing.Size(100, 15);
            this.lblrecuperacion.TabIndex = 275;
            this.lblrecuperacion.Text = "Recuperación:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 93);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 15);
            this.label6.TabIndex = 274;
            this.label6.Text = "Anestesia:";
            // 
            // btncirujano
            // 
            appearance6.ForeColor = System.Drawing.Color.Navy;
            appearance6.TextHAlignAsString = "Center";
            appearance6.TextVAlignAsString = "Middle";
            this.btncirujano.Appearance = appearance6;
            this.btncirujano.ButtonStyle = Infragistics.Win.UIElementButtonStyle.WindowsXPCommandButton;
            this.btncirujano.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncirujano.Location = new System.Drawing.Point(318, 52);
            this.btncirujano.Name = "btncirujano";
            this.btncirujano.Size = new System.Drawing.Size(30, 21);
            this.btncirujano.TabIndex = 273;
            this.btncirujano.TabStop = false;
            this.btncirujano.Text = "F1";
            this.btncirujano.Click += new System.EventHandler(this.btncirujano_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(999, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 15);
            this.label5.TabIndex = 95;
            this.label5.Text = "Hab:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(788, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 15);
            this.label4.TabIndex = 93;
            this.label4.Text = "Quirófano:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 15);
            this.label3.TabIndex = 91;
            this.label3.Text = "Cirujano:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1108, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 15);
            this.label2.TabIndex = 89;
            this.label2.Text = "Edad:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(385, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 87;
            this.label1.Text = "Paciente:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(385, 53);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(88, 15);
            this.label24.TabIndex = 83;
            this.label24.Text = "Ayudante(P):";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.BackColor = System.Drawing.Color.Transparent;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(788, 53);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(92, 15);
            this.label.TabIndex = 84;
            this.label.Text = "Ayudantía(C):";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(12, 16);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(50, 15);
            this.label23.TabIndex = 79;
            this.label23.Text = "Fecha:";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // txthorainicio
            // 
            this.txthorainicio.CustomFormat = "HH:mm:ss";
            this.txthorainicio.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.txthorainicio.Location = new System.Drawing.Point(47, 132);
            this.txthorainicio.Name = "txthorainicio";
            this.txthorainicio.ShowUpDown = true;
            this.txthorainicio.Size = new System.Drawing.Size(70, 20);
            this.txthorainicio.TabIndex = 319;
            // 
            // frmQuirofanoRegistro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1213, 263);
            this.Controls.Add(this.groupgenerales);
            this.Controls.Add(this.tools);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmQuirofanoRegistro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registro de Suministro";
            this.Load += new System.EventHandler(this.frmQuirofanoRegistro_Load);
            this.tools.ResumeLayout(false);
            this.tools.PerformLayout();
            this.groupgenerales.ResumeLayout(false);
            this.groupgenerales.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStrip tools;
        private System.Windows.Forms.ToolStripButton toolStripButtonGuardar;
        private System.Windows.Forms.ToolStripButton toolStripButtonEditar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButtonSalir;
        private System.Windows.Forms.GroupBox groupgenerales;
        private Infragistics.Win.Misc.UltraButton btncirujano;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.CheckBox ckbEmergencia;
        private System.Windows.Forms.CheckBox ckbProgramada;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblrecuperacion;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbHabQuirofano;
        private System.Windows.Forms.Label lblfecha;
        private System.Windows.Forms.Label lblpaciente;
        private System.Windows.Forms.Label lbledad;
        private System.Windows.Forms.Label lblhabitacion;
        private System.Windows.Forms.Label lblprocedimiento;
        private System.Windows.Forms.TextBox txtcirujano;
        private System.Windows.Forms.Label lblatencion;
        private System.Windows.Forms.TextBox txtpatologia;
        private Infragistics.Win.Misc.UltraButton btnpatologia;
        private System.Windows.Forms.TextBox txtinstrumentista;
        private Infragistics.Win.Misc.UltraButton btninstrumentista;
        private System.Windows.Forms.TextBox txtcirculante;
        private Infragistics.Win.Misc.UltraButton btncirculante;
        private System.Windows.Forms.TextBox txtduracion;
        private System.Windows.Forms.ComboBox cbanestesia;
        private System.Windows.Forms.CheckBox ckbno;
        private System.Windows.Forms.CheckBox ckbsi;
        private System.Windows.Forms.TextBox txtanestesiologo;
        private Infragistics.Win.Misc.UltraButton btnanestesiologo;
        private System.Windows.Forms.TextBox txtayudantia;
        private Infragistics.Win.Misc.UltraButton btnayudantia;
        private System.Windows.Forms.TextBox txtayudante;
        private Infragistics.Win.Misc.UltraButton btnayudante;
        private System.Windows.Forms.DateTimePicker HoraFin;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.DateTimePicker txthorainicio;
    }
}