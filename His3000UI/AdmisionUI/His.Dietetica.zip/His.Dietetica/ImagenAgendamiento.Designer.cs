﻿namespace His.Dietetica
{
    partial class ImagenAgendamiento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ImagenAgendamiento));
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            this.ultraTabSharedControlsPage3 = new Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage();
            this.cachedGarantias1 = new His.Admision.CachedGarantias();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.pnl2 = new System.Windows.Forms.Panel();
            this.lblAlertaImagen = new System.Windows.Forms.Label();
            this.grpATE = new Infragistics.Win.Misc.UltraGroupBox();
            this.ultraLabel5 = new Infragistics.Win.Misc.UltraLabel();
            this.txtHC = new System.Windows.Forms.TextBox();
            this.btnAgregaEstudio = new System.Windows.Forms.Button();
            this.txtIdAgendamiento = new System.Windows.Forms.TextBox();
            this.gridEstudios = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ESTUDIO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CODSUB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtTecnologo = new System.Windows.Forms.TextBox();
            this.txtCODRadiologo = new System.Windows.Forms.TextBox();
            this.txtRadiologo = new System.Windows.Forms.TextBox();
            this.txtCODTecnologo = new System.Windows.Forms.TextBox();
            this.txtPaciente = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.btnRadiologo = new System.Windows.Forms.Button();
            this.ultraLabel4 = new Infragistics.Win.Misc.UltraLabel();
            this.txtObservaciones = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.btnPaciente = new System.Windows.Forms.Button();
            this.ultraLabel8 = new Infragistics.Win.Misc.UltraLabel();
            this.dtpFechaNota = new System.Windows.Forms.DateTimePicker();
            this.ultraLabel9 = new Infragistics.Win.Misc.UltraLabel();
            this.ultraLabel3 = new Infragistics.Win.Misc.UltraLabel();
            this.btnTecnologo = new System.Windows.Forms.Button();
            this.ultraLabel2 = new Infragistics.Win.Misc.UltraLabel();
            this.ultraLabel1 = new Infragistics.Win.Misc.UltraLabel();
            this.pnl1 = new System.Windows.Forms.Panel();
            this.grid = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.groupBox5 = new Infragistics.Win.Misc.UltraGroupBox();
            this.dtpHasta = new System.Windows.Forms.DateTimePicker();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.dtpDesde = new System.Windows.Forms.DateTimePicker();
            this.label63 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.tools = new System.Windows.Forms.ToolStrip();
            this.btnNuevo = new System.Windows.Forms.ToolStripButton();
            this.btnModificar = new System.Windows.Forms.ToolStripButton();
            this.btnDelete = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonActualizar = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonBuscar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonSalir = new System.Windows.Forms.ToolStripButton();
            this.ultraGridExcelExporter1 = new Infragistics.Win.UltraWinGrid.ExcelExport.UltraGridExcelExporter(this.components);
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnl3 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txtMotivoCancelacion = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblDelete = new System.Windows.Forms.Label();
            this.toolStrip1.SuspendLayout();
            this.pnl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grpATE)).BeginInit();
            this.grpATE.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridEstudios)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPaciente)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtObservaciones)).BeginInit();
            this.pnl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupBox5)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.tools.SuspendLayout();
            this.pnl3.SuspendLayout();
            this.SuspendLayout();
            // 
            // ultraTabSharedControlsPage3
            // 
            this.ultraTabSharedControlsPage3.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabSharedControlsPage3.Name = "ultraTabSharedControlsPage3";
            this.ultraTabSharedControlsPage3.Size = new System.Drawing.Size(834, 79);
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripSeparator4,
            this.toolStripButton7});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(643, 45);
            this.toolStrip1.TabIndex = 79;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.AutoSize = false;
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(42, 42);
            this.toolStripButton3.Text = "toolStripButton1";
            this.toolStripButton3.ToolTipText = "Guardar";
            this.toolStripButton3.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.AutoSize = false;
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(42, 42);
            this.toolStripButton4.Text = "toolStripButton1";
            this.toolStripButton4.ToolTipText = "Cancelar";
            this.toolStripButton4.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 45);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.AutoSize = false;
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(42, 42);
            this.toolStripButton7.Text = "toolStripButton1";
            this.toolStripButton7.ToolTipText = "Salir";
            this.toolStripButton7.Click += new System.EventHandler(this.toolStripButtonSalir_Click);
            // 
            // pnl2
            // 
            this.pnl2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnl2.Controls.Add(this.lblAlertaImagen);
            this.pnl2.Controls.Add(this.grpATE);
            this.pnl2.Controls.Add(this.btnAgregaEstudio);
            this.pnl2.Controls.Add(this.txtIdAgendamiento);
            this.pnl2.Controls.Add(this.gridEstudios);
            this.pnl2.Controls.Add(this.txtTecnologo);
            this.pnl2.Controls.Add(this.txtCODRadiologo);
            this.pnl2.Controls.Add(this.txtRadiologo);
            this.pnl2.Controls.Add(this.txtCODTecnologo);
            this.pnl2.Controls.Add(this.txtPaciente);
            this.pnl2.Controls.Add(this.btnRadiologo);
            this.pnl2.Controls.Add(this.ultraLabel4);
            this.pnl2.Controls.Add(this.txtObservaciones);
            this.pnl2.Controls.Add(this.btnPaciente);
            this.pnl2.Controls.Add(this.ultraLabel8);
            this.pnl2.Controls.Add(this.dtpFechaNota);
            this.pnl2.Controls.Add(this.ultraLabel9);
            this.pnl2.Controls.Add(this.ultraLabel3);
            this.pnl2.Controls.Add(this.btnTecnologo);
            this.pnl2.Controls.Add(this.ultraLabel2);
            this.pnl2.Controls.Add(this.ultraLabel1);
            this.pnl2.Controls.Add(this.toolStrip1);
            this.pnl2.Location = new System.Drawing.Point(2, 1);
            this.pnl2.Name = "pnl2";
            this.pnl2.Size = new System.Drawing.Size(643, 393);
            this.pnl2.TabIndex = 82;
            this.pnl2.Visible = false;
            this.pnl2.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl2_Paint);
            // 
            // lblAlertaImagen
            // 
            this.lblAlertaImagen.AutoSize = true;
            this.lblAlertaImagen.ForeColor = System.Drawing.Color.Red;
            this.lblAlertaImagen.Location = new System.Drawing.Point(461, 78);
            this.lblAlertaImagen.Name = "lblAlertaImagen";
            this.lblAlertaImagen.Size = new System.Drawing.Size(125, 13);
            this.lblAlertaImagen.TabIndex = 102;
            this.lblAlertaImagen.Text = "No tiene item de Imagen.";
            this.lblAlertaImagen.Visible = false;
            // 
            // grpATE
            // 
            this.grpATE.Controls.Add(this.ultraLabel5);
            this.grpATE.Controls.Add(this.txtHC);
            this.grpATE.ForeColor = System.Drawing.Color.Black;
            appearance1.FontData.BoldAsString = "True";
            appearance1.ForeColor = System.Drawing.Color.DimGray;
            appearance1.TextHAlignAsString = "Right";
            this.grpATE.HeaderAppearance = appearance1;
            this.grpATE.HeaderPosition = Infragistics.Win.Misc.GroupBoxHeaderPosition.TopOnBorder;
            this.grpATE.Location = new System.Drawing.Point(265, 42);
            this.grpATE.Name = "grpATE";
            this.grpATE.Size = new System.Drawing.Size(190, 26);
            this.grpATE.TabIndex = 101;
            // 
            // ultraLabel5
            // 
            this.ultraLabel5.AutoSize = true;
            this.ultraLabel5.Location = new System.Drawing.Point(24, 6);
            this.ultraLabel5.Name = "ultraLabel5";
            this.ultraLabel5.Size = new System.Drawing.Size(102, 14);
            this.ultraLabel5.TabIndex = 100;
            this.ultraLabel5.Text = "Codigo de atencion ";
            this.ultraLabel5.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtHC
            // 
            this.txtHC.BackColor = System.Drawing.SystemColors.Control;
            this.txtHC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtHC.Location = new System.Drawing.Point(132, 6);
            this.txtHC.Name = "txtHC";
            this.txtHC.Size = new System.Drawing.Size(47, 13);
            this.txtHC.TabIndex = 95;
            this.txtHC.Text = "0";
            // 
            // btnAgregaEstudio
            // 
            this.btnAgregaEstudio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregaEstudio.Image = ((System.Drawing.Image)(resources.GetObject("btnAgregaEstudio.Image")));
            this.btnAgregaEstudio.Location = new System.Drawing.Point(69, 214);
            this.btnAgregaEstudio.Name = "btnAgregaEstudio";
            this.btnAgregaEstudio.Size = new System.Drawing.Size(25, 26);
            this.btnAgregaEstudio.TabIndex = 99;
            this.btnAgregaEstudio.UseVisualStyleBackColor = true;
            this.btnAgregaEstudio.Click += new System.EventHandler(this.btnAgregaEstudio_Click_1);
            // 
            // txtIdAgendamiento
            // 
            this.txtIdAgendamiento.Location = new System.Drawing.Point(38, 262);
            this.txtIdAgendamiento.Name = "txtIdAgendamiento";
            this.txtIdAgendamiento.Size = new System.Drawing.Size(38, 20);
            this.txtIdAgendamiento.TabIndex = 98;
            this.txtIdAgendamiento.Text = "0";
            this.txtIdAgendamiento.Visible = false;
            // 
            // gridEstudios
            // 
            this.gridEstudios.AllowUserToAddRows = false;
            this.gridEstudios.AllowUserToOrderColumns = true;
            this.gridEstudios.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridEstudios.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gridEstudios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridEstudios.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.ESTUDIO,
            this.CODSUB});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridEstudios.DefaultCellStyle = dataGridViewCellStyle2;
            this.gridEstudios.Location = new System.Drawing.Point(100, 214);
            this.gridEstudios.Name = "gridEstudios";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridEstudios.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.gridEstudios.RowHeadersWidth = 13;
            this.gridEstudios.Size = new System.Drawing.Size(466, 124);
            this.gridEstudios.TabIndex = 92;
            // 
            // ID
            // 
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Width = 50;
            // 
            // ESTUDIO
            // 
            this.ESTUDIO.HeaderText = "ESTUDIO";
            this.ESTUDIO.Name = "ESTUDIO";
            this.ESTUDIO.ReadOnly = true;
            this.ESTUDIO.Width = 250;
            // 
            // CODSUB
            // 
            this.CODSUB.HeaderText = "CODSUB";
            this.CODSUB.Name = "CODSUB";
            this.CODSUB.ReadOnly = true;
            this.CODSUB.Visible = false;
            // 
            // txtTecnologo
            // 
            this.txtTecnologo.Location = new System.Drawing.Point(100, 102);
            this.txtTecnologo.Name = "txtTecnologo";
            this.txtTecnologo.ReadOnly = true;
            this.txtTecnologo.Size = new System.Drawing.Size(321, 20);
            this.txtTecnologo.TabIndex = 96;
            // 
            // txtCODRadiologo
            // 
            this.txtCODRadiologo.Location = new System.Drawing.Point(524, 128);
            this.txtCODRadiologo.Name = "txtCODRadiologo";
            this.txtCODRadiologo.Size = new System.Drawing.Size(38, 20);
            this.txtCODRadiologo.TabIndex = 94;
            this.txtCODRadiologo.Text = "0";
            this.txtCODRadiologo.Visible = false;
            // 
            // txtRadiologo
            // 
            this.txtRadiologo.Location = new System.Drawing.Point(100, 130);
            this.txtRadiologo.Name = "txtRadiologo";
            this.txtRadiologo.ReadOnly = true;
            this.txtRadiologo.Size = new System.Drawing.Size(321, 20);
            this.txtRadiologo.TabIndex = 97;
            this.txtRadiologo.TextChanged += new System.EventHandler(this.txtRadiologo_TextChanged);
            // 
            // txtCODTecnologo
            // 
            this.txtCODTecnologo.Location = new System.Drawing.Point(524, 101);
            this.txtCODTecnologo.Name = "txtCODTecnologo";
            this.txtCODTecnologo.Size = new System.Drawing.Size(38, 20);
            this.txtCODTecnologo.TabIndex = 93;
            this.txtCODTecnologo.Text = "0";
            this.txtCODTecnologo.Visible = false;
            // 
            // txtPaciente
            // 
            appearance18.BackColor = System.Drawing.Color.White;
            this.txtPaciente.Appearance = appearance18;
            this.txtPaciente.BackColor = System.Drawing.Color.White;
            this.txtPaciente.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1;
            this.txtPaciente.DisplayStyle = Infragistics.Win.EmbeddableElementDisplayStyle.ScenicRibbon;
            this.txtPaciente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPaciente.Location = new System.Drawing.Point(100, 72);
            this.txtPaciente.Name = "txtPaciente";
            this.txtPaciente.ReadOnly = true;
            this.txtPaciente.Size = new System.Drawing.Size(321, 21);
            this.txtPaciente.TabIndex = 80;
            // 
            // btnRadiologo
            // 
            this.btnRadiologo.Location = new System.Drawing.Point(427, 129);
            this.btnRadiologo.Name = "btnRadiologo";
            this.btnRadiologo.Size = new System.Drawing.Size(28, 21);
            this.btnRadiologo.TabIndex = 81;
            this.btnRadiologo.Text = "...";
            this.btnRadiologo.UseVisualStyleBackColor = true;
            this.btnRadiologo.Click += new System.EventHandler(this.btnRadiologo_Click);
            // 
            // ultraLabel4
            // 
            this.ultraLabel4.AutoSize = true;
            this.ultraLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            appearance2.BackColor = System.Drawing.Color.Transparent;
            this.ultraLabel4.HotTrackAppearance = appearance2;
            this.ultraLabel4.Location = new System.Drawing.Point(9, 214);
            this.ultraLabel4.Name = "ultraLabel4";
            this.ultraLabel4.Size = new System.Drawing.Size(54, 14);
            this.ultraLabel4.TabIndex = 91;
            this.ultraLabel4.Text = "Estudios :";
            // 
            // txtObservaciones
            // 
            appearance3.BackColor = System.Drawing.Color.White;
            this.txtObservaciones.Appearance = appearance3;
            this.txtObservaciones.BackColor = System.Drawing.Color.White;
            this.txtObservaciones.BorderStyle = Infragistics.Win.UIElementBorderStyle.Rounded1;
            this.txtObservaciones.DisplayStyle = Infragistics.Win.EmbeddableElementDisplayStyle.ScenicRibbon;
            this.txtObservaciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtObservaciones.Location = new System.Drawing.Point(100, 158);
            this.txtObservaciones.MaxLength = 254;
            this.txtObservaciones.Multiline = true;
            this.txtObservaciones.Name = "txtObservaciones";
            this.txtObservaciones.Size = new System.Drawing.Size(466, 42);
            this.txtObservaciones.TabIndex = 82;
            // 
            // btnPaciente
            // 
            this.btnPaciente.Location = new System.Drawing.Point(427, 74);
            this.btnPaciente.Name = "btnPaciente";
            this.btnPaciente.Size = new System.Drawing.Size(28, 21);
            this.btnPaciente.TabIndex = 90;
            this.btnPaciente.Text = "...";
            this.btnPaciente.UseVisualStyleBackColor = true;
            this.btnPaciente.Click += new System.EventHandler(this.btnPaciente_Click);
            // 
            // ultraLabel8
            // 
            this.ultraLabel8.Location = new System.Drawing.Point(12, 105);
            this.ultraLabel8.Name = "ultraLabel8";
            this.ultraLabel8.Size = new System.Drawing.Size(82, 17);
            this.ultraLabel8.TabIndex = 83;
            this.ultraLabel8.Text = "Tecnólogo:";
            this.ultraLabel8.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // dtpFechaNota
            // 
            this.dtpFechaNota.CustomFormat = "dd-MM-yyyy HH:mm";
            this.dtpFechaNota.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFechaNota.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFechaNota.Location = new System.Drawing.Point(100, 46);
            this.dtpFechaNota.Name = "dtpFechaNota";
            this.dtpFechaNota.Size = new System.Drawing.Size(159, 20);
            this.dtpFechaNota.TabIndex = 89;
            // 
            // ultraLabel9
            // 
            this.ultraLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel9.Location = new System.Drawing.Point(12, 133);
            this.ultraLabel9.Name = "ultraLabel9";
            this.ultraLabel9.Size = new System.Drawing.Size(82, 17);
            this.ultraLabel9.TabIndex = 84;
            this.ultraLabel9.Text = "Radiólogo:";
            // 
            // ultraLabel3
            // 
            this.ultraLabel3.Location = new System.Drawing.Point(12, 49);
            this.ultraLabel3.Name = "ultraLabel3";
            this.ultraLabel3.Size = new System.Drawing.Size(82, 17);
            this.ultraLabel3.TabIndex = 88;
            this.ultraLabel3.Text = "Fecha:";
            this.ultraLabel3.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // btnTecnologo
            // 
            this.btnTecnologo.Location = new System.Drawing.Point(427, 101);
            this.btnTecnologo.Name = "btnTecnologo";
            this.btnTecnologo.Size = new System.Drawing.Size(28, 21);
            this.btnTecnologo.TabIndex = 85;
            this.btnTecnologo.Text = "...";
            this.btnTecnologo.UseVisualStyleBackColor = true;
            this.btnTecnologo.Click += new System.EventHandler(this.btnTecnologo_Click);
            // 
            // ultraLabel2
            // 
            this.ultraLabel2.Location = new System.Drawing.Point(12, 77);
            this.ultraLabel2.Name = "ultraLabel2";
            this.ultraLabel2.Size = new System.Drawing.Size(82, 17);
            this.ultraLabel2.TabIndex = 87;
            this.ultraLabel2.Text = "Paciente:";
            this.ultraLabel2.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // ultraLabel1
            // 
            this.ultraLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel1.Location = new System.Drawing.Point(12, 166);
            this.ultraLabel1.Name = "ultraLabel1";
            this.ultraLabel1.Size = new System.Drawing.Size(82, 18);
            this.ultraLabel1.TabIndex = 86;
            this.ultraLabel1.Text = "Observacion:";
            // 
            // pnl1
            // 
            this.pnl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnl1.Controls.Add(this.grid);
            this.pnl1.Controls.Add(this.groupBox5);
            this.pnl1.Controls.Add(this.tools);
            this.pnl1.Location = new System.Drawing.Point(5, 4);
            this.pnl1.Name = "pnl1";
            this.pnl1.Size = new System.Drawing.Size(637, 393);
            this.pnl1.TabIndex = 83;
            // 
            // grid
            // 
            this.grid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            appearance4.BackColor = System.Drawing.SystemColors.Window;
            appearance4.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grid.DisplayLayout.Appearance = appearance4;
            this.grid.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grid.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            appearance5.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance5.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance5.BorderColor = System.Drawing.SystemColors.Window;
            this.grid.DisplayLayout.GroupByBox.Appearance = appearance5;
            appearance6.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grid.DisplayLayout.GroupByBox.BandLabelAppearance = appearance6;
            this.grid.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance7.BackColor2 = System.Drawing.SystemColors.Control;
            appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance7.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grid.DisplayLayout.GroupByBox.PromptAppearance = appearance7;
            this.grid.DisplayLayout.MaxColScrollRegions = 1;
            this.grid.DisplayLayout.MaxRowScrollRegions = 1;
            appearance8.BackColor = System.Drawing.SystemColors.Window;
            appearance8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grid.DisplayLayout.Override.ActiveCellAppearance = appearance8;
            appearance9.BackColor = System.Drawing.SystemColors.Highlight;
            appearance9.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grid.DisplayLayout.Override.ActiveRowAppearance = appearance9;
            this.grid.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
            this.grid.DisplayLayout.Override.AllowDelete = Infragistics.Win.DefaultableBoolean.False;
            this.grid.DisplayLayout.Override.AllowRowFiltering = Infragistics.Win.DefaultableBoolean.True;
            this.grid.DisplayLayout.Override.AllowUpdate = Infragistics.Win.DefaultableBoolean.False;
            this.grid.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grid.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance10.BackColor = System.Drawing.SystemColors.Window;
            this.grid.DisplayLayout.Override.CardAreaAppearance = appearance10;
            appearance11.BorderColor = System.Drawing.Color.Silver;
            appearance11.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grid.DisplayLayout.Override.CellAppearance = appearance11;
            this.grid.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grid.DisplayLayout.Override.CellPadding = 0;
            this.grid.DisplayLayout.Override.ColumnSizingArea = Infragistics.Win.UltraWinGrid.ColumnSizingArea.EntireColumn;
            appearance12.BackColor = System.Drawing.SystemColors.Control;
            appearance12.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance12.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance12.BorderColor = System.Drawing.SystemColors.Window;
            this.grid.DisplayLayout.Override.GroupByRowAppearance = appearance12;
            appearance13.TextHAlignAsString = "Left";
            this.grid.DisplayLayout.Override.HeaderAppearance = appearance13;
            this.grid.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grid.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance14.BackColor = System.Drawing.SystemColors.Window;
            appearance14.BorderColor = System.Drawing.Color.Silver;
            this.grid.DisplayLayout.Override.RowAppearance = appearance14;
            this.grid.DisplayLayout.Override.RowSelectorHeaderStyle = Infragistics.Win.UltraWinGrid.RowSelectorHeaderStyle.ColumnChooserButton;
            appearance15.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grid.DisplayLayout.Override.TemplateAddRowAppearance = appearance15;
            this.grid.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grid.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grid.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grid.Location = new System.Drawing.Point(10, 265);
            this.grid.Name = "grid";
            this.grid.Size = new System.Drawing.Size(611, 114);
            this.grid.TabIndex = 81;
            this.grid.Text = "ultraGrid1";
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            appearance19.BackColor = System.Drawing.Color.Transparent;
            this.groupBox5.Appearance = appearance19;
            this.groupBox5.Controls.Add(this.dtpHasta);
            this.groupBox5.Controls.Add(this.monthCalendar1);
            this.groupBox5.Controls.Add(this.dtpDesde);
            this.groupBox5.Controls.Add(this.label63);
            this.groupBox5.Controls.Add(this.label67);
            this.groupBox5.ForeColor = System.Drawing.Color.Black;
            appearance20.FontData.BoldAsString = "True";
            appearance20.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox5.HeaderAppearance = appearance20;
            this.groupBox5.Location = new System.Drawing.Point(3, 46);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(619, 213);
            this.groupBox5.TabIndex = 81;
            this.groupBox5.Text = "Rango de fechas:";
            // 
            // dtpHasta
            // 
            this.dtpHasta.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.dtpHasta.CalendarTitleForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.dtpHasta.CustomFormat = "dd-MM-yyyy HH:mm";
            this.dtpHasta.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpHasta.Location = new System.Drawing.Point(289, 19);
            this.dtpHasta.Name = "dtpHasta";
            this.dtpHasta.Size = new System.Drawing.Size(122, 20);
            this.dtpHasta.TabIndex = 69;
            this.dtpHasta.Value = new System.DateTime(2010, 10, 16, 0, 0, 0, 0);
            this.dtpHasta.ValueChanged += new System.EventHandler(this.dtpHasta_ValueChanged);
            this.dtpHasta.Leave += new System.EventHandler(this.dtpHasta_Leave);
            this.dtpHasta.MouseLeave += new System.EventHandler(this.dtpHasta_MouseLeave);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.monthCalendar1.BackColor = System.Drawing.Color.Gainsboro;
            this.monthCalendar1.CalendarDimensions = new System.Drawing.Size(3, 1);
            this.monthCalendar1.Location = new System.Drawing.Point(7, 48);
            this.monthCalendar1.MaxSelectionCount = 90;
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.SelectionRange = new System.Windows.Forms.SelectionRange(new System.DateTime(2020, 7, 14, 0, 0, 0, 0), new System.DateTime(2020, 9, 14, 0, 0, 0, 0));
            this.monthCalendar1.TabIndex = 0;
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);
            this.monthCalendar1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateSelected);
            // 
            // dtpDesde
            // 
            this.dtpDesde.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.dtpDesde.CalendarTitleForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.dtpDesde.CustomFormat = "dd-MM-yyyy HH:mm";
            this.dtpDesde.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDesde.Location = new System.Drawing.Point(106, 18);
            this.dtpDesde.Name = "dtpDesde";
            this.dtpDesde.Size = new System.Drawing.Size(122, 20);
            this.dtpDesde.TabIndex = 68;
            this.dtpDesde.Value = new System.DateTime(2010, 10, 16, 0, 0, 0, 0);
            this.dtpDesde.ValueChanged += new System.EventHandler(this.dtpDesde_ValueChanged);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.BackColor = System.Drawing.Color.Transparent;
            this.label63.ForeColor = System.Drawing.Color.Black;
            this.label63.Location = new System.Drawing.Point(245, 25);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(38, 13);
            this.label63.TabIndex = 65;
            this.label63.Text = "Hasta:";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.BackColor = System.Drawing.Color.Transparent;
            this.label67.ForeColor = System.Drawing.Color.Black;
            this.label67.Location = new System.Drawing.Point(59, 24);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(41, 13);
            this.label67.TabIndex = 52;
            this.label67.Text = "Desde:";
            // 
            // tools
            // 
            this.tools.AutoSize = false;
            this.tools.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNuevo,
            this.btnModificar,
            this.btnDelete,
            this.toolStripSeparator2,
            this.toolStripButtonActualizar,
            this.toolStripButtonBuscar,
            this.toolStripSeparator1,
            this.toolStripButtonSalir});
            this.tools.Location = new System.Drawing.Point(0, 0);
            this.tools.Name = "tools";
            this.tools.Size = new System.Drawing.Size(637, 45);
            this.tools.TabIndex = 79;
            this.tools.Text = "toolStrip1";
            // 
            // btnNuevo
            // 
            this.btnNuevo.AutoSize = false;
            this.btnNuevo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnNuevo.Image = ((System.Drawing.Image)(resources.GetObject("btnNuevo.Image")));
            this.btnNuevo.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnNuevo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(42, 42);
            this.btnNuevo.Text = "toolStripButton1";
            this.btnNuevo.ToolTipText = "Nuevo";
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // btnModificar
            // 
            this.btnModificar.AutoSize = false;
            this.btnModificar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnModificar.Image = ((System.Drawing.Image)(resources.GetObject("btnModificar.Image")));
            this.btnModificar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnModificar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(42, 42);
            this.btnModificar.Text = "Modificar";
            this.btnModificar.ToolTipText = "Modificar";
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.AutoSize = false;
            this.btnDelete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(42, 42);
            this.btnDelete.Text = "Modificar";
            this.btnDelete.ToolTipText = "Cancelar Cita";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 45);
            // 
            // toolStripButtonActualizar
            // 
            this.toolStripButtonActualizar.AutoSize = false;
            this.toolStripButtonActualizar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonActualizar.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonActualizar.Image")));
            this.toolStripButtonActualizar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonActualizar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonActualizar.Name = "toolStripButtonActualizar";
            this.toolStripButtonActualizar.Size = new System.Drawing.Size(42, 42);
            this.toolStripButtonActualizar.Text = "toolStripButton1";
            this.toolStripButtonActualizar.ToolTipText = "Actualizar";
            this.toolStripButtonActualizar.Click += new System.EventHandler(this.toolStripButtonActualizar_Click);
            // 
            // toolStripButtonBuscar
            // 
            this.toolStripButtonBuscar.AutoSize = false;
            this.toolStripButtonBuscar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonBuscar.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonBuscar.Image")));
            this.toolStripButtonBuscar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonBuscar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonBuscar.Name = "toolStripButtonBuscar";
            this.toolStripButtonBuscar.Size = new System.Drawing.Size(42, 42);
            this.toolStripButtonBuscar.Text = "Exportar";
            this.toolStripButtonBuscar.ToolTipText = "Exportar a excel";
            this.toolStripButtonBuscar.Click += new System.EventHandler(this.toolStripButtonBuscar_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 45);
            // 
            // toolStripButtonSalir
            // 
            this.toolStripButtonSalir.AutoSize = false;
            this.toolStripButtonSalir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonSalir.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSalir.Image")));
            this.toolStripButtonSalir.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonSalir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSalir.Name = "toolStripButtonSalir";
            this.toolStripButtonSalir.Size = new System.Drawing.Size(42, 42);
            this.toolStripButtonSalir.Text = "toolStripButton1";
            this.toolStripButtonSalir.ToolTipText = "Salir";
            this.toolStripButtonSalir.Click += new System.EventHandler(this.toolStripButtonSalir_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 50;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "ESTUDIO";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 250;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "CODSUB";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Visible = false;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "NOTA";
            this.dataGridViewTextBoxColumn4.MaxInputLength = 20;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 170;
            // 
            // pnl3
            // 
            this.pnl3.Controls.Add(this.button2);
            this.pnl3.Controls.Add(this.button1);
            this.pnl3.Controls.Add(this.txtMotivoCancelacion);
            this.pnl3.Controls.Add(this.label1);
            this.pnl3.Controls.Add(this.lblDelete);
            this.pnl3.Location = new System.Drawing.Point(-1, 75);
            this.pnl3.Name = "pnl3";
            this.pnl3.Size = new System.Drawing.Size(647, 182);
            this.pnl3.TabIndex = 84;
            this.pnl3.Visible = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(328, 132);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "Cancelar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(120, 132);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Aceptar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtMotivoCancelacion
            // 
            this.txtMotivoCancelacion.Location = new System.Drawing.Point(29, 72);
            this.txtMotivoCancelacion.MaxLength = 50;
            this.txtMotivoCancelacion.Multiline = true;
            this.txtMotivoCancelacion.Name = "txtMotivoCancelacion";
            this.txtMotivoCancelacion.Size = new System.Drawing.Size(502, 24);
            this.txtMotivoCancelacion.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(225, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Por favor escriba el motivo y presione aceptar.";
            // 
            // lblDelete
            // 
            this.lblDelete.AutoSize = true;
            this.lblDelete.Location = new System.Drawing.Point(26, 33);
            this.lblDelete.Name = "lblDelete";
            this.lblDelete.Size = new System.Drawing.Size(169, 13);
            this.lblDelete.TabIndex = 0;
            this.lblDelete.Text = "Se cancelara el agendamiento de ";
            // 
            // ImagenAgendamiento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(647, 400);
            this.Controls.Add(this.pnl1);
            this.Controls.Add(this.pnl3);
            this.Controls.Add(this.pnl2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ImagenAgendamiento";
            this.Text = "Agendamiento de Imagen";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.pnl2.ResumeLayout(false);
            this.pnl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grpATE)).EndInit();
            this.grpATE.ResumeLayout(false);
            this.grpATE.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridEstudios)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPaciente)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtObservaciones)).EndInit();
            this.pnl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupBox5)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tools.ResumeLayout(false);
            this.tools.PerformLayout();
            this.pnl3.ResumeLayout(false);
            this.pnl3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Admision.CachedGarantias cachedGarantias1;
        private Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage ultraTabSharedControlsPage3;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.Panel pnl2;
        private System.Windows.Forms.Button btnAgregaEstudio;
        private System.Windows.Forms.TextBox txtIdAgendamiento;
        private System.Windows.Forms.DataGridView gridEstudios;
        private System.Windows.Forms.TextBox txtHC;
        private System.Windows.Forms.TextBox txtTecnologo;
        private System.Windows.Forms.TextBox txtCODRadiologo;
        private System.Windows.Forms.TextBox txtRadiologo;
        private System.Windows.Forms.TextBox txtCODTecnologo;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtPaciente;
        private System.Windows.Forms.Button btnRadiologo;
        private Infragistics.Win.Misc.UltraLabel ultraLabel4;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor txtObservaciones;
        private System.Windows.Forms.Button btnPaciente;
        private Infragistics.Win.Misc.UltraLabel ultraLabel8;
        private System.Windows.Forms.DateTimePicker dtpFechaNota;
        private Infragistics.Win.Misc.UltraLabel ultraLabel9;
        private Infragistics.Win.Misc.UltraLabel ultraLabel3;
        private System.Windows.Forms.Button btnTecnologo;
        private Infragistics.Win.Misc.UltraLabel ultraLabel2;
        private Infragistics.Win.Misc.UltraLabel ultraLabel1;
        private System.Windows.Forms.Panel pnl1;
        private Infragistics.Win.UltraWinGrid.UltraGrid grid;
        private Infragistics.Win.Misc.UltraGroupBox groupBox5;
        private System.Windows.Forms.DateTimePicker dtpHasta;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.DateTimePicker dtpDesde;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.ToolStrip tools;
        private System.Windows.Forms.ToolStripButton btnNuevo;
        private System.Windows.Forms.ToolStripButton btnModificar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButtonActualizar;
        private System.Windows.Forms.ToolStripButton toolStripButtonBuscar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButtonSalir;
        private Infragistics.Win.UltraWinGrid.ExcelExport.UltraGridExcelExporter ultraGridExcelExporter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private Infragistics.Win.Misc.UltraLabel ultraLabel5;
        private Infragistics.Win.Misc.UltraGroupBox grpATE;
        private System.Windows.Forms.ToolStripButton btnDelete;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ESTUDIO;
        private System.Windows.Forms.DataGridViewTextBoxColumn CODSUB;
        private System.Windows.Forms.Panel pnl3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtMotivoCancelacion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDelete;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.Label lblAlertaImagen;
    }
}