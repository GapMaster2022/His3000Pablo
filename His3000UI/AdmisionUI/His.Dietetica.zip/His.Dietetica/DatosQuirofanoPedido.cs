﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace His.Dietetica
{
    public class DatosQuirofanoPedido
    {
        public string hc { get; set; }
        public string atencion { get; set; }
        public string num_pedido { get; set; }
        public string paciente { get; set; }
        public string fecha { get; set; }
        public string usuario { get; set; }
        public string medico { get; set; }
        public string cant { get; set; }
        public string codigo { get; set; }
        public string descripcion { get; set; }
    }
}
